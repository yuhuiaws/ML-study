#!/usr/bin/env bash
# prereq_check.sh — Validate node prerequisites for vLLM 1P1D DeepSeek-V4-Pro on EKS
# Usage: Run on each p5en.48xlarge node (via SSM or kubectl exec on a privileged pod)
#   bash prereq_check.sh [--mooncake|--nixl]

set -euo pipefail

MODE="${1:---mooncake}"
PASS=0
FAIL=0

check() {
    local desc="$1"
    shift
    if eval "$@" >/dev/null 2>&1; then
        echo "  ✅ $desc"
        ((PASS++))
    else
        echo "  ❌ $desc"
        ((FAIL++))
    fi
}

echo "=== vLLM 1P1D DeepSeek-V4 Prerequisites Check ($(date)) ==="
echo "Mode: $MODE"
echo ""

# --- EKS / Kubernetes ---
echo "[1/7] EKS Cluster"
check "kubectl accessible" "kubectl cluster-info"

# --- EFA Device Plugin ---
echo "[2/7] EFA Device Plugin"
check "EFA device plugin DaemonSet running" "kubectl get ds -n kube-system 2>/dev/null | grep -q efa"

# --- EFA Devices ---
echo "[3/7] EFA Devices on Node"
EFA_COUNT=$(ls /dev/infiniband/uverbs* 2>/dev/null | wc -l)
check "EFA devices >= 16 (found: $EFA_COUNT)" "[ $EFA_COUNT -ge 16 ]"
check "libfabric available (fi_info)" "command -v fi_info"
check "EFA provider with FI_RMA capability" "fi_info -p efa -c FI_RMA 2>/dev/null | grep -q efa"

# --- GPU ---
echo "[4/7] GPU"
GPU_COUNT=$(nvidia-smi -L 2>/dev/null | wc -l)
check "8x H200 GPUs (found: $GPU_COUNT)" "[ $GPU_COUNT -eq 8 ]"
check "NVSwitch topology (NV18)" "nvidia-smi topo -m 2>/dev/null | grep -q NV18"

# --- Kernel Modules (Mooncake-specific) ---
echo "[5/7] Kernel Modules"
if [[ "$MODE" == "--mooncake" ]]; then
    check "efa_nv_peermem loaded" "lsmod | grep -q efa_nv_peermem"
    if ! lsmod | grep -q efa_nv_peermem; then
        echo "       → Fix: sudo modprobe efa_nv_peermem"
    fi
else
    echo "  ⏭️  efa_nv_peermem not required for NIXL mode"
fi

# --- sysctl ---
echo "[6/7] sysctl"
MAX_MAP=$(cat /proc/sys/vm/max_map_count 2>/dev/null || echo 0)
check "vm.max_map_count >= 16777216 (current: $MAX_MAP)" "[ $MAX_MAP -ge 16777216 ]"
if [ "$MAX_MAP" -lt 16777216 ]; then
    echo "       → Fix: sudo sysctl -w vm.max_map_count=16777216"
fi

# --- Storage ---
echo "[7/7] Storage"
NVME_AVAIL=$(df --output=avail /opt/dlami/nvme 2>/dev/null | tail -1 | tr -d ' ')
check "NVMe mounted at /opt/dlami/nvme" "df /opt/dlami/nvme >/dev/null 2>&1"
if [ -d /opt/dlami/nvme/DeepSeek-V4-Pro ]; then
    MODEL_SIZE=$(du -sb /opt/dlami/nvme/DeepSeek-V4-Pro 2>/dev/null | cut -f1)
    check "Model downloaded (size: $(numfmt --to=iec $MODEL_SIZE 2>/dev/null || echo $MODEL_SIZE))" "[ ${MODEL_SIZE:-0} -gt 800000000000 ]"
else
    echo "  ❌ Model not found at /opt/dlami/nvme/DeepSeek-V4-Pro"
    ((FAIL++))
fi

echo ""
echo "=== Results: $PASS passed, $FAIL failed ==="
[ $FAIL -eq 0 ] && echo "All checks passed! Ready to deploy." || echo "Fix the failed checks before deploying."
exit $FAIL
