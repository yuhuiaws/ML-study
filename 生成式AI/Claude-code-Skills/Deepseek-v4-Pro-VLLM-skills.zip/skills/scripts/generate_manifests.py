#!/usr/bin/env python3
"""
generate_manifests.py — Generate K8s YAML manifests for vLLM 1P1D DeepSeek-V4-Pro deployment.

Usage:
    python generate_manifests.py --mode mooncake --prefill-ip 10.2.140.108 --decode-ip 10.2.140.109 --image <ecr>/vllm:tag --output-dir ./manifests
    python generate_manifests.py --mode nixl --prefill-ip 10.2.140.108 --decode-ip 10.2.140.109 --image <ecr>/vllm:tag --output-dir ./manifests
"""

import argparse
import json
import os
import sys
import yaml


def generate_namespace():
    return {
        "apiVersion": "v1",
        "kind": "Namespace",
        "metadata": {"name": "vllm-pd"}
    }


def generate_configmap(mode: str):
    common_data = {
        "FI_PROVIDER": "efa",
        "FI_EFA_USE_DEVICE_RDMA": "1",
        "FI_EFA_FORK_SAFE": "1",
        "NCCL_MNNVL_ENABLE": "0",
        "NCCL_NVLS_ENABLE": "0",
        "NCCL_PROTO": "Simple",
        "VLLM_USE_NCCL_SYMM_MEM": "0",
        "VLLM_ENGINE_READY_TIMEOUT_S": "3600",
        "VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS": "0",
    }

    if mode == "mooncake":
        common_data.update({
            "MC_SLICE_SIZE": "1048576",
            "MC_ENABLE_DEST_DEVICE_AFFINITY": "1",
            "MOONCAKE_PROTOCOL": "efa",
        })
    else:
        common_data["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

    return {
        "apiVersion": "v1",
        "kind": "ConfigMap",
        "metadata": {"name": f"vllm-{mode}-config", "namespace": "vllm-pd"},
        "data": common_data
    }


def _base_pod_spec(name: str, node_ip: str, image: str, role_label: str,
                   port: int, args: list, env_extra: list = None,
                   model_path: str = "/models/DeepSeek-V4-Pro",
                   configmap_name: str = "vllm-mooncake-config"):
    env = [
        {"name": "CUDA_VISIBLE_DEVICES", "value": "0,1,2,3,4,5,6,7"},
        {"name": "MODEL_PATH", "value": model_path},
    ]
    if env_extra:
        env.extend(env_extra)

    return {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": name,
            "namespace": "vllm-pd",
            "labels": {"app": name, "role": role_label}
        },
        "spec": {
            "hostNetwork": True,
            "dnsPolicy": "ClusterFirstWithHostNet",
            "nodeSelector": {"vllm/role": role_label},
            "restartPolicy": "Never",
            "containers": [{
                "name": "vllm",
                "image": image,
                "args": args,
                "env": env,
                "envFrom": [{"configMapRef": {"name": configmap_name}}],
                "resources": {
                    "limits": {
                        "nvidia.com/gpu": "8",
                        "vpc.amazonaws.com/efa": "16"
                    },
                    "requests": {
                        "nvidia.com/gpu": "8",
                        "vpc.amazonaws.com/efa": "16"
                    }
                },
                "securityContext": {
                    "capabilities": {"add": ["IPC_LOCK"]}
                },
                "volumeMounts": [
                    {"name": "model", "mountPath": "/models/DeepSeek-V4-Pro"},
                    {"name": "shm", "mountPath": "/dev/shm"}
                ]
            }],
            "volumes": [
                {"name": "model", "hostPath": {"path": "/opt/dlami/nvme/DeepSeek-V4-Pro"}},
                {"name": "shm", "emptyDir": {"medium": "Memory", "sizeLimit": "64Gi"}}
            ]
        }
    }


def _common_vllm_args(node_ip: str, port: int, dp_size: int = 8):
    return [
        "vllm", "serve", "/models/DeepSeek-V4-Pro",
        "--trust-remote-code",
        "--tokenizer-mode", "deepseek_v4",
        "--tool-call-parser", "deepseek_v4",
        "--reasoning-parser", "deepseek_v4",
        "--enable-auto-tool-choice",
        "--kv-cache-dtype", "fp8",
        "--block-size", "256",
        "--data-parallel-size", str(dp_size),
        "--data-parallel-size-local", str(dp_size),
        "--data-parallel-address", node_ip,
        "--data-parallel-rpc-port", "29500",
        "--enable-expert-parallel",
        "--max-num-seqs", "512",
        "--max-num-batched-tokens", "512",
        "--no-enable-flashinfer-autotune",
        "--compilation-config", json.dumps({"mode": 0, "cudagraph_mode": "FULL_DECODE_ONLY"}),
        "--enable-sleep-mode",
        "--no-disable-hybrid-kv-cache-manager",
        "--gpu-memory-utilization", "0.90",
        "--port", str(port),
    ]


def generate_mooncake_prefill(prefill_ip: str, image: str, max_model_len: int = 32768):
    kv_config = json.dumps({
        "kv_connector": "MooncakeConnector",
        "kv_role": "kv_producer",
        "kv_load_failure_policy": "fail",
        "kv_connector_extra_config": {"mooncake_protocol": "efa"}
    })

    args = _common_vllm_args(prefill_ip, 8001)
    args.extend([
        "--max-model-len", str(max_model_len),
        "--enforce-eager",
        "--no-async-scheduling",
        "--kv-transfer-config", kv_config,
    ])

    env_extra = [
        {"name": "VLLM_MOONCAKE_BOOTSTRAP_PORT", "value": "8998"},
    ]

    pod = _base_pod_spec("vllm-prefill", prefill_ip, image, "prefill", 8001,
                         args, env_extra, configmap_name="vllm-mooncake-config")

    # Add sed patch for bootstrap race fix
    pod["spec"]["containers"][0]["command"] = ["bash", "-c"]
    patch_script = """set -e
FILE=/usr/local/lib/python3.12/site-packages/vllm/distributed/kv_transfer/kv_connector/v1/mooncake/mooncake_connector.py
sed -i 's|async with httpx.AsyncClient() as client:|async with httpx.AsyncClient(timeout=30.0) as client:|' "$FILE"
sed -i 's|except httpx.ConnectError:|except (httpx.ConnectError, httpx.TimeoutException, httpx.RemoteProtocolError):|' "$FILE"
exec """ + " ".join(f'"{a}"' if " " in a or "{" in a else a for a in args)
    pod["spec"]["containers"][0]["args"] = [patch_script]

    return pod


def generate_mooncake_decode(decode_ip: str, image: str, max_model_len: int = 32768):
    kv_config = json.dumps({
        "kv_connector": "MooncakeConnector",
        "kv_role": "kv_consumer",
        "kv_load_failure_policy": "fail",
        "kv_connector_extra_config": {"mooncake_protocol": "efa"}
    })

    args = _common_vllm_args(decode_ip, 8002)
    args.extend([
        "--max-model-len", str(max_model_len),
        "--enforce-eager",
        "--kv-transfer-config", kv_config,
    ])

    env_extra = [
        {"name": "VLLM_MOONCAKE_BOOTSTRAP_PORT", "value": "8998"},
    ]

    pod = _base_pod_spec("vllm-decode", decode_ip, image, "decode", 8002,
                         args, env_extra, configmap_name="vllm-mooncake-config")

    # Same sed patch
    pod["spec"]["containers"][0]["command"] = ["bash", "-c"]
    patch_script = """set -e
FILE=/usr/local/lib/python3.12/site-packages/vllm/distributed/kv_transfer/kv_connector/v1/mooncake/mooncake_connector.py
sed -i 's|async with httpx.AsyncClient() as client:|async with httpx.AsyncClient(timeout=30.0) as client:|' "$FILE"
sed -i 's|except httpx.ConnectError:|except (httpx.ConnectError, httpx.TimeoutException, httpx.RemoteProtocolError):|' "$FILE"
exec """ + " ".join(f'"{a}"' if " " in a or "{" in a else a for a in args)
    pod["spec"]["containers"][0]["args"] = [patch_script]

    return pod


def generate_mooncake_proxy(prefill_ip: str, decode_ip: str, image: str):
    return {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": "vllm-router",
            "namespace": "vllm-pd",
            "labels": {"app": "vllm-router"}
        },
        "spec": {
            "hostNetwork": True,
            "dnsPolicy": "ClusterFirstWithHostNet",
            "restartPolicy": "Never",
            "containers": [{
                "name": "proxy",
                "image": image,
                "command": ["python3"],
                "args": [
                    "-m", "vllm.entrypoints.openai.disaggregated_serving.mooncake_connector.mooncake_connector_proxy",
                    "--prefill-addr", f"http://{prefill_ip}:8001",
                    "--decode-addr", f"http://{decode_ip}:8002",
                    "--host", "0.0.0.0",
                    "--port", "30000",
                ],
                "ports": [{"containerPort": 30000, "name": "api"}],
                "resources": {"requests": {"cpu": "2", "memory": "4Gi"}}
            }]
        }
    }


def generate_mooncake_proxy_service():
    return {
        "apiVersion": "v1",
        "kind": "Service",
        "metadata": {"name": "vllm-router", "namespace": "vllm-pd"},
        "spec": {
            "selector": {"app": "vllm-router"},
            "ports": [{"port": 30000, "targetPort": 30000, "name": "api"}],
            "type": "ClusterIP"
        }
    }


def generate_nixl_prefill(prefill_ip: str, image: str, max_model_len: int = 131072,
                          backend: str = "UCX"):
    kv_config = {"kv_connector": "NixlConnector", "kv_role": "kv_producer",
                 "kv_load_failure_policy": "fail"}
    if backend == "LIBFABRIC":
        kv_config["kv_connector_extra_config"] = {"backends": ["LIBFABRIC"]}

    args = _common_vllm_args(prefill_ip, 8001)
    args.extend([
        "--max-model-len", str(max_model_len),
        "--enforce-eager",
        "--no-async-scheduling",
        "--kv-transfer-config", json.dumps(kv_config),
    ])

    env_extra = [
        {"name": "VLLM_NIXL_SIDE_CHANNEL_HOST", "value": prefill_ip},
        {"name": "VLLM_NIXL_SIDE_CHANNEL_PORT", "value": "5557"},
    ]
    if backend == "LIBFABRIC":
        env_extra.extend([
            {"name": "NIXL_PLUGIN_DIR",
             "value": "/usr/local/lib/python3.12/site-packages/.nixl_cu13.mesonpy.libs/plugins"},
            {"name": "LD_LIBRARY_PATH",
             "value": "/usr/local/lib/python3.12/site-packages/.nixl_cu13.mesonpy.libs:/opt/amazon/efa/lib64:/opt/amazon/efa/lib:/usr/local/nvidia/lib64:/usr/local/cuda/lib64"},
        ])

    return _base_pod_spec("vllm-prefill", prefill_ip, image, "prefill", 8001,
                          args, env_extra, configmap_name="vllm-nixl-config")


def generate_nixl_decode(decode_ip: str, image: str, max_model_len: int = 131072,
                         backend: str = "UCX"):
    kv_config = {"kv_connector": "NixlConnector", "kv_role": "kv_consumer",
                 "kv_load_failure_policy": "fail"}
    if backend == "LIBFABRIC":
        kv_config["kv_connector_extra_config"] = {"backends": ["LIBFABRIC"]}

    args = _common_vllm_args(decode_ip, 8002)
    args.extend([
        "--max-model-len", str(max_model_len),
        "--max-cudagraph-capture-size", "1024",
        "--kv-transfer-config", json.dumps(kv_config),
    ])

    env_extra = [
        {"name": "VLLM_NIXL_SIDE_CHANNEL_HOST", "value": decode_ip},
        {"name": "VLLM_NIXL_SIDE_CHANNEL_PORT", "value": "5558"},
    ]
    if backend == "LIBFABRIC":
        env_extra.extend([
            {"name": "NIXL_PLUGIN_DIR",
             "value": "/usr/local/lib/python3.12/site-packages/.nixl_cu13.mesonpy.libs/plugins"},
            {"name": "LD_LIBRARY_PATH",
             "value": "/usr/local/lib/python3.12/site-packages/.nixl_cu13.mesonpy.libs:/opt/amazon/efa/lib64:/opt/amazon/efa/lib:/usr/local/nvidia/lib64:/usr/local/cuda/lib64"},
        ])

    return _base_pod_spec("vllm-decode", decode_ip, image, "decode", 8002,
                          args, env_extra, configmap_name="vllm-nixl-config")


def generate_nixl_router(prefill_ip: str, decode_ip: str, image: str):
    return {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": "vllm-router",
            "namespace": "vllm-pd",
            "labels": {"app": "vllm-router"}
        },
        "spec": {
            "hostNetwork": True,
            "dnsPolicy": "ClusterFirstWithHostNet",
            "restartPolicy": "Never",
            "containers": [{
                "name": "router",
                "image": image,
                "command": ["vllm-router"],
                "args": [
                    "--port", "30000",
                    "--policy", "round_robin",
                    "--vllm-pd-disaggregation",
                    "--intra-node-data-parallel-size", "8",
                    "--engine-url", f"http://{prefill_ip}:8001",
                    "--engine-url", f"http://{decode_ip}:8002",
                ],
                "ports": [{"containerPort": 30000, "name": "api"}],
                "resources": {"requests": {"cpu": "2", "memory": "4Gi"}}
            }]
        }
    }


def main():
    parser = argparse.ArgumentParser(description="Generate K8s manifests for vLLM 1P1D DeepSeek-V4-Pro")
    parser.add_argument("--mode", choices=["mooncake", "nixl"], required=True)
    parser.add_argument("--prefill-ip", required=True, help="Prefill node internal IP")
    parser.add_argument("--decode-ip", required=True, help="Decode node internal IP")
    parser.add_argument("--image", required=True, help="Docker image URI")
    parser.add_argument("--output-dir", default="./manifests", help="Output directory")
    parser.add_argument("--max-model-len", type=int, default=None,
                        help="Max model length (default: 32768 for mooncake, 131072 for nixl)")
    parser.add_argument("--nixl-backend", choices=["UCX", "LIBFABRIC"], default="UCX",
                        help="NIXL backend (only for --mode nixl)")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    if args.max_model_len is None:
        args.max_model_len = 32768 if args.mode == "mooncake" else 131072

    manifests = []

    manifests.append(("00-namespace.yaml", generate_namespace()))
    manifests.append(("01-configmap.yaml", generate_configmap(args.mode)))

    if args.mode == "mooncake":
        manifests.append(("02-prefill-pod.yaml",
                          generate_mooncake_prefill(args.prefill_ip, args.image, args.max_model_len)))
        manifests.append(("03-decode-pod.yaml",
                          generate_mooncake_decode(args.decode_ip, args.image, args.max_model_len)))
        manifests.append(("04-router-pod.yaml",
                          generate_mooncake_proxy(args.prefill_ip, args.decode_ip, args.image)))
        manifests.append(("05-router-service.yaml", generate_mooncake_proxy_service()))
    else:
        manifests.append(("02-prefill-pod.yaml",
                          generate_nixl_prefill(args.prefill_ip, args.image, args.max_model_len,
                                               args.nixl_backend)))
        manifests.append(("03-decode-pod.yaml",
                          generate_nixl_decode(args.decode_ip, args.image, args.max_model_len,
                                              args.nixl_backend)))
        manifests.append(("04-router-pod.yaml",
                          generate_nixl_router(args.prefill_ip, args.decode_ip, args.image)))

    for filename, manifest in manifests:
        path = os.path.join(args.output_dir, filename)
        with open(path, "w") as f:
            yaml.dump(manifest, f, default_flow_style=False, allow_unicode=True)
        print(f"  Generated: {path}")

    print(f"\nDone! {len(manifests)} manifests written to {args.output_dir}/")
    print(f"\nDeploy with:")
    print(f"  kubectl apply -f {args.output_dir}/00-namespace.yaml")
    print(f"  kubectl apply -f {args.output_dir}/01-configmap.yaml")
    print(f"  kubectl apply -f {args.output_dir}/02-prefill-pod.yaml")
    print(f"  # Wait for prefill API ready...")
    print(f"  kubectl apply -f {args.output_dir}/03-decode-pod.yaml")
    print(f"  # Wait for decode API ready...")
    print(f"  kubectl apply -f {args.output_dir}/04-router-pod.yaml")


if __name__ == "__main__":
    main()
