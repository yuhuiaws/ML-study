#!/usr/bin/env bash
# validate.sh — Post-deployment validation for vLLM 1P1D DeepSeek-V4-Pro
#
# Usage: bash validate.sh [--mode mooncake|nixl]

set -euo pipefail

MODE="${1:---mode}"
MODE="${2:-mooncake}"
if [[ "$1" == "--mooncake" || "$1" == "--nixl" ]]; then
    MODE="${1#--}"
fi

NAMESPACE="vllm-pd"
PASS=0
FAIL=0

check() {
    local desc="$1"; shift
    if eval "$@" >/dev/null 2>&1; then
        echo "  ✅ $desc"; ((PASS++))
    else
        echo "  ❌ $desc"; ((FAIL++))
    fi
}

echo "=== vLLM 1P1D Validation (mode=$MODE) ==="
echo ""

# --- Pod status ---
echo "[1/6] Pod Status"
check "Prefill pod running" "kubectl get pod vllm-prefill -n $NAMESPACE -o jsonpath='{.status.phase}' | grep -q Running"
check "Decode pod running" "kubectl get pod vllm-decode -n $NAMESPACE -o jsonpath='{.status.phase}' | grep -q Running"
check "Router pod running" "kubectl get pod vllm-router -n $NAMESPACE -o jsonpath='{.status.phase}' | grep -q Running"

# --- API ports ---
echo "[2/6] API Ports"
check "Prefill :8001 listening" "kubectl exec vllm-prefill -n $NAMESPACE -- ss -tln | grep -q ':8001 '"
check "Decode :8002 listening" "kubectl exec vllm-decode -n $NAMESPACE -- ss -tln | grep -q ':8002 '"

# --- KV Transfer connector ---
echo "[3/6] KV Transfer"
if [ "$MODE" == "mooncake" ]; then
    check "Mooncake EFA transport installed" "kubectl logs vllm-prefill -n $NAMESPACE | grep -q 'EFA transport installed'"
    check "No fi_mr_regattr errors" "! kubectl logs vllm-prefill -n $NAMESPACE | grep -q 'fi_mr_regattr failed'"
    check "16 EFA devices registered" "kubectl logs vllm-prefill -n $NAMESPACE | grep -c 'EFA device' | grep -qE '(16|^[0-9]{2,})'"
else
    NIXL_COUNT=$(kubectl logs vllm-prefill -n $NAMESPACE | grep -c "NIXL is available" || echo 0)
    check "NIXL available (count=$NIXL_COUNT, expect>=8)" "[ $NIXL_COUNT -ge 8 ]"
fi

# --- DeepGEMM ---
echo "[4/6] DeepGEMM"
check "DeepGEMM importable" "kubectl exec vllm-prefill -n $NAMESPACE -- python3 -c 'import deep_gemm'"

# --- Health endpoints ---
echo "[5/6] Health Checks"
PREFILL_IP=$(kubectl get node -l vllm/role=prefill -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
DECODE_IP=$(kubectl get node -l vllm/role=decode -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')

check "Prefill /health" "kubectl exec vllm-prefill -n $NAMESPACE -- curl -sf http://localhost:8001/health"
check "Decode /health" "kubectl exec vllm-decode -n $NAMESPACE -- curl -sf http://localhost:8002/health"

# --- E2E inference ---
echo "[6/6] E2E Inference"
ROUTER_IP=$(kubectl get svc vllm-router -n $NAMESPACE -o jsonpath='{.spec.clusterIP}' 2>/dev/null || echo "$PREFILL_IP")
MODEL_NAME="/models/DeepSeek-V4-Pro"
[ "$MODE" == "nixl" ] && MODEL_NAME="deepseek-ai/DeepSeek-V4-Pro"

RESPONSE=$(kubectl exec vllm-prefill -n $NAMESPACE -- curl -sf --max-time 120 \
    "http://$ROUTER_IP:30000/v1/chat/completions" \
    -H "Content-Type: application/json" \
    -d "{\"model\":\"$MODEL_NAME\",\"messages\":[{\"role\":\"user\",\"content\":\"What is 2+2? Answer in one word.\"}],\"max_tokens\":10,\"temperature\":0}" 2>&1 || echo "FAILED")

if echo "$RESPONSE" | grep -q '"choices"'; then
    CONTENT=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['choices'][0]['message']['content'])" 2>/dev/null || echo "parse_error")
    echo "  ✅ E2E inference OK (response: $CONTENT)"
    ((PASS++))
else
    echo "  ❌ E2E inference failed"
    echo "     Response: ${RESPONSE:0:200}"
    ((FAIL++))
fi

# --- Streaming ---
echo ""
echo "Streaming test (first 3 chunks):"
kubectl exec vllm-prefill -n $NAMESPACE -- curl -sN --max-time 30 \
    "http://$ROUTER_IP:30000/v1/chat/completions" \
    -H "Content-Type: application/json" \
    -d "{\"model\":\"$MODEL_NAME\",\"messages\":[{\"role\":\"user\",\"content\":\"Say hello\"}],\"max_tokens\":20,\"stream\":true}" 2>/dev/null | head -5

echo ""
echo "=== Results: $PASS passed, $FAIL failed ==="
[ $FAIL -eq 0 ] && echo "All validations passed!" || echo "Some checks failed — review above."
exit $FAIL
