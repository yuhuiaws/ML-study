#!/usr/bin/env bash
# troubleshoot.sh — Diagnostics for vLLM 1P1D DeepSeek-V4-Pro deployment
#
# Usage: bash troubleshoot.sh [--mode mooncake|nixl]

set -euo pipefail

MODE="${1:---mooncake}"
MODE="${MODE#--}"
NAMESPACE="vllm-pd"

echo "=== vLLM 1P1D Troubleshooting Diagnostics ==="
echo "Mode: $MODE | Namespace: $NAMESPACE"
echo "Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo ""

# --- Pod status ---
echo "━━━ Pod Status ━━━"
kubectl get pods -n $NAMESPACE -o wide 2>/dev/null || echo "Cannot reach cluster"
echo ""

# --- Recent events ---
echo "━━━ Recent Events ━━━"
kubectl get events -n $NAMESPACE --sort-by='.lastTimestamp' 2>/dev/null | tail -10
echo ""

# --- Prefill diagnostics ---
echo "━━━ Prefill Last 30 Lines ━━━"
kubectl logs vllm-prefill -n $NAMESPACE --tail=30 2>/dev/null || echo "Prefill pod not found"
echo ""

# --- Decode diagnostics ---
echo "━━━ Decode Last 30 Lines ━━━"
kubectl logs vllm-decode -n $NAMESPACE --tail=30 2>/dev/null || echo "Decode pod not found"
echo ""

# --- Error patterns ---
echo "━━━ Error Patterns ━━━"

echo "  [Prefill errors]"
kubectl logs vllm-prefill -n $NAMESPACE 2>/dev/null | grep -iE "ERROR|FATAL|OOM|illegal memory|Bad address|failed" | tail -10 || echo "  (none)"
echo ""

echo "  [Decode errors]"
kubectl logs vllm-decode -n $NAMESPACE 2>/dev/null | grep -iE "ERROR|FATAL|OOM|illegal memory|Bad address|failed" | tail -10 || echo "  (none)"
echo ""

# --- Mode-specific checks ---
if [ "$MODE" == "mooncake" ]; then
    echo "━━━ Mooncake-Specific ━━━"
    echo "  EFA transport status:"
    kubectl logs vllm-prefill -n $NAMESPACE 2>/dev/null | grep -E "EFA transport|EFA device|fi_mr_regattr|Bad address|mooncake_protocol" | head -10 || echo "  (no EFA logs)"
    echo ""
    echo "  Bootstrap registration:"
    kubectl logs vllm-prefill -n $NAMESPACE 2>/dev/null | grep -E "Registering|register.*engine_id|bootstrap" | tail -5 || echo "  (none)"
    echo ""
    echo "  Router/Proxy:"
    kubectl logs vllm-router -n $NAMESPACE --tail=10 2>/dev/null || echo "  Router not running"
else
    echo "━━━ NIXL-Specific ━━━"
    echo "  NIXL availability:"
    kubectl logs vllm-prefill -n $NAMESPACE 2>/dev/null | grep -iE "NIXL|nixl" | head -10 || echo "  (no NIXL logs)"
    echo ""
    echo "  Side channel:"
    kubectl exec vllm-prefill -n $NAMESPACE -- ss -tln 2>/dev/null | grep -E "5557|5558" || echo "  Side channel ports not listening"
    echo ""
    echo "  NIXL errors:"
    kubectl logs vllm-prefill -n $NAMESPACE 2>/dev/null | grep -i "NIXL_ERR" | tail -5 || echo "  (none)"
fi

# --- Resource usage ---
echo ""
echo "━━━ GPU Memory (Prefill) ━━━"
kubectl exec vllm-prefill -n $NAMESPACE -- nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv,noheader 2>/dev/null || echo "Cannot query GPU"
echo ""

echo "━━━ GPU Memory (Decode) ━━━"
kubectl exec vllm-decode -n $NAMESPACE -- nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv,noheader 2>/dev/null || echo "Cannot query GPU"

echo ""
echo "━━━ Common Fixes ━━━"
echo "  • fi_mr_regattr Bad address → modprobe efa_nv_peermem on host + remove expandable_segments"
echo "  • Triton OOM → lower --max-model-len (try 32768) + --gpu-memory-utilization 0.90"
echo "  • CUDA illegal memory access → add --enforce-eager to decode"
echo "  • NIXL_ERR_BACKEND on startup → non-fatal, vLLM handles fallback"
echo "  • Missing transfer_id → use mooncake_connector_proxy.py, not vllm-router"
echo "  • Stale engine_id → restart proxy after prefill restart"
