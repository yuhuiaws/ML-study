#!/usr/bin/env bash
# deploy_mooncake.sh — Deploy vLLM 1P1D DeepSeek-V4-Pro with Mooncake+EFA
#
# Usage:
#   export IMAGE=<your-ecr>/vllm-mooncake-efa:v0.20.1-r5
#   bash deploy_mooncake.sh [--max-model-len 32768] [--manifest-dir ./manifests]
#
# Prerequisites:
#   - Nodes labeled: kubectl label node <n1> vllm/role=prefill; kubectl label node <n2> vllm/role=decode
#   - Model downloaded to /opt/dlami/nvme/DeepSeek-V4-Pro on both nodes
#   - efa_nv_peermem loaded on both nodes
#   - vm.max_map_count=16777216 on both nodes

set -euo pipefail

IMAGE="${IMAGE:?Set IMAGE env var to your ECR image URI}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-32768}"
MANIFEST_DIR="${MANIFEST_DIR:-./manifests-mooncake}"
NAMESPACE="vllm-pd"

echo "=== vLLM 1P1D Mooncake+EFA Deployment ==="
echo "Image: $IMAGE"
echo "Max model len: $MAX_MODEL_LEN"
echo ""

# --- Get node IPs ---
echo "[1/6] Getting node IPs..."
PREFILL_IP=$(kubectl get node -l vllm/role=prefill -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
DECODE_IP=$(kubectl get node -l vllm/role=decode -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')

if [ -z "$PREFILL_IP" ] || [ -z "$DECODE_IP" ]; then
    echo "ERROR: Cannot find nodes with labels vllm/role=prefill and vllm/role=decode"
    echo "Label them first: kubectl label node <node> vllm/role=prefill"
    exit 1
fi
echo "  Prefill: $PREFILL_IP"
echo "  Decode:  $DECODE_IP"

# --- Generate manifests ---
echo "[2/6] Generating manifests..."
python3 "$(dirname "$0")/generate_manifests.py" \
    --mode mooncake \
    --prefill-ip "$PREFILL_IP" \
    --decode-ip "$DECODE_IP" \
    --image "$IMAGE" \
    --max-model-len "$MAX_MODEL_LEN" \
    --output-dir "$MANIFEST_DIR"

# --- Deploy namespace + configmap ---
echo "[3/6] Deploying namespace and configmap..."
kubectl apply -f "$MANIFEST_DIR/00-namespace.yaml"
kubectl apply -f "$MANIFEST_DIR/01-configmap.yaml"

# --- Deploy Prefill ---
echo "[4/6] Deploying Prefill pod (wait for API on :8001)..."
kubectl apply -f "$MANIFEST_DIR/02-prefill-pod.yaml"

echo "  Waiting for Prefill to be ready (this takes 3-5 minutes for model loading + warmup)..."
for i in $(seq 1 120); do
    if kubectl exec vllm-prefill -n "$NAMESPACE" -- ss -tln 2>/dev/null | grep -q ":8001 "; then
        echo "  ✅ Prefill API ready on :8001"
        break
    fi
    if [ $i -eq 120 ]; then
        echo "  ❌ Prefill not ready after 10 minutes. Check logs:"
        echo "     kubectl logs vllm-prefill -n $NAMESPACE --tail=50"
        exit 1
    fi
    sleep 5
done

# --- Deploy Decode ---
echo "[5/6] Deploying Decode pod (wait for API on :8002)..."
kubectl apply -f "$MANIFEST_DIR/03-decode-pod.yaml"

echo "  Waiting for Decode to be ready..."
for i in $(seq 1 120); do
    if kubectl exec vllm-decode -n "$NAMESPACE" -- ss -tln 2>/dev/null | grep -q ":8002 "; then
        echo "  ✅ Decode API ready on :8002"
        break
    fi
    if [ $i -eq 120 ]; then
        echo "  ❌ Decode not ready after 10 minutes. Check logs:"
        echo "     kubectl logs vllm-decode -n $NAMESPACE --tail=50"
        exit 1
    fi
    sleep 5
done

# --- Deploy Router/Proxy ---
echo "[6/6] Deploying Mooncake proxy..."
kubectl apply -f "$MANIFEST_DIR/04-router-pod.yaml"
kubectl apply -f "$MANIFEST_DIR/05-router-service.yaml" 2>/dev/null || true
sleep 5

echo ""
echo "=== Deployment Complete ==="
echo ""
echo "Quick validation:"
echo "  # Health check"
echo "  kubectl exec vllm-prefill -n $NAMESPACE -- curl -s http://localhost:8001/health"
echo ""
echo "  # Test inference via proxy"
echo "  ROUTER_IP=\$(kubectl get svc vllm-router -n $NAMESPACE -o jsonpath='{.spec.clusterIP}' 2>/dev/null || echo $PREFILL_IP)"
echo "  kubectl exec vllm-prefill -n $NAMESPACE -- curl -s http://\$ROUTER_IP:30000/v1/chat/completions \\"
echo "    -H 'Content-Type: application/json' \\"
echo "    -d '{\"model\":\"/models/DeepSeek-V4-Pro\",\"messages\":[{\"role\":\"user\",\"content\":\"Hello\"}],\"max_tokens\":20}'"
echo ""
echo "  # Check Mooncake EFA is active"
echo "  kubectl logs vllm-prefill -n $NAMESPACE | grep 'EFA transport installed'"
