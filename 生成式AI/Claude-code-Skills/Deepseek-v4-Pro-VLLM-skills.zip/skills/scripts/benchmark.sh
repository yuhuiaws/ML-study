#!/usr/bin/env bash
# benchmark.sh — Run vLLM bench serve for 1P1D DeepSeek-V4-Pro
#
# Usage:
#   bash benchmark.sh [--mode mooncake|nixl] [--num-prompts 100] [--input-len 1024] [--output-len 256] [--rate 4]

set -euo pipefail

MODE="mooncake"
NUM_PROMPTS=100
INPUT_LEN=1024
OUTPUT_LEN=256
REQUEST_RATE=4
NAMESPACE="vllm-pd"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode) MODE="$2"; shift 2;;
        --num-prompts) NUM_PROMPTS="$2"; shift 2;;
        --input-len) INPUT_LEN="$2"; shift 2;;
        --output-len) OUTPUT_LEN="$2"; shift 2;;
        --rate) REQUEST_RATE="$2"; shift 2;;
        *) shift;;
    esac
done

ROUTER_IP=$(kubectl get svc vllm-router -n $NAMESPACE -o jsonpath='{.spec.clusterIP}' 2>/dev/null)
if [ -z "$ROUTER_IP" ]; then
    ROUTER_IP=$(kubectl get node -l vllm/role=prefill -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
fi

MODEL="/models/DeepSeek-V4-Pro"
[ "$MODE" == "nixl" ] && MODEL="deepseek-ai/DeepSeek-V4-Pro"

echo "=== vLLM Bench Serve ==="
echo "Mode: $MODE | Router: $ROUTER_IP:30000"
echo "Prompts: $NUM_PROMPTS | Input: $INPUT_LEN | Output: $OUTPUT_LEN | Rate: $REQUEST_RATE req/s"
echo ""

kubectl exec vllm-prefill -n $NAMESPACE -- vllm bench serve \
    --backend openai-chat \
    --base-url "http://$ROUTER_IP:30000" \
    --endpoint /v1/chat/completions \
    --model "$MODEL" \
    --dataset-name random \
    --num-prompts "$NUM_PROMPTS" \
    --random-input-len "$INPUT_LEN" \
    --random-output-len "$OUTPUT_LEN" \
    --request-rate "$REQUEST_RATE" \
    --trust-remote-code
