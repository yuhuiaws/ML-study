#!/usr/bin/env bash
# deploy_nixl.sh — Deploy vLLM 1P1D DeepSeek-V4-Pro with NIXL connector
#
# Usage:
#   export IMAGE=<your-ecr>/vllm-nixl-efa:v0.20.1-r1
#   bash deploy_nixl.sh [--backend UCX|LIBFABRIC]
#
# Prerequisites:
#   - Nodes labeled: kubectl label node <n1> vllm/role=prefill; kubectl label node <n2> vllm/role=decode
#   - Model downloaded to /opt/dlami/nvme/DeepSeek-V4-Pro on both nodes

set -euo pipefail

IMAGE="${IMAGE:?Set IMAGE env var to your ECR image URI}"
NIXL_BACKEND="${NIXL_BACKEND:-UCX}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-131072}"
MANIFEST_DIR="${MANIFEST_DIR:-./manifests-nixl}"
NAMESPACE="vllm-pd"

echo "=== vLLM 1P1D NIXL Deployment ==="
echo "Image: $IMAGE"
echo "Backend: $NIXL_BACKEND"
echo "Max model len: $MAX_MODEL_LEN"
echo ""

# --- Get node IPs ---
echo "[1/5] Getting node IPs..."
PREFILL_IP=$(kubectl get node -l vllm/role=prefill -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
DECODE_IP=$(kubectl get node -l vllm/role=decode -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')

if [ -z "$PREFILL_IP" ] || [ -z "$DECODE_IP" ]; then
    echo "ERROR: Cannot find nodes with labels vllm/role=prefill and vllm/role=decode"
    exit 1
fi
echo "  Prefill: $PREFILL_IP"
echo "  Decode:  $DECODE_IP"

# --- Generate manifests ---
echo "[2/5] Generating manifests..."
python3 "$(dirname "$0")/generate_manifests.py" \
    --mode nixl \
    --prefill-ip "$PREFILL_IP" \
    --decode-ip "$DECODE_IP" \
    --image "$IMAGE" \
    --max-model-len "$MAX_MODEL_LEN" \
    --nixl-backend "$NIXL_BACKEND" \
    --output-dir "$MANIFEST_DIR"

# --- Deploy namespace + configmap ---
echo "[3/5] Deploying namespace and configmap..."
kubectl apply -f "$MANIFEST_DIR/00-namespace.yaml"
kubectl apply -f "$MANIFEST_DIR/01-configmap.yaml"

# --- Deploy Prefill ---
echo "[4/5] Deploying Prefill pod..."
kubectl apply -f "$MANIFEST_DIR/02-prefill-pod.yaml"

echo "  Waiting for Prefill API on :8001 (3-5 minutes)..."
for i in $(seq 1 120); do
    if kubectl exec vllm-prefill -n "$NAMESPACE" -- ss -tln 2>/dev/null | grep -q ":8001 "; then
        echo "  ✅ Prefill ready"
        break
    fi
    [ $i -eq 120 ] && { echo "  ❌ Timeout"; exit 1; }
    sleep 5
done

# --- Deploy Decode ---
echo "[4/5] Deploying Decode pod..."
kubectl apply -f "$MANIFEST_DIR/03-decode-pod.yaml"

echo "  Waiting for Decode API on :8002..."
for i in $(seq 1 120); do
    if kubectl exec vllm-decode -n "$NAMESPACE" -- ss -tln 2>/dev/null | grep -q ":8002 "; then
        echo "  ✅ Decode ready"
        break
    fi
    [ $i -eq 120 ] && { echo "  ❌ Timeout"; exit 1; }
    sleep 5
done

# --- Deploy Router ---
echo "[5/5] Deploying vllm-router..."
kubectl apply -f "$MANIFEST_DIR/04-router-pod.yaml"
sleep 5

echo ""
echo "=== Deployment Complete ==="
echo ""
echo "Test:"
echo "  curl http://$PREFILL_IP:30000/v1/chat/completions \\"
echo "    -H 'Content-Type: application/json' \\"
echo "    -d '{\"model\":\"deepseek-ai/DeepSeek-V4-Pro\",\"messages\":[{\"role\":\"user\",\"content\":\"Hello\"}],\"max_tokens\":20}'"
