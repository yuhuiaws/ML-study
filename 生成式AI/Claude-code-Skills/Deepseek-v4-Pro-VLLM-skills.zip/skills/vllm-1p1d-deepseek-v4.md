---
name: vllm-1p1d-deepseek-v4
description: Deploy DeepSeek-V4-Pro on AWS EKS with vLLM 1P1D (Prefill-Decode Disaggregation) using either Mooncake+EFA or NIXL connector. Includes image building, K8s manifest generation, deployment automation, validation, and troubleshooting.
---

# vLLM 1P1D DeepSeek-V4-Pro Deployment Skill

Deploy DeepSeek-V4-Pro (1.6T total / 49B active, FP4+FP8, ~864GB) on AWS EKS HyperPod with 1P1D architecture.

## Environment

- **Cluster**: AWS SageMaker HyperPod EKS
- **Nodes**: 2× ml.p5en.48xlarge (8×H200 141GB / node, 16× EFA NICs / node)
- **Architecture**: 1P1D (Prefill-Decode Disaggregation), DP=8 + Expert Parallel
- **KV Transfer Options**:
  - **Mooncake+EFA**: Best throughput (~347 GB/s cross-node), uses `mooncake_connector_proxy.py`
  - **NIXL (UCX or LIBFABRIC)**: NVIDIA standard toolchain, uses `vllm-router` (Rust)

## When to Use

Use this skill when:
- Deploying DeepSeek-V4-Pro on EKS with P/D disaggregation
- Generating K8s manifests for vLLM 1P1D
- Building Docker images with EFA + DeepGEMM support
- Troubleshooting vLLM 1P1D deployment issues (EFA, Mooncake, NIXL, OOM, cudagraph)
- Running benchmarks on the deployed cluster

## Decision: Mooncake vs NIXL

| Criteria | Mooncake+EFA | NIXL |
|----------|-------------|------|
| KV Transfer bandwidth | **347 GB/s** (87% peak) | ~same as TCP, EFA not fully utilized |
| Router | `mooncake_connector_proxy.py` (Python) | `vllm-router` (Rust, official) |
| Proxy restart dependency | Proxy must restart with Prefill | Independent |
| PYTORCH_CUDA_ALLOC_CONF | **Cannot** use `expandable_segments:True` | Can use `expandable_segments:True` |
| Decode cudagraph | Unstable (use --enforce-eager) | Works (`--max-cudagraph-capture-size 1024`) |
| Maturity on EFA | Production-proven | Known `NIXL_ERR_BACKEND` (non-fatal) |

**Recommendation**: Use Mooncake+EFA for max throughput; NIXL for NVIDIA ecosystem alignment.

## Key Constraints (Both Approaches)

1. **DeepGEMM is MANDATORY** — FP4 MoE compute kernel, without it output is garbled
2. **`--block-size 256`** — DeepSeek-V4 sparse MLA indexer hard requirement
3. **`--kv-cache-dtype fp8`** — Required for the mixed precision model
4. **`--gpu-memory-utilization 0.90`** — Higher causes Triton JIT OOM
5. **`--max-num-batched-tokens 512`** — H200 limit
6. **`efa_nv_peermem` kernel module** — Must be loaded on host for GPU RDMA (Mooncake only)
7. **`vm.max_map_count=16777216`** — Host sysctl for multi-NIC MR registration

## Scripts

Helper scripts are in `skills/scripts/`:
- `prereq_check.sh` — Validate node prerequisites (EFA, GPU, kernel modules, sysctl)
- `deploy_mooncake.sh` — Full deployment flow for Mooncake+EFA approach
- `deploy_nixl.sh` — Full deployment flow for NIXL approach
- `validate.sh` — Post-deployment validation (health, streaming, KV transfer)
- `benchmark.sh` — Run vllm bench serve
- `generate_manifests.py` — Generate K8s YAML manifests from parameters
- `troubleshoot.sh` — Common diagnostics

## Troubleshooting Quick Reference

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| `fi_mr_regattr failed ... Bad address` | Missing `efa_nv_peermem` or `expandable_segments:True` | Load module; remove env var |
| `Missing transfer_id in kv_transfer_params` | Using vllm-router with Mooncake | Switch to mooncake_connector_proxy.py |
| `Failed to find remote engine_id` | Proxy cached stale ID after Prefill restart | Restart proxy after prefill |
| `CUDA error: illegal memory access` (decode) | cudagraph + EP conflict | Add `--enforce-eager` to decode |
| `Triton Error [CUDA]: out of memory` | max-model-len too high | Lower to 32768, gpu-util to 0.90 |
| `NIXL_ERR_BACKEND` on startup | DP=8 engine_id handshake race | Non-fatal, vLLM fallback handles it |
| Output garbled/nonsense | DeepGEMM not installed | Rebuild image with DeepGEMM |
| `The Mooncake Transfer Engine is using tcp` | `mooncake_protocol=efa` not passed | Check `--kv-transfer-config` JSON |
