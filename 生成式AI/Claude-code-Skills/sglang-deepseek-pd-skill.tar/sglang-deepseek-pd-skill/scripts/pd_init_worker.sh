#!/bin/bash
# Initialize a DLC worker for sglang 1P1D PD disaggregation with nixl LIBFABRIC on EFA.
#
# Container image: public.ecr.aws/deep-learning-containers/sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci
# Pre-installed: sglang 0.5.8, Python 3.12, PyTorch, CUDA 12.9
# This script adds: nixl (KV transfer), sglang-router, EFA verification, optional GDRCopy.
#
# No UCCL-EP or deep_ep — MoE communication (if any) uses NCCL over NVLink (intra-node).
#
# Usage: Run inside each worker pod before launching PD servers.
#   bash pd_init_worker.sh [--with-gdrcopy]
#
# Options:
#   --with-gdrcopy   Install GDRCopy userspace library from NVIDIA upstream.
#                    Not required for nixl LIBFABRIC/UCX, but can improve performance.
#
# Prerequisites:
#   - FSx mounted at /fsx
#   - Pod has GPU + EFA resources allocated
set -e
export DEBIAN_FRONTEND=noninteractive

INSTALL_GDRCOPY=false
for arg in "$@"; do
  case "$arg" in
    --with-gdrcopy) INSTALL_GDRCOPY=true ;;
  esac
done

echo ">>> [$(hostname)] PD Worker Init - Start (GDRCopy: $INSTALL_GDRCOPY)"
echo ">>> Python: $(python3 --version 2>&1)"
echo ">>> PyTorch: $(python3 -c 'import torch; print(torch.__version__)' 2>&1)"
echo ">>> CUDA: $(nvcc --version 2>&1 | grep release || echo 'nvcc not found')"

# ---- Step 1: System dependencies ----
echo ">>> [$(hostname)] Step 1: System dependencies"
apt-get update -qq
apt-get install -y -qq \
  build-essential git curl wget \
  rdma-core libibverbs-dev libnuma-dev librdmacm-dev \
  libhwloc-dev libevent-dev \
  pciutils iproute2 2>&1 | tail -2
echo ">>> [$(hostname)] System deps done"

# ---- Step 2: EFA verification / installation ----
echo ">>> [$(hostname)] Step 2: EFA"
export EFA_HOME=/opt/amazon/efa
export CUDA_HOME=/usr/local/cuda

if [ -f "$EFA_HOME/bin/fi_info" ]; then
  echo ">>> [$(hostname)] EFA already installed: $($EFA_HOME/bin/fi_info --version 2>&1)"
else
  echo ">>> [$(hostname)] Installing EFA..."
  cd /tmp
  curl -sO https://efa-installer.amazonaws.com/aws-efa-installer-1.42.0.tar.gz
  tar -xf aws-efa-installer-1.42.0.tar.gz
  cd aws-efa-installer
  ./efa_installer.sh -y --skip-kmod -g --no-verify 2>&1 | tail -3
  echo ">>> [$(hostname)] EFA installed: $($EFA_HOME/bin/fi_info --version 2>&1)"
fi

export LD_LIBRARY_PATH=/usr/local/lib:$EFA_HOME/lib:$EFA_HOME/lib64:/opt/amazon/ofi-nccl/lib/x86_64-linux-gnu:$CUDA_HOME/lib64:$LD_LIBRARY_PATH
export PATH=$EFA_HOME/bin:$CUDA_HOME/bin:$PATH

# ---- Step 3: Install nixl + sglang-router ----
echo ">>> [$(hostname)] Step 3: Install nixl + sglang-router"
pip install nixl-cu12==0.10.0 sglang-router==0.3.2 2>&1 | tail -3
echo ">>> [$(hostname)] nixl + sglang-router installed"

# ---- Step 4 (optional): GDRCopy userspace library ----
if [ "$INSTALL_GDRCOPY" = true ]; then
  echo ">>> [$(hostname)] Step 4: Installing GDRCopy from NVIDIA upstream"
  if [ -f /usr/local/lib/libgdrapi.so ]; then
    echo ">>> [$(hostname)] GDRCopy already installed"
  else
    cd /tmp
    if [ ! -d gdrcopy ]; then
      git clone https://github.com/NVIDIA/gdrcopy.git
    fi
    cd gdrcopy
    make -j$(nproc) lib lib_install PREFIX=/usr/local CUDA=$CUDA_HOME 2>&1 | tail -3
    ldconfig
    echo ">>> [$(hostname)] GDRCopy installed: $(ls /usr/local/lib/libgdrapi.so)"
  fi
else
  echo ">>> [$(hostname)] Step 4: GDRCopy skipped (use --with-gdrcopy to install)"
fi

# ---- Step 5: Fix hostname resolution ----
echo ">>> [$(hostname)] Step 5: Fix hostname resolution"
MYIP=$(ip addr show | grep "inet 10\." | head -1 | awk '{print $2}' | cut -d/ -f1)
MYHOST=$(hostname)
if [ -n "$MYIP" ]; then
  if ! grep -q "^${MYIP}.*${MYHOST}" /etc/hosts 2>/dev/null; then
    echo "$MYIP $MYHOST" >> /etc/hosts
  fi
  echo ">>> [$(hostname)] Hostname: $MYHOST -> $MYIP"
else
  echo ">>> [$(hostname)] WARNING: No 10.x.x.x IP found, hostname fix skipped"
fi

# ---- Step 6: Cache directories ----
echo ">>> [$(hostname)] Step 6: Cache directories"
mkdir -p /fsx/triton-cache /fsx/flashinfer-cache /fsx/torchinductor-cache
mkdir -p /fsx/deep_gemm_cache/cache /fsx/deep_gemm_cache/tmp

# DeepGEMM JIT ignores DG_JIT_CACHE_DIR in this DLC version — it always writes to
# ~/.cache/deep_gemm/. Symlink it to shared FSx so compiled kernels persist across
# restarts and are shared between prefill/decode (decode kernels ⊂ prefill kernels).
if [ ! -L /root/.cache/deep_gemm ]; then
  rm -rf /root/.cache/deep_gemm
  mkdir -p /root/.cache
  ln -sf /fsx/deep_gemm_cache /root/.cache/deep_gemm
  echo ">>> [$(hostname)] Symlinked /root/.cache/deep_gemm -> /fsx/deep_gemm_cache"
else
  echo ">>> [$(hostname)] DeepGEMM cache symlink already exists"
fi

# ---- Step 7: Patch sglang nixl conn.py for LIBFABRIC backend support ----
# SGLang 0.5.8 creates nixl_agent without passing nixl_agent_config, so nixl
# always defaults to UCX backend regardless of SGLANG_DISAGGREGATION_NIXL_BACKEND.
# This patch makes conn.py read the env var and pass backends=['LIBFABRIC'] to nixl.
echo ">>> [$(hostname)] Step 7: Patch sglang nixl conn.py for LIBFABRIC backend"
CONN_PY=$(python3 -c "import sglang; import os; print(os.path.join(os.path.dirname(sglang.__file__), 'srt/disaggregation/nixl/conn.py'))" 2>/dev/null)
if [ -f "$CONN_PY" ]; then
  # Only patch if not already patched
  if ! grep -q "nixl_agent_config" "$CONN_PY"; then
    # Add nixl_agent_config to the import line
    sed -i 's/from nixl._api import nixl_agent$/from nixl._api import nixl_agent, nixl_agent_config/' "$CONN_PY"
    # Replace agent creation to read env var and pass config
    sed -i 's/self\.agent = nixl_agent(str(uuid\.uuid4()))/import os; _backends = os.environ.get("SGLANG_DISAGGREGATION_NIXL_BACKEND", "UCX").split(","); _conf = nixl_agent_config(backends=_backends); self.agent = nixl_agent(str(uuid.uuid4()), nixl_conf=_conf)/' "$CONN_PY"
    echo ">>> [$(hostname)] Patched $CONN_PY for LIBFABRIC backend support"
  else
    echo ">>> [$(hostname)] conn.py already patched"
  fi
else
  echo ">>> [$(hostname)] WARNING: conn.py not found at expected path"
fi

# ---- Verify ----
echo ""
echo ">>> [$(hostname)] Verification:"
echo "  Python:       $(python3 --version 2>&1)"
echo "  PyTorch:      $(python3 -c 'import torch; print(torch.__version__)' 2>&1)"
echo "  SGLang:       $(python3 -c 'import sglang; print(sglang.__version__)' 2>&1)"
echo "  nixl:         $(python3 -c 'import nixl; print("OK")' 2>&1)"
echo "  sglang-router:$(python3 -c 'import sglang_router; print("OK")' 2>&1)"
echo "  EFA:          $($EFA_HOME/bin/fi_info -p efa -l 2>&1 | head -1 || echo 'N/A')"
echo "  GPUs:         $(python3 -c 'import torch; print(torch.cuda.device_count())' 2>&1)"
echo "  GDRCopy:      $(ls /usr/local/lib/libgdrapi.so 2>/dev/null && echo 'installed' || echo 'not installed (optional)')"
echo ""
echo ">>> [$(hostname)] PD WORKER INIT COMPLETE"
