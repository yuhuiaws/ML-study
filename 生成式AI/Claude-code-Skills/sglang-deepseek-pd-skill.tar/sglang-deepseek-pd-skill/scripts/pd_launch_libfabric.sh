#!/bin/bash
# Launch sglang 1P1D (Prefill-Decode disaggregation) with nixl LIBFABRIC backend on EFA.
#
# Architecture:
#   Node0: Prefill server (TP GPUs) + sglang_router
#   Node1: Decode server  (TP GPUs)
#   KV cache transfer: nixl LIBFABRIC backend (EFA RDMA)
#
# No UCCL-EP or deep_ep — MoE (if any) uses NCCL over NVLink (intra-node only).
# GDRCopy is optional: if installed, auto-detected and PYTORCH_CUDA_ALLOC_CONF unset.
#
# Usage: pd_launch_libfabric.sh <role> <prefill_addr> <decode_addr> [model_path] [tp]
#   role:          prefill | decode | router
#   prefill_addr:  IP of prefill node (10.x.x.x)
#   decode_addr:   IP of decode node  (10.x.x.x)
#   model_path:    path to model (default: /fsx/models/Qwen3-8B)
#   tp:            tensor parallelism degree (default: 1)
#
# Examples:
#   # Qwen3-8B, TP=1 (1 GPU per role):
#   pd_launch_libfabric.sh prefill 10.4.38.23 10.4.44.17 /fsx/models/Qwen3-8B 1
#   pd_launch_libfabric.sh decode  10.4.38.23 10.4.44.17 /fsx/models/Qwen3-8B 1
#   pd_launch_libfabric.sh router  10.4.38.23 10.4.44.17
#
#   # DeepSeek-V2, TP=8 (8 GPU per role):
#   pd_launch_libfabric.sh prefill 10.4.38.23 10.4.44.17 /fsx/models/DeepSeek-V2 8
#   pd_launch_libfabric.sh decode  10.4.38.23 10.4.44.17 /fsx/models/DeepSeek-V2 8
#   pd_launch_libfabric.sh router  10.4.38.23 10.4.44.17
set -e

ROLE=${1:?Usage: $0 <prefill|decode|router> <prefill_addr> <decode_addr> [model_path] [tp]}
PREFILL_ADDR=${2:?Usage: $0 <prefill|decode|router> <prefill_addr> <decode_addr> [model_path] [tp]}
DECODE_ADDR=${3:?Usage: $0 <prefill|decode|router> <prefill_addr> <decode_addr> [model_path] [tp]}
MODEL_PATH=${4:-/fsx/models/Qwen3-8B}
TP=${5:-1}

# =============================================
# Environment: EFA + NCCL
# =============================================
export CUDA_HOME=/usr/local/cuda
export EFA_HOME=/opt/amazon/efa
export LD_LIBRARY_PATH=/usr/local/lib:$EFA_HOME/lib:$EFA_HOME/lib64:/opt/amazon/ofi-nccl/lib/x86_64-linux-gnu:$CUDA_HOME/lib64:$LD_LIBRARY_PATH
export PATH=$EFA_HOME/bin:$CUDA_HOME/bin:$PATH

export NCCL_SOCKET_IFNAME=enp
export NCCL_NET_PLUGIN=libnccl-net-ofi.so
export FI_PROVIDER=efa
export FI_EFA_USE_DEVICE_RDMA=1
export NCCL_PROTO=Simple

# =============================================
# Environment: nixl LIBFABRIC backend
# =============================================
export SGLANG_DISAGGREGATION_NIXL_BACKEND=LIBFABRIC

# libfabric tuning for EFA
export FI_EFA_FORK_SAFE=1
export FI_EFA_USE_HUGE_PAGE=0
export FI_MR_CACHE_MONITOR=disabled

# Logging
export FI_LOG_LEVEL=warn
export NIXL_LOG_LEVEL=info

# UCX interface binding — nixl initializes both UCX and LIBFABRIC backends.
# UCX must bind to the correct 10.x.x.x EFA interface, not 169.254.0.1 (veth_def_agent).
UCX_IF=$(ip -o addr show | grep "inet 10\." | awk '{print $2}' | head -1)
if [ -n "$UCX_IF" ]; then
  export UCX_NET_DEVICES=${UCX_IF}
fi

# =============================================
# GDRCopy: optional performance optimization
# If libgdrapi.so is installed, unset expandable_segments (incompatible with gdr_pin_buffer).
# If not installed, nixl uses dmabuf path — expandable_segments is safe to keep.
# =============================================
if [ -f /usr/local/lib/libgdrapi.so ] || ldconfig -p 2>/dev/null | grep -q libgdrapi; then
  echo ">>> GDRCopy detected — unsetting PYTORCH_CUDA_ALLOC_CONF for gdr_pin_buffer compatibility"
  unset PYTORCH_CUDA_ALLOC_CONF
else
  echo ">>> GDRCopy not installed — using dmabuf path (expandable_segments OK)"
fi

# =============================================
# JIT caches (shared FSx, persist across restarts)
# =============================================
# --- Fix missing cuobjdump in DLC (DeepGEMM JIT needs it to extract kernel symbols) ---
if ! command -v cuobjdump &>/dev/null; then
  TRITON_CUOBJDUMP=$(python3 -c "import triton; import os; print(os.path.join(os.path.dirname(triton.__file__), 'backends/nvidia/bin/cuobjdump'))" 2>/dev/null)
  if [ -f "$TRITON_CUOBJDUMP" ]; then
    ln -sf "$TRITON_CUOBJDUMP" /usr/local/cuda/bin/cuobjdump
    echo ">>> Fixed: symlinked cuobjdump from Triton to CUDA bin"
  fi
fi

# NOTE: DG_JIT_CACHE_DIR is ignored by the DeepGEMM version in this DLC image.
# DeepGEMM always writes to ~/.cache/deep_gemm/cache/ regardless of this env var.
# The pd_init_worker.sh script symlinks ~/.cache/deep_gemm -> /fsx/deep_gemm_cache
# to persist compiled kernels on shared FSx. We keep this env var for forward
# compatibility in case a future DeepGEMM version reads it.
export DG_JIT_CACHE_DIR=/fsx/deep_gemm_cache
export TRITON_CACHE_DIR=/fsx/triton-cache
export FLASHINFER_CACHE_DIR=/fsx/flashinfer-cache
export FLASHINFER_CUBINS_REPOSITORY=/nonexistent
export TORCHINDUCTOR_CACHE_DIR=/fsx/torchinductor-cache

# Unbuffered Python output
export PYTHONUNBUFFERED=1

# =============================================
# Fix hostname resolution (HyperPod 172.18.x -> 10.x)
# =============================================
MYIP=$(ip addr show | grep "inet 10\." | head -1 | awk '{print $2}' | cut -d/ -f1)
if [ -n "$MYIP" ]; then
  if ! grep -q "^${MYIP}.*$(hostname)" /etc/hosts 2>/dev/null; then
    echo "$MYIP $(hostname)" >> /etc/hosts
  fi
fi

echo ">>> $ROLE: $(hostname) @ $MYIP"
echo ">>> prefill=$PREFILL_ADDR, decode=$DECODE_ADDR, model=$MODEL_PATH, tp=$TP"
echo ">>> nixl backend: LIBFABRIC (EFA RDMA)"

# =============================================
# Ports
# =============================================
PREFILL_PORT=30000
DECODE_PORT=30001
ROUTER_PORT=8000
BOOTSTRAP_PORT=8998

# =============================================
# Launch
# =============================================
case "$ROLE" in
  prefill)
    echo ">>> Starting Prefill server on port $PREFILL_PORT ..."
    python3 -m sglang.launch_server \
      --model-path "$MODEL_PATH" \
      --tp "$TP" \
      --ep "$TP" \
      --trust-remote-code \
      --disaggregation-mode prefill \
      --disaggregation-transfer-backend nixl \
      --disaggregation-bootstrap-port "$BOOTSTRAP_PORT" \
      --disaggregation-decode-tp "$TP" \
      --host 0.0.0.0 \
      --port "$PREFILL_PORT" \
      --mem-fraction-static 0.85 \
      --watchdog-timeout 1200
    ;;
  decode)
    echo ">>> Starting Decode server on port $DECODE_PORT ..."
    python3 -m sglang.launch_server \
      --model-path "$MODEL_PATH" \
      --tp "$TP" \
      --ep "$TP" \
      --trust-remote-code \
      --disaggregation-mode decode \
      --disaggregation-transfer-backend nixl \
      --disaggregation-bootstrap-port "$BOOTSTRAP_PORT" \
      --host 0.0.0.0 \
      --port "$DECODE_PORT" \
      --mem-fraction-static 0.85 \
      --watchdog-timeout 1200
    ;;
  router)
    echo ">>> Starting PD Router on port $ROUTER_PORT ..."
    echo ">>>   Prefill: http://${PREFILL_ADDR}:${PREFILL_PORT} (bootstrap: ${BOOTSTRAP_PORT})"
    echo ">>>   Decode:  http://${DECODE_ADDR}:${DECODE_PORT}"
    python3 -m sglang_router.launch_router \
      --pd-disaggregation \
      --prefill "http://${PREFILL_ADDR}:${PREFILL_PORT}" "$BOOTSTRAP_PORT" \
      --decode "http://${DECODE_ADDR}:${DECODE_PORT}" \
      --host 0.0.0.0 \
      --port "$ROUTER_PORT"
    ;;
  *)
    echo "Unknown role: $ROLE. Must be prefill, decode, or router."
    exit 1
    ;;
esac
