#!/bin/bash
# Benchmark sglang 1P1D PD disaggregation using sglang.bench_serving.
#
# Runs sglang.bench_serving at multiple request rates: 1, 2, 4, 8, 16, 32
# Uses random dataset with configurable input/output lengths.
#
# Usage: pd_bench_serving.sh [options]
#   --host HOST          Server host (default: 127.0.0.1)
#   --port PORT          Server port (default: 8000, i.e. the router port)
#   --model MODEL        Model path for API request payload
#   --num-prompts N      Number of prompts per rate level (default: 100)
#   --input-len N        Random input token length (default: 2048)
#   --output-len N       Random output token length (default: 256)
#   --range-ratio F      Random range ratio (default: 0.5)
#   --rates "1 2 4 ..."  Space-separated list of rates (default: "1 2 4 8 16 32")
#
# Examples:
#   # Benchmark PD router on localhost:8000 (default)
#   pd_bench_serving.sh --model /fsx/models/Qwen3-8B
#
#   # Benchmark with custom rates and port
#   pd_bench_serving.sh --model /fsx/models/DeepSeek-V2 --port 8000 --rates "1 4 16 32"
#
#   # Benchmark prefill server directly (skip router)
#   pd_bench_serving.sh --model /fsx/models/Qwen3-8B --port 30000 --rates "1 2 4 8"
set -e

# ---- Defaults ----
HOST="127.0.0.1"
PORT=8000
MODEL=""
NUM_PROMPTS=100
INPUT_LEN=2048
OUTPUT_LEN=256
RANGE_RATIO=0.5
RATES="1 2 4 8 16 32"

# ---- Parse arguments ----
while [[ $# -gt 0 ]]; do
  case "$1" in
    --host)        HOST="$2"; shift 2 ;;
    --port)        PORT="$2"; shift 2 ;;
    --model)       MODEL="$2"; shift 2 ;;
    --num-prompts) NUM_PROMPTS="$2"; shift 2 ;;
    --input-len)   INPUT_LEN="$2"; shift 2 ;;
    --output-len)  OUTPUT_LEN="$2"; shift 2 ;;
    --range-ratio) RANGE_RATIO="$2"; shift 2 ;;
    --rates)       RATES="$2"; shift 2 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ---- Build common args ----
COMMON_ARGS=(
  --backend sglang
  --host "$HOST"
  --port "$PORT"
  --dataset-name random
  --num-prompts "$NUM_PROMPTS"
  --random-input-len "$INPUT_LEN"
  --random-output-len "$OUTPUT_LEN"
  --random-range-ratio "$RANGE_RATIO"
)

if [ -n "$MODEL" ]; then
  COMMON_ARGS+=(--model "$MODEL")
fi

echo "============================================="
echo "sglang PD Disaggregation Benchmark"
echo "============================================="
echo "  Server:       ${HOST}:${PORT}"
echo "  Model:        ${MODEL:-'(auto)'}"
echo "  Num prompts:  $NUM_PROMPTS"
echo "  Input len:    $INPUT_LEN"
echo "  Output len:   $OUTPUT_LEN"
echo "  Range ratio:  $RANGE_RATIO"
echo "  Rates:        $RATES"
echo "============================================="
echo ""

# ---- Run benchmark at each rate ----
for rate in $RATES; do
  echo ">>> Rate=$rate (request-rate=$rate, max-concurrency=$rate)"
  echo "---------------------------------------------"

  python3 -m sglang.bench_serving \
    "${COMMON_ARGS[@]}" \
    --request-rate "$rate" \
    --max-concurrency "$rate"

  echo ""
  echo ">>> Rate=$rate done"
  echo "============================================="
  echo ""
done

echo ">>> All rates completed."
