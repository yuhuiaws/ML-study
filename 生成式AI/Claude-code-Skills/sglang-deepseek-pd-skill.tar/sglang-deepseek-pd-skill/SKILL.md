# SGLang DeepSeek-V3 PD Disaggregation on EFA

Deploy DeepSeek-V3 671B MoE (FP8) using SGLang's 1P1D Prefill-Decode disaggregation
with nixl LIBFABRIC backend on AWS EFA.

## Overview

Prefill-Decode (PD) disaggregation splits inference into two specialized servers:
- **Prefill server** (Node0, 8 GPU): compute-heavy, processes input tokens
- **Decode server** (Node1, 8 GPU): memory-bound, generates output tokens
- **Router** (Node0): PD-aware load balancer, routes requests to prefill then decode

KV cache is transferred from prefill to decode via **nixl** (NVIDIA's transfer library)
using the **LIBFABRIC backend** over EFA RDMA.

MoE expert communication (256 experts, top-8 routing) stays **intra-node only** via
NCCL over NVLink — no internode all-to-all needed. This avoids the EFA low-latency
bottleneck that limits NCCL EP internode throughput.

## Architecture

```
Node0 (8x H200):  Prefill server (TP=8 EP=8) ── NCCL NVLink (MoE intra-node)
                   sglang_router (port 8000)
                        │
                   nixl LIBFABRIC (KV cache transfer over EFA RDMA)
                        │
Node1 (8x H200):  Decode server  (TP=8 EP=8) ── NCCL NVLink (MoE intra-node)
```

Key difference from NCCL EP (TP=16 across 2 nodes): PD disaggregation eliminates
per-token internode MoE communication. The only cross-node data movement is KV cache
transfer (once per request, not once per token per layer).

## Test Environment

| Component | Details |
|-----------|---------|
| Instance | 2x p5en.48xlarge (SageMaker HyperPod EKS) |
| GPU | 8x H200 141GB per node (16 total) |
| EFA | 32x EFA per node |
| Container | `public.ecr.aws/deep-learning-containers/sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci` |
| SGLang | 0.5.8 |
| Python | 3.12 |
| PyTorch | 2.9.1+cu129 |
| CUDA | 12.9 |
| nixl | 0.10.0 (nixl-cu12) |
| sglang-router | 0.3.2 |
| Model | DeepSeek-V3 671B MoE FP8 (`/fsx/models/DeepSeek-V3`) |

## Quick Start

### 1. Initialize Worker Pods

Run on each worker pod (node0 and node1):

```bash
# Basic init (no GDRCopy)
bash scripts/pd_init_worker.sh

# With optional GDRCopy for performance
bash scripts/pd_init_worker.sh --with-gdrcopy
```

The DLC image already has sglang 0.5.8, nixl, sglang_router, and EFA pre-installed.
The init script adds system dependencies, verifies EFA, fixes hostname resolution,
and creates cache directories.

### 2. Get Node IPs

```bash
NODE0_IP=$(kubectl exec uccl-ep-node0 -- bash -c \
  "ip addr show | grep 'inet 10\.' | head -1 | awk '{print \$2}' | cut -d/ -f1")
NODE1_IP=$(kubectl exec uccl-ep-node1 -- bash -c \
  "ip addr show | grep 'inet 10\.' | head -1 | awk '{print \$2}' | cut -d/ -f1")
echo "Node0: $NODE0_IP, Node1: $NODE1_IP"
```

### 3. Launch Servers

```bash
# Copy launch script to both nodes
kubectl cp scripts/pd_launch_libfabric.sh uccl-ep-node0:/tmp/pd_launch_libfabric.sh
kubectl cp scripts/pd_launch_libfabric.sh uccl-ep-node1:/tmp/pd_launch_libfabric.sh

# Start prefill (node0)
kubectl exec uccl-ep-node0 -- bash -c \
  "nohup bash /tmp/pd_launch_libfabric.sh prefill $NODE0_IP $NODE1_IP /fsx/models/DeepSeek-V3 8 \
   > /tmp/pd_prefill.log 2>&1 &"

# Start decode (node1)
kubectl exec uccl-ep-node1 -- bash -c \
  "nohup bash /tmp/pd_launch_libfabric.sh decode $NODE0_IP $NODE1_IP /fsx/models/DeepSeek-V3 8 \
   > /tmp/pd_decode.log 2>&1 &"

# Wait for both servers to show "The server is fired up and ready to roll!"
# Model loading takes ~3 min, DeepGEMM JIT warmup can take 5-15 min (cold cache)
kubectl exec uccl-ep-node0 -- grep -c "fired up" /tmp/pd_prefill.log
kubectl exec uccl-ep-node1 -- grep -c "fired up" /tmp/pd_decode.log

# Start router (node0, after both servers are ready)
kubectl exec uccl-ep-node0 -- bash -c \
  "nohup bash /tmp/pd_launch_libfabric.sh router $NODE0_IP $NODE1_IP \
   > /tmp/pd_router.log 2>&1 &"
```

### 4. Verify

```bash
kubectl exec uccl-ep-node0 -- curl -s http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"/fsx/models/DeepSeek-V3","messages":[{"role":"user","content":"Say hello"}],"max_tokens":50}'
```

### 5. Run Benchmark

```bash
kubectl cp scripts/pd_bench_serving.sh uccl-ep-node0:/tmp/pd_bench_serving.sh
kubectl exec uccl-ep-node0 -- bash /tmp/pd_bench_serving.sh \
  --model /fsx/models/DeepSeek-V3 --port 8000 --rates "1 2 4 8 16 32"
```

## Benchmark Results

### Workload

- 100 prompts per rate level
- Random dataset: input ~2048 tokens, output ~256 tokens, range ratio 0.5
- Rates: 1, 2, 4, 8, 16, 32 req/s
- Benchmark tool: `sglang.bench_serving`

### Results: LIBFABRIC Backend (EFA RDMA)

Confirmed LIBFABRIC backend via logs: `"Backend LIBFABRIC was instantiated"`,
`"Selected backend: LIBFABRIC"`. Requires the conn.py patch (see Known Issues).

| Rate | Req/s | Output tok/s | Total tok/s | Mean E2E (ms) | Mean TTFT (ms) | Mean TPOT (ms) | P99 TPOT (ms) | Mean ITL (ms) | P99 ITL (ms) |
|------|------:|-------------:|------------:|--------------:|---------------:|---------------:|--------------:|--------------:|-------------:|
| 1    | 0.48  | 92           | 832         | 2,085         | 149            | 10.15          | 10.20         | 10.15         | 10.32        |
| 2    | 0.87  | 166          | 1,505       | 2,283         | 174            | 11.06          | 11.18         | 11.05         | 11.41        |
| 4    | 1.49  | 285          | 2,578       | 2,616         | 190            | 12.73          | 12.87         | 12.72         | 14.02        |
| 8    | 2.34  | 449          | 4,062       | 3,278         | 253            | 15.86          | 16.12         | 15.86         | 17.45        |
| 16   | 3.62  | 694          | 6,281       | 4,106         | 296            | 20.00          | 20.63         | 19.97         | 22.24        |
| 32   | 5.34  | 1,024        | 9,262       | 5,292         | 404            | 25.68          | 26.90         | 25.62         | 29.42        |

### Comparison: LIBFABRIC vs UCX Backend

SGLang 0.5.8's nixl integration defaults to UCX backend (see Known Issues).
Without the conn.py patch, nixl silently falls back to UCX (`rma_am(tcp)` over EFA — no true RDMA).
The table below shows the dramatic difference:

| Rate | TTFT LIBFABRIC (ms) | TTFT UCX (ms) | Improvement | Output tok/s LIBFABRIC | Output tok/s UCX | Improvement |
|------|--------------------:|--------------:|:-----------:|-----------------------:|-----------------:|:-----------:|
| 1    | **149**             | 498           | 3.3x        | **92**                 | 79               | +16%        |
| 2    | **174**             | 584           | 3.4x        | **166**                | 143              | +16%        |
| 4    | **190**             | 867           | 4.6x        | **285**                | 232              | +23%        |
| 8    | **253**             | 1,204         | 4.8x        | **449**                | 360              | +25%        |
| 16   | **296**             | 2,976         | 10.1x       | **694**                | 460              | +51%        |
| 32   | **404**             | 7,784         | **19.3x**   | **1,024**              | 484              | **+112%**   |

**Key findings**:
- **TTFT**: LIBFABRIC achieves 3-19x lower TTFT due to native EFA RDMA for KV cache transfer
- **Throughput**: 2.1x higher output throughput at rate=32 (1,024 vs 484 tok/s)
- **Scaling**: LIBFABRIC throughput continues scaling at rate=32; UCX saturates at rate=16
- **TPOT**: comparable at low rates; LIBFABRIC maintains better latency under load

### Performance Characteristics (LIBFABRIC)

- **Peak total throughput**: 9,262 tok/s at rate=32
- **Peak output throughput**: 1,024 tok/s at rate=32 (peak instantaneous: 1,214 tok/s)
- **Best per-token latency**: 10.15ms TPOT at rate=1
- **TTFT scaling**: stays remarkably low — 149ms (rate=1) to 404ms (rate=32)
- **TPOT stability**: stays in 10~26ms range across all rates
- **Saturation point**: throughput still growing at rate=32, prefill server (8 GPU) is primary bottleneck

### Comparison with NCCL EP (TP=16 across 2 nodes)

Both on p5en.48xlarge, same model (DeepSeek-V3 671B FP8), same benchmark parameters.
PD results use LIBFABRIC backend (confirmed).

| Rate | Output tok/s |  | Total tok/s |  | Mean TTFT (ms) |  | Mean TPOT (ms) |  |
|------|:-----------:|:-:|:----------:|:-:|:-------------:|:-:|:-------------:|:-:|
|      | **NCCL EP** | **PD** | **NCCL EP** | **PD** | **NCCL EP** | **PD** | **NCCL EP** | **PD** |
| 1    | 27  | **92**    | 246  | **832**   | 209   | **149**   | 36  | **10.15** |
| 2    | 56  | **166**   | 509  | **1,505** | 210   | **174**   | 34  | **11.06** |
| 4    | 110 | **285**   | 999  | **2,578** | 210   | **190**   | 35  | **12.73** |
| 8    | 209 | **449**   | 1,892 | **4,062** | 224   | 253       | 36  | **15.86** |
| 16   | 345 | **694**   | 3,119 | **6,281** | **238** | 296     | 43  | **20.00** |
| 32   | 542 | **1,024** | 4,908 | **9,262** | **295** | 404     | 52  | **25.68** |

### Analysis

**PD LIBFABRIC advantages (all rates)**:
- Output throughput 1.9x~3.4x higher across all rates (dedicated decode server, CUDA graphs)
- TPOT 2~3.6x lower (10~26ms vs 34~52ms)
- Total throughput 1.9x at rate=32 (9,262 vs 4,908 tok/s)
- TTFT comparable or better at low rates (149ms vs 209ms at rate=1)

**NCCL EP advantages (rate >= 16)**:
- TTFT more stable at high concurrency: 238~295ms vs PD's 296~404ms
- But the gap is much smaller than with UCX backend

**Root causes**:
- TTFT: NCCL EP uses all 16 GPUs for prefill; PD uses only 8. With LIBFABRIC the
  KV transfer overhead is minimal, so PD TTFT stays competitive at low-mid rates
- TPOT: PD has a dedicated decode server with no prefill contention
- Throughput: PD with LIBFABRIC achieves higher throughput at all rates because
  the decode server is never interrupted by prefill work

### Recommendation

| Scenario | Recommended | Reason |
|----------|-------------|--------|
| General purpose (rate <= 32) | **PD LIBFABRIC** | 2x throughput, 2-3x lower TPOT |
| Interactive (rate <= 8) | **PD LIBFABRIC** | Lower TTFT + TPOT, higher throughput |
| Extreme concurrency (rate >> 32) | **NCCL EP** | More stable TTFT at very high load |
| Scale-out (N prefill + M decode) | **PD LIBFABRIC** | Independent scaling of P and D instances |

## Scripts

### `scripts/pd_init_worker.sh`

Worker initialization script. Run inside each pod before launching servers.

- Installs system dependencies (rdma-core, libibverbs, etc.)
- Verifies/installs EFA
- Installs `nixl-cu12==0.10.0` and `sglang-router==0.3.2`
- Optional: `--with-gdrcopy` installs GDRCopy userspace library
- Fixes hostname resolution (HyperPod 172.18.x -> 10.x)
- Creates JIT cache directories on FSx
- **Patches sglang nixl conn.py** for LIBFABRIC backend support (critical — see Known Issues)
- **Symlinks DeepGEMM cache** (`~/.cache/deep_gemm` → `/fsx/deep_gemm_cache`) for persistence

### `scripts/pd_launch_libfabric.sh`

Launch script for prefill/decode/router roles with nixl LIBFABRIC backend.

Usage:
```bash
pd_launch_libfabric.sh <role> <prefill_addr> <decode_addr> [model_path] [tp]
```

Arguments:
- `role`: `prefill` | `decode` | `router`
- `prefill_addr`: IP of prefill node (10.x.x.x)
- `decode_addr`: IP of decode node (10.x.x.x)
- `model_path`: path to model (default: `/fsx/models/Qwen3-8B`)
- `tp`: tensor parallelism degree (default: 1)

Key environment variables:
```bash
SGLANG_DISAGGREGATION_NIXL_BACKEND=LIBFABRIC  # Use LIBFABRIC, not UCX
FI_PROVIDER=efa                                 # EFA provider
FI_EFA_USE_DEVICE_RDMA=1                        # Enable device RDMA
FI_EFA_FORK_SAFE=1                              # Fork safety
FI_EFA_USE_HUGE_PAGE=0                          # Disable huge pages
FI_MR_CACHE_MONITOR=disabled                    # Disable MR cache monitor
UCX_NET_DEVICES=<auto-detected>                 # Critical: nixl inits both UCX and LIBFABRIC
```

Key sglang flags:
- `--disaggregation-mode prefill|decode`
- `--disaggregation-transfer-backend nixl`
- `--disaggregation-bootstrap-port 8998`
- `--disaggregation-decode-tp 8` (prefill only)
- `--tp 8 --ep 8`
- `--mem-fraction-static 0.85`
- `--watchdog-timeout 1200` (for DeepGEMM JIT warmup)
- `--max-running-requests 128` (decode server, recommended for higher throughput)

Ports: Prefill=30000, Decode=30001, Router=8000, Bootstrap=8998

### `scripts/pd_bench_serving.sh`

Benchmark script using `sglang.bench_serving`.

Usage:
```bash
pd_bench_serving.sh [options]
  --host HOST          Server host (default: 127.0.0.1)
  --port PORT          Server port (default: 8000)
  --model MODEL        Model path
  --num-prompts N      Prompts per rate (default: 100)
  --input-len N        Input token length (default: 2048)
  --output-len N       Output token length (default: 256)
  --range-ratio F      Random range ratio (default: 0.5)
  --rates "1 2 4 ..."  Space-separated rates (default: "1 2 4 8 16 32")
```

## Startup Phases

DeepSeek-V3 goes through these phases before serving:

1. **Weight loading** (~3 min): 163 safetensors shards, ~83 GB/GPU
2. **NCCL init** (~30s): 8 ranks intra-node via NVLink
3. **DeepGEMM JIT warmup** (2-15 min): ~16384 FP8 GEMM kernels
   - Cold cache: compiles all kernels (~18 it/s), can take 15 min
   - Warm cache (FSx via symlink `~/.cache/deep_gemm` → `/fsx/deep_gemm_cache`): ~2 min
   - Prefill compiles 278 kernels, decode 251 (subset) — shared cache works for both
4. **Server warmup** (~30s): warmup requests
5. **Ready**: `"The server is fired up and ready to roll!"`

Total: ~5-20 min depending on JIT cache state.

## nixl Backend: LIBFABRIC on EFA

nixl supports multiple transfer backends. This deployment uses LIBFABRIC for EFA RDMA.

**How it works**:
- nixl initializes **both** UCX and LIBFABRIC backends simultaneously
- LIBFABRIC uses EFA's native RDMA with `FI_HMEM` for GPU memory registration
- UCX must also be configured correctly (even though LIBFABRIC does the actual transfer)
- `UCX_NET_DEVICES` must be set to the correct 10.x.x.x interface

**GDRCopy** (optional):
- nixl official docs: GDRCopy is not required for either UCX or LIBFABRIC backend
- Can improve performance by enabling GPU memory pinning for RDMA
- If installed: must unset `PYTORCH_CUDA_ALLOC_CONF` (expandable_segments incompatible with gdr_pin_buffer)
- If not installed: nixl uses dmabuf path, expandable_segments is safe to keep
- The launch script auto-detects GDRCopy and adjusts accordingly

**UCX vs LIBFABRIC**:
- UCX: falls back to TCP transport (`rma_am(tcp)`) over EFA — no true RDMA
- LIBFABRIC: uses EFA native RDMA — 3-19x lower TTFT, 2x throughput at high concurrency

## Known Issues & Required Patches

### 1. SGLang 0.5.8 ignores `SGLANG_DISAGGREGATION_NIXL_BACKEND` (Critical)

**Problem**: SGLang 0.5.8's `NixlKVManager.__init__` in `conn.py` creates `nixl_agent`
without passing `nixl_agent_config`. The `nixl_agent_config.__init__` defaults to
`backends=['UCX']`, so nixl **always uses UCX** regardless of the env var.

**Impact**: Without the patch, KV cache transfer uses UCX TCP fallback instead of
EFA RDMA, resulting in 3-19x higher TTFT and 2x lower throughput (see benchmark comparison).

**Verification**: Check server logs for:
```
Backend LIBFABRIC was instantiated    # Good — patch is working
Selected backend: LIBFABRIC           # Good

Backend UCX was instantiated          # Bad — patch missing, using TCP fallback
Selected backend: UCX                 # Bad
```

**Fix**: The `pd_init_worker.sh` script automatically patches `conn.py` to:
1. Import `nixl_agent_config` alongside `nixl_agent`
2. Read `SGLANG_DISAGGREGATION_NIXL_BACKEND` env var
3. Pass `nixl_agent_config(backends=['LIBFABRIC'])` to `nixl_agent()`

The patched line in `sglang/srt/disaggregation/nixl/conn.py`:
```python
# Before (broken):
from nixl._api import nixl_agent
self.agent = nixl_agent(str(uuid.uuid4()))

# After (fixed):
from nixl._api import nixl_agent, nixl_agent_config
import os; _backends = os.environ.get("SGLANG_DISAGGREGATION_NIXL_BACKEND", "UCX").split(",")
_conf = nixl_agent_config(backends=_backends)
self.agent = nixl_agent(str(uuid.uuid4()), nixl_conf=_conf)
```

### 2. DeepGEMM `DG_JIT_CACHE_DIR` env var ignored

**Problem**: The DeepGEMM version in this DLC image ignores `DG_JIT_CACHE_DIR` and
always writes compiled kernels to `~/.cache/deep_gemm/cache/` (~278 kernel directories
for prefill, ~251 for decode).

**Impact**: Without a fix, each pod restart triggers a full 15-minute JIT recompilation.

**Fix**: The `pd_init_worker.sh` script symlinks the default cache path to shared FSx:
```bash
ln -sf /fsx/deep_gemm_cache /root/.cache/deep_gemm
```

Prefill and decode kernels can safely share one cache directory — decode's 251 kernels
are a strict subset of prefill's 278 kernels (same sm90 architecture, same source code).

## Troubleshooting

See `references/troubleshooting.md` for detailed error diagnosis and fixes.

Common issues:
1. **nixl silently using UCX instead of LIBFABRIC** → run `pd_init_worker.sh` to apply conn.py patch
2. **DeepGEMM JIT recompilation on every restart** → verify symlink `~/.cache/deep_gemm` → FSx
3. **Scheduler watchdog timeout** during DeepGEMM JIT → set `--watchdog-timeout 1200`
4. **nixl NIXL_ERR_BACKEND** with UCX connecting to 169.254.x.x → set `UCX_NET_DEVICES`
5. **Port already in use** → kill lingering processes from previous runs
6. **GPU memory occupied by zombies** → check `nvidia-smi` for stale processes
7. **GDRCopy + expandable_segments** → unset `PYTORCH_CUDA_ALLOC_CONF` when GDRCopy present
