# PD Disaggregation Troubleshooting Guide

## 1. nixl Silently Using UCX Instead of LIBFABRIC (Critical)

**Symptom**: Server starts and serves requests, but TTFT is much higher than expected
(e.g., 500-8000ms at rate=1-32 instead of 150-400ms). Server logs show:
```
Backend UCX was instantiated
Selected backend: UCX
```
instead of:
```
Backend LIBFABRIC was instantiated
Selected backend: LIBFABRIC
```

**Cause**: SGLang 0.5.8's `NixlKVManager.__init__` in
`sglang/srt/disaggregation/nixl/conn.py` creates `nixl_agent(str(uuid.uuid4()))`
without passing `nixl_agent_config`. The `nixl_agent_config.__init__` defaults to
`backends=['UCX']`, so the `SGLANG_DISAGGREGATION_NIXL_BACKEND=LIBFABRIC` env var
set in the launch script is **never read** by sglang code.

**Impact**: KV cache transfer falls back to UCX's TCP transport (`rma_am(tcp)`)
instead of EFA RDMA. Benchmarks show 3-19x higher TTFT and 2x lower throughput.

**Fix**: Run `pd_init_worker.sh` which patches `conn.py` to:
1. Import `nixl_agent_config` alongside `nixl_agent`
2. Read `SGLANG_DISAGGREGATION_NIXL_BACKEND` env var at runtime
3. Pass `nixl_agent_config(backends=['LIBFABRIC'])` to `nixl_agent()`

Manual fix (if init script already ran without the patch):
```bash
CONN_PY=$(python3 -c "import sglang; import os; print(os.path.join(os.path.dirname(sglang.__file__), 'srt/disaggregation/nixl/conn.py'))")
sed -i 's/from nixl._api import nixl_agent$/from nixl._api import nixl_agent, nixl_agent_config/' "$CONN_PY"
sed -i 's/self\.agent = nixl_agent(str(uuid\.uuid4()))/import os; _backends = os.environ.get("SGLANG_DISAGGREGATION_NIXL_BACKEND", "UCX").split(","); _conf = nixl_agent_config(backends=_backends); self.agent = nixl_agent(str(uuid.uuid4()), nixl_conf=_conf)/' "$CONN_PY"
```

After patching, restart the sglang servers and verify logs show `Selected backend: LIBFABRIC`.

---

## 2. DeepGEMM Cache Not Persisting Across Restarts

**Symptom**: Every pod restart triggers a full 15-minute DeepGEMM JIT recompilation,
even though `DG_JIT_CACHE_DIR=/fsx/deep_gemm_cache` is set. The FSx cache directory
is empty while `~/.cache/deep_gemm/cache/` has all the compiled kernels.

**Cause**: The DeepGEMM version in the DLC image (`sglang:0.5.8-...`) ignores the
`DG_JIT_CACHE_DIR` environment variable. It always writes compiled kernels to the
hardcoded default path `~/.cache/deep_gemm/cache/`.

**Fix**: Symlink the default path to shared FSx:
```bash
mkdir -p /fsx/deep_gemm_cache/cache /fsx/deep_gemm_cache/tmp
rm -rf /root/.cache/deep_gemm
ln -sf /fsx/deep_gemm_cache /root/.cache/deep_gemm
```

The `pd_init_worker.sh` script does this automatically.

**Note**: Prefill compiles 278 kernels and decode compiles 251 kernels. Decode's
kernels are a strict subset of prefill's (same sm90 architecture, same `.cu` source).
Both nodes can safely share one FSx cache directory with no conflicts.

---

## 3. Scheduler Watchdog Timeout During DeepGEMM JIT

**Symptom**:
```
Scheduler watchdog timeout (self.watchdog_timeout=300, self.soft=False)
```

**Cause**: DeepGEMM compiles ~16384 FP8 GEMM kernels on first run (cold cache).
Default watchdog timeout of 300s is insufficient.

**Fix**: Add `--watchdog-timeout 1200` to both prefill and decode launch commands.
Already included in `pd_launch_libfabric.sh`.

**Prevention**: JIT cache on shared FSx (`/fsx/deep_gemm_cache`) persists across
restarts. After first warm-up, subsequent launches use the cache and are much faster.

---

## 4. nixl NIXL_ERR_BACKEND (UCX Connecting to 169.254.x.x)

**Symptom**:
```
nixl_cu12._bindings.nixlBackendError: NIXL_ERR_BACKEND
```

Server logs show UCX trying to connect to `169.254.0.1` (veth_def_agent link-local
address) instead of the correct `10.x.x.x` EFA address.

**Cause**: nixl initializes **both** UCX and LIBFABRIC backends, even when
`SGLANG_DISAGGREGATION_NIXL_BACKEND=LIBFABRIC`. UCX auto-selects the wrong
network interface on HyperPod (veth_def_agent has 169.254.0.1).

**Fix**: Set `UCX_NET_DEVICES` to the correct EFA interface:
```bash
UCX_IF=$(ip -o addr show | grep "inet 10\." | awk '{print $2}' | head -1)
export UCX_NET_DEVICES=${UCX_IF}
```

Already included in `pd_launch_libfabric.sh`.

---

## 5. Port Already in Use

**Symptom**:
```
OSError: [Errno 98] Address already in use
```
or
```
failed to install Prometheus metrics exporter: FailedToCreateHTTPListener("Address already in use (os error 98)")
```

**Cause**: Previous server/router process left the port bound.

**Fix**: Find and kill the process occupying the port:
```bash
# Check which process holds the port
ss -tlnp | grep <PORT>

# Kill it
kill -9 <PID>
```

Common ports:
- 30000: prefill server
- 30001: decode server
- 8000: router
- 8998: bootstrap
- 9090/9091: Prometheus metrics

---

## 6. GPU Memory Occupied by Zombie Processes

**Symptom**: GPU memory is mostly consumed but no active sglang processes visible.
```bash
nvidia-smi  # Shows high memory usage
ps aux | grep sglang  # Shows no processes (or PPID=1 zombies)
```

**Cause**: Previous sglang processes crashed but their GPU memory allocations persist
(parent PID=1, container init cannot reap them).

**Fix**: Identify and kill zombie processes:
```bash
# List GPU compute processes
nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv

# Kill specific PIDs
kill -9 <PID1> <PID2> ...
```

If PIDs cannot be killed (PPID=1 zombies), the pod needs to be recreated.

---

## 7. GDRCopy + Expandable Segments Incompatibility

**Symptom**:
```
gdr_pin_buffer: Invalid argument
```
or RDMA registration failures.

**Cause**: PyTorch's `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True` uses
`cuMemAddressReserve`+`cuMemMap` (virtual memory API). GDRCopy's `gdr_pin_buffer`
cannot pin memory allocated this way.

**Fix**: Unset `PYTORCH_CUDA_ALLOC_CONF` when GDRCopy is present:
```bash
unset PYTORCH_CUDA_ALLOC_CONF
```

The launch script auto-detects GDRCopy and handles this:
```bash
if [ -f /usr/local/lib/libgdrapi.so ] || ldconfig -p 2>/dev/null | grep -q libgdrapi; then
  unset PYTORCH_CUDA_ALLOC_CONF
fi
```

---

## 8. Hostname Resolution Failure

**Symptom**: NCCL or nixl fails to connect between processes on the same node.
Logs show connection attempts to `172.18.x.x` instead of `10.x.x.x`.

**Cause**: HyperPod EKS uses `172.18.x.x` for internal DNS, but EFA data-plane
uses `10.x.x.x`. `hostname` resolves to the wrong address.

**Fix**: Add correct hostname mapping to `/etc/hosts`:
```bash
MYIP=$(ip addr show | grep "inet 10\." | head -1 | awk '{print $2}' | cut -d/ -f1)
echo "$MYIP $(hostname)" >> /etc/hosts
```

Already included in both `pd_init_worker.sh` and `pd_launch_libfabric.sh`.

---

## 9. Router Fails to Register Workers

**Symptom**: Router starts but shows `workers: []` and requests return 503.

**Cause**: Router was started before prefill/decode servers were ready.

**Fix**: Wait for both servers to show "fired up" before starting router:
```bash
# Check readiness
kubectl exec uccl-ep-node0 -- grep "fired up" /tmp/pd_prefill.log
kubectl exec uccl-ep-node1 -- grep "fired up" /tmp/pd_decode.log

# Both must return a match before starting router
```

Router logs should show:
```
Activated 1 worker(s) (marked as healthy)  # appears twice (prefill + decode)
```

---

## 10. Model Loading OOM

**Symptom**:
```
torch.OutOfMemoryError: CUDA out of memory
```
during safetensors loading.

**Cause**: Previous model's GPU memory not fully released, or other processes
consuming GPU memory.

**Fix**:
```bash
# Check GPU memory usage
nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv,noheader

# Kill any lingering processes
nvidia-smi --query-compute-apps=pid --format=csv,noheader | xargs -r kill -9

# Verify memory is freed
nvidia-smi
```

DeepSeek-V3 FP8 requires ~83 GB/GPU with TP=8. H200 141GB GPUs have sufficient
headroom, but any stale processes will cause OOM.

---

## 11. EFA Provider Not Found

**Symptom**:
```
fi_getinfo: -61 (No data available)
```

**Cause**: EFA libfabric provider not installed or not in library path.

**Fix**:
```bash
export EFA_HOME=/opt/amazon/efa
export LD_LIBRARY_PATH=$EFA_HOME/lib:$EFA_HOME/lib64:$LD_LIBRARY_PATH
export PATH=$EFA_HOME/bin:$PATH

# Verify
fi_info -p efa -l
```

---

## 12. Slow DeepGEMM JIT Compilation

**Symptom**: Server hangs for 10-15 minutes after model loading with log messages like:
```
Warmup DeepGemm...  18it/s
```

**Cause**: Cold DeepGEMM JIT cache. ~16384 kernels need compilation.

**Mitigation**:
- Ensure the DeepGEMM cache symlink is in place: `ls -la /root/.cache/deep_gemm`
  should show `-> /fsx/deep_gemm_cache`
- If missing, run `pd_init_worker.sh` or manually:
  `rm -rf /root/.cache/deep_gemm && ln -sf /fsx/deep_gemm_cache /root/.cache/deep_gemm`
- First run populates the cache; subsequent runs load from cache (~2 min)
- Note: `DG_JIT_CACHE_DIR` env var does not work in this DLC version (see issue #2)
- Use `--watchdog-timeout 1200` to prevent timeout during compilation

---

## Diagnostic Commands

```bash
# Check server readiness
kubectl exec <node> -- grep "fired up" /tmp/pd_prefill.log
kubectl exec <node> -- grep "fired up" /tmp/pd_decode.log

# Check for errors
kubectl exec <node> -- grep -E "Traceback|Error|FAILED|killed" /tmp/pd_prefill.log

# GPU status
kubectl exec <node> -- nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv,noheader

# GPU processes
kubectl exec <node> -- nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv

# Network interface check
kubectl exec <node> -- ip -o addr show | grep "inet 10\."

# EFA status
kubectl exec <node> -- fi_info -p efa -l

# Port usage
kubectl exec <node> -- ss -tlnp | grep -E "30000|30001|8000|8998"

# nixl backend verification (in server logs)
kubectl exec <node> -- grep "LIBFABRIC\|backend" /tmp/pd_prefill.log | head -20

# Health check
kubectl exec <node> -- curl -s http://127.0.0.1:8000/health
kubectl exec <node> -- curl -s http://127.0.0.1:30000/health
kubectl exec <node> -- curl -s http://127.0.0.1:30001/health
```
