# PD Disaggregation Benchmark Results

## Test Setup

| Parameter | Value |
|-----------|-------|
| Hardware | 2x p5en.48xlarge (8x H200 141GB per node) |
| Model | DeepSeek-V3 671B MoE FP8 |
| Framework | SGLang 0.5.8 |
| Architecture | 1P1D: Prefill (Node0, TP=8) + Decode (Node1, TP=8) |
| KV Transfer | nixl LIBFABRIC backend (EFA RDMA) |
| MoE Communication | NCCL over NVLink (intra-node only) |
| Benchmark Tool | `sglang.bench_serving` |
| Prompts per Rate | 100 |
| Input Length | ~2048 tokens (random, range_ratio=0.5) |
| Output Length | ~256 tokens (random, range_ratio=0.5) |
| Rates Tested | 1, 2, 4, 8, 16, 32 req/s |

## LIBFABRIC Backend Results (Confirmed)

Verified via server logs: `"Backend LIBFABRIC was instantiated"`, `"Selected backend: LIBFABRIC"`.
Requires conn.py patch applied by `pd_init_worker.sh` (see troubleshooting.md issue #1).

### Summary Table (LIBFABRIC)

| Rate | Req/s | Output tok/s | Total tok/s | Mean E2E (ms) | Mean TTFT (ms) | Mean TPOT (ms) | P99 TPOT (ms) | Mean ITL (ms) | P99 ITL (ms) |
|------|------:|-------------:|------------:|--------------:|---------------:|---------------:|--------------:|--------------:|-------------:|
| 1    | 0.48  | 92           | 832         | 2,085         | 149            | 10.15          | 10.20         | 10.15         | 10.32        |
| 2    | 0.87  | 166          | 1,505       | 2,283         | 174            | 11.06          | 11.18         | 11.05         | 11.41        |
| 4    | 1.49  | 285          | 2,578       | 2,616         | 190            | 12.73          | 12.87         | 12.72         | 14.02        |
| 8    | 2.34  | 449          | 4,062       | 3,278         | 253            | 15.86          | 16.12         | 15.86         | 17.45        |
| 16   | 3.62  | 694          | 6,281       | 4,106         | 296            | 20.00          | 20.63         | 19.97         | 22.24        |
| 32   | 5.34  | 1,024        | 9,262       | 5,292         | 404            | 25.68          | 26.90         | 25.62         | 29.42        |

### Full Results (LIBFABRIC)

#### Rate = 1 (LIBFABRIC)

```
Traffic request rate:                    1.0
Max request concurrency:                 1
Successful requests:                     100
Benchmark duration (s):                  208.51
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              0.48
Input token throughput (tok/s):          740.06
Output token throughput (tok/s):         91.95
Peak output token throughput (tok/s):    99.00
Peak concurrent requests:                2
Total token throughput (tok/s):          832.00
Concurrency:                             1.00
Mean E2E Latency (ms):                   2,084.69
Median E2E Latency (ms):                 2,056.46
P90 E2E Latency (ms):                    2,584.32
P99 E2E Latency (ms):                    2,702.26
Mean TTFT (ms):                          149.17
Median TTFT (ms):                        147.52
P99 TTFT (ms):                           173.60
Mean TPOT (ms):                          10.15
Median TPOT (ms):                        10.15
P99 TPOT (ms):                           10.20
Mean ITL (ms):                           10.15
Median ITL (ms):                         10.14
P95 ITL (ms):                            10.23
P99 ITL (ms):                            10.32
Max ITL (ms):                            31.34
```

#### Rate = 2 (LIBFABRIC)

```
Traffic request rate:                    2.0
Max request concurrency:                 2
Successful requests:                     100
Benchmark duration (s):                  115.29
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              0.87
Input token throughput (tok/s):          1,338.40
Output token throughput (tok/s):         166.29
Peak output token throughput (tok/s):    182.00
Peak concurrent requests:                4
Total token throughput (tok/s):          1,504.69
Concurrency:                             1.98
Mean E2E Latency (ms):                   2,282.93
Median E2E Latency (ms):                 2,271.90
P90 E2E Latency (ms):                    2,817.81
P99 E2E Latency (ms):                    3,007.81
Mean TTFT (ms):                          174.49
Median TTFT (ms):                        164.19
P99 TTFT (ms):                           296.62
Mean TPOT (ms):                          11.06
Median TPOT (ms):                        11.06
P99 TPOT (ms):                           11.18
Mean ITL (ms):                           11.05
Median ITL (ms):                         11.12
P95 ITL (ms):                            11.28
P99 ITL (ms):                            11.41
Max ITL (ms):                            201.25
```

#### Rate = 4 (LIBFABRIC)

```
Traffic request rate:                    4.0
Max request concurrency:                 4
Successful requests:                     100
Benchmark duration (s):                  67.30
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              1.49
Input token throughput (tok/s):          2,292.85
Output token throughput (tok/s):         284.88
Peak output token throughput (tok/s):    316.00
Peak concurrent requests:                7
Total token throughput (tok/s):          2,577.73
Concurrency:                             3.89
Mean E2E Latency (ms):                   2,616.34
Median E2E Latency (ms):                 2,550.27
P90 E2E Latency (ms):                    3,250.37
P99 E2E Latency (ms):                    3,445.76
Mean TTFT (ms):                          189.76
Median TTFT (ms):                        167.11
P99 TTFT (ms):                           302.41
Mean TPOT (ms):                          12.73
Median TPOT (ms):                        12.79
P99 TPOT (ms):                           12.87
Mean ITL (ms):                           12.72
Median ITL (ms):                         12.77
P95 ITL (ms):                            13.08
P99 ITL (ms):                            14.02
Max ITL (ms):                            17.21
```

#### Rate = 8 (LIBFABRIC)

```
Traffic request rate:                    8.0
Max request concurrency:                 8
Successful requests:                     100
Benchmark duration (s):                  42.71
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              2.34
Input token throughput (tok/s):          3,613.04
Output token throughput (tok/s):         448.91
Peak output token throughput (tok/s):    504.00
Peak concurrent requests:                15
Total token throughput (tok/s):          4,061.95
Concurrency:                             7.68
Mean E2E Latency (ms):                   3,278.17
Median E2E Latency (ms):                 3,218.80
P90 E2E Latency (ms):                    4,044.26
P99 E2E Latency (ms):                    4,225.74
Mean TTFT (ms):                          253.38
Median TTFT (ms):                        216.14
P99 TTFT (ms):                           524.81
Mean TPOT (ms):                          15.86
Median TPOT (ms):                        15.98
P99 TPOT (ms):                           16.12
Mean ITL (ms):                           15.86
Median ITL (ms):                         15.97
P95 ITL (ms):                            16.32
P99 ITL (ms):                            17.45
Max ITL (ms):                            26.91
```

#### Rate = 16 (LIBFABRIC)

```
Traffic request rate:                    16.0
Max request concurrency:                 16
Successful requests:                     100
Benchmark duration (s):                  27.62
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              3.62
Input token throughput (tok/s):          5,586.59
Output token throughput (tok/s):         694.11
Peak output token throughput (tok/s):    789.00
Peak concurrent requests:                25
Total token throughput (tok/s):          6,280.70
Concurrency:                             14.86
Mean E2E Latency (ms):                   4,105.56
Median E2E Latency (ms):                 4,003.66
P90 E2E Latency (ms):                    5,064.68
P99 E2E Latency (ms):                    5,387.33
Mean TTFT (ms):                          295.96
Median TTFT (ms):                        270.45
P99 TTFT (ms):                           516.26
Mean TPOT (ms):                          20.00
Median TPOT (ms):                        20.20
P99 TPOT (ms):                           20.63
Mean ITL (ms):                           19.97
Median ITL (ms):                         20.33
P95 ITL (ms):                            21.19
P99 ITL (ms):                            22.24
Max ITL (ms):                            26.23
```

#### Rate = 32 (LIBFABRIC)

```
Traffic request rate:                    32.0
Max request concurrency:                 32
Successful requests:                     100
Benchmark duration (s):                  18.73
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              5.34
Input token throughput (tok/s):          8,238.30
Output token throughput (tok/s):         1,023.58
Peak output token throughput (tok/s):    1,214.00
Peak concurrent requests:                44
Total token throughput (tok/s):          9,261.88
Concurrency:                             28.25
Mean E2E Latency (ms):                   5,291.50
Median E2E Latency (ms):                 5,160.83
P90 E2E Latency (ms):                    6,487.01
P99 E2E Latency (ms):                    7,024.00
Mean TTFT (ms):                          404.47
Median TTFT (ms):                        413.32
P99 TTFT (ms):                           685.30
Mean TPOT (ms):                          25.68
Median TPOT (ms):                        26.06
P99 TPOT (ms):                           26.90
Mean ITL (ms):                           25.62
Median ITL (ms):                         26.35
P95 ITL (ms):                            27.64
P99 ITL (ms):                            29.42
Max ITL (ms):                            37.67
```

## LIBFABRIC vs UCX Backend Comparison

Without the conn.py patch, SGLang 0.5.8 silently falls back to UCX backend.
Below are benchmarks from the same hardware and workload, comparing both backends.

### UCX Backend Results (Before Fix)

Server logs showed `"Backend UCX was instantiated"`, `"Selected backend: UCX"`.

| Rate | Req/s | Output tok/s | Total tok/s | Mean E2E (ms) | Mean TTFT (ms) | Mean TPOT (ms) |
|------|------:|-------------:|------------:|--------------:|---------------:|---------------:|
| 1    | 0.41  | 79           | 713         | 2,085         | 498            | 10.14          |
| 2    | 0.74  | 143          | 1,290       | 2,583         | 584            | 10.93          |
| 4    | 1.21  | 232          | 2,102       | 3,347         | 867            | 12.41          |
| 8    | 1.88  | 360          | 3,255       | 4,589         | 1,204          | 15.31          |
| 16   | 2.40  | 460          | 4,166       | 6,928         | 2,976          | 17.12          |
| 32   | 2.53  | 484          | 4,383       | 11,653        | 7,784          | 19.57          |

### Comparison: LIBFABRIC vs UCX

| Rate | TTFT LIBFABRIC (ms) | TTFT UCX (ms) | Improvement | Output tok/s LIBFABRIC | Output tok/s UCX | Improvement |
|------|--------------------:|--------------:|:-----------:|-----------------------:|-----------------:|:-----------:|
| 1    | **149**             | 498           | 3.3x        | **92**                 | 79               | +16%        |
| 2    | **174**             | 584           | 3.4x        | **166**                | 143              | +16%        |
| 4    | **190**             | 867           | 4.6x        | **285**                | 232              | +23%        |
| 8    | **253**             | 1,204         | 4.8x        | **449**                | 360              | +25%        |
| 16   | **296**             | 2,976         | 10.1x       | **694**                | 460              | +51%        |
| 32   | **404**             | 7,784         | **19.3x**   | **1,024**              | 484              | **+112%**   |

### Analysis: Why LIBFABRIC is Dramatically Better

1. **KV Transfer Mechanism**: LIBFABRIC uses EFA's native RDMA (`FI_HMEM` GPU memory
   registration + RDMA read/write). UCX falls back to `rma_am(tcp)` — TCP sockets
   over EFA, missing the RDMA fast path entirely.

2. **TTFT Impact**: KV cache transfer happens once per request between prefill and decode.
   With LIBFABRIC, this transfer is near-instant via RDMA. With UCX TCP, each transfer
   incurs TCP overhead that compounds as concurrency increases, causing TTFT to explode
   from 498ms to 7,784ms at rate=32.

3. **Throughput Impact**: At high concurrency, the UCX TCP bottleneck limits how fast
   the decode server can receive KV caches, capping throughput at ~484 tok/s. LIBFABRIC
   removes this bottleneck, allowing throughput to scale to 1,024 tok/s and beyond.

## UCX Backend Full Results (Before Fix)

These results are kept for reference. They were collected before the conn.py patch
was applied, when nixl was silently using UCX instead of LIBFABRIC.

## Full Results (UCX — Before Fix)

### Rate = 1 (UCX)

```
Traffic request rate:                    1.0
Max request concurrency:                 1
Successful requests:                     100
Benchmark duration (s):                  262.82
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              0.38
Input token throughput (tok/s):          587.12
Output token throughput (tok/s):         72.95
Peak output token throughput (tok/s):    99.00
Peak concurrent requests:                2
Total token throughput (tok/s):          660.06
Concurrency:                             1.00
Mean E2E Latency (ms):                   2,627.72
Median E2E Latency (ms):                 2,620.17
P90 E2E Latency (ms):                    3,121.33
P99 E2E Latency (ms):                    3,283.49
Mean TTFT (ms):                          692.72
Median TTFT (ms):                        681.08
P99 TTFT (ms):                           1,001.92
Mean TPOT (ms):                          10.15
Median TPOT (ms):                        10.15
P99 TPOT (ms):                           10.20
Mean ITL (ms):                           10.16
Median ITL (ms):                         10.18
P95 ITL (ms):                            10.30
P99 ITL (ms):                            10.25
Max ITL (ms):                            12.48
```

### Rate = 2 (UCX)

```
Traffic request rate:                    2.0
Max request concurrency:                 2
Successful requests:                     100
Benchmark duration (s):                  134.63
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              0.74
Input token throughput (tok/s):          1,146.17
Output token throughput (tok/s):         142.41
Peak output token throughput (tok/s):    180.00
Peak concurrent requests:                4
Total token throughput (tok/s):          1,288.57
Concurrency:                             1.99
Mean E2E Latency (ms):                   2,674.21
Median E2E Latency (ms):                 2,623.76
P90 E2E Latency (ms):                    3,218.27
P99 E2E Latency (ms):                    3,625.23
Mean TTFT (ms):                          587.36
Median TTFT (ms):                        547.28
P99 TTFT (ms):                           971.98
Mean TPOT (ms):                          10.94
Median TPOT (ms):                        10.91
P99 TPOT (ms):                           11.68
Mean ITL (ms):                           10.94
Median ITL (ms):                         10.96
P95 ITL (ms):                            11.40
P99 ITL (ms):                            11.83
Max ITL (ms):                            14.53
```

### Rate = 4 (UCX)

```
Traffic request rate:                    4.0
Max request concurrency:                 4
Successful requests:                     100
Benchmark duration (s):                  79.35
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              1.26
Input token throughput (tok/s):          1,944.55
Output token throughput (tok/s):         241.60
Peak output token throughput (tok/s):    312.00
Peak concurrent requests:                7
Total token throughput (tok/s):          2,186.15
Concurrency:                             3.91
Mean E2E Latency (ms):                   3,102.01
Median E2E Latency (ms):                 3,096.23
P90 E2E Latency (ms):                    3,725.97
P99 E2E Latency (ms):                    4,357.52
Mean TTFT (ms):                          716.09
Median TTFT (ms):                        616.01
P99 TTFT (ms):                           1,354.99
Mean TPOT (ms):                          12.51
Median TPOT (ms):                        12.64
P99 TPOT (ms):                           12.83
Mean ITL (ms):                           12.51
Median ITL (ms):                         12.74
P95 ITL (ms):                            13.07
P99 ITL (ms):                            13.86
Max ITL (ms):                            16.76
```

### Rate = 8 (UCX)

```
Traffic request rate:                    8.0
Max request concurrency:                 8
Successful requests:                     100
Benchmark duration (s):                  55.52
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              1.80
Input token throughput (tok/s):          2,779.05
Output token throughput (tok/s):         345.29
Peak output token throughput (tok/s):    458.00
Peak concurrent requests:                12
Total token throughput (tok/s):          3,124.34
Concurrency:                             7.74
Mean E2E Latency (ms):                   4,300.20
Median E2E Latency (ms):                 4,176.69
P90 E2E Latency (ms):                    5,437.61
P99 E2E Latency (ms):                    6,406.95
Mean TTFT (ms):                          1,410.03
Median TTFT (ms):                        1,339.45
P99 TTFT (ms):                           3,044.48
Mean TPOT (ms):                          15.16
Median TPOT (ms):                        15.52
P99 TPOT (ms):                           16.07
Mean ITL (ms):                           15.15
Median ITL (ms):                         15.68
P95 ITL (ms):                            16.21
P99 ITL (ms):                            17.66
Max ITL (ms):                            26.52
```

### Rate = 16 (UCX)

```
Traffic request rate:                    16.0
Max request concurrency:                 16
Successful requests:                     100
Benchmark duration (s):                  44.54
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              2.25
Input token throughput (tok/s):          3,464.34
Output token throughput (tok/s):         430.43
Peak output token throughput (tok/s):    603.00
Peak concurrent requests:                21
Total token throughput (tok/s):          3,894.77
Concurrency:                             15.08
Mean E2E Latency (ms):                   6,717.72
Median E2E Latency (ms):                 6,567.24
P90 E2E Latency (ms):                    8,365.76
P99 E2E Latency (ms):                    9,635.27
Mean TTFT (ms):                          3,554.24
Median TTFT (ms):                        3,383.89
P99 TTFT (ms):                           6,421.97
Mean TPOT (ms):                          16.61
Median TPOT (ms):                        16.83
P99 TPOT (ms):                           17.95
Mean ITL (ms):                           16.59
Median ITL (ms):                         16.14
P95 ITL (ms):                            18.28
P99 ITL (ms):                            19.73
Max ITL (ms):                            22.76
```

### Rate = 32 (UCX)

```
Traffic request rate:                    32.0
Max request concurrency:                 32
Successful requests:                     100
Benchmark duration (s):                  42.26
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              2.37
Input token throughput (tok/s):          3,650.94
Output token throughput (tok/s):         453.62
Peak output token throughput (tok/s):    903.00
Peak concurrent requests:                43
Total token throughput (tok/s):          4,104.55
Concurrency:                             28.14
Mean E2E Latency (ms):                   11,894.50
Median E2E Latency (ms):                 11,655.14
P90 E2E Latency (ms):                    15,236.53
P99 E2E Latency (ms):                    16,469.89
Mean TTFT (ms):                          8,141.21
Median TTFT (ms):                        7,804.83
P99 TTFT (ms):                           11,217.34
Mean TPOT (ms):                          19.77
Median TPOT (ms):                        19.99
P99 TPOT (ms):                           22.98
Mean ITL (ms):                           19.68
Median ITL (ms):                         20.08
P95 ITL (ms):                            23.78
P99 ITL (ms):                            24.18
Max ITL (ms):                            30.52
```

## Summary Table (UCX — Before Fix)

| Rate | Req/s | Output tok/s | Total tok/s | Mean E2E (ms) | Mean TTFT (ms) | Mean TPOT (ms) | P99 TPOT (ms) | Mean ITL (ms) | P99 ITL (ms) |
|------|------:|-------------:|------------:|--------------:|---------------:|---------------:|--------------:|--------------:|-------------:|
| 1    | 0.38  | 73           | 660         | 2,628         | 693            | 10.15          | 10.20         | 10.16         | 10.25        |
| 2    | 0.74  | 142          | 1,289       | 2,674         | 587            | 10.94          | 11.68         | 10.94         | 11.83        |
| 4    | 1.26  | 242          | 2,186       | 3,102         | 716            | 12.51          | 12.83         | 12.51         | 13.86        |
| 8    | 1.80  | 345          | 3,124       | 4,300         | 1,410          | 15.16          | 16.07         | 15.15         | 17.66        |
| 16   | 2.25  | 430          | 3,895       | 6,718         | 3,554          | 16.61          | 17.95         | 16.59         | 19.73        |
| 32   | 2.37  | 454          | 4,105       | 11,895        | 8,141          | 19.77          | 22.98         | 19.68         | 24.18        |

## Results with `--max-running-requests 128` (UCX Backend, Decode Server)

The decode server was configured with `--max-running-requests 128` to allow larger decode
batches. All other parameters remain identical to the default configuration above.
Note: these results were collected with UCX backend (before the LIBFABRIC fix).

### Rate = 1 (UCX, MRR=128)

```
Traffic request rate:                    1.0
Max request concurrency:                 1
Successful requests:                     100
Benchmark duration (s):                  242.64
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              0.41
Input token throughput (tok/s):          635.95
Output token throughput (tok/s):         79.01
Peak output token throughput (tok/s):    99.00
Peak concurrent requests:                2
Total token throughput (tok/s):          714.96
Concurrency:                             1.00
Mean E2E Latency (ms):                   2,425.99
Median E2E Latency (ms):                 2,394.54
P90 E2E Latency (ms):                    2,901.31
P99 E2E Latency (ms):                    3,107.69
Mean TTFT (ms):                          493.12
Median TTFT (ms):                        492.67
P99 TTFT (ms):                           633.14
Mean TPOT (ms):                          10.13
Median TPOT (ms):                        10.13
P99 TPOT (ms):                           10.18
Mean ITL (ms):                           10.13
Median ITL (ms):                         10.13
P95 ITL (ms):                            10.23
P99 ITL (ms):                            10.33
Max ITL (ms):                            22.24
```

### Rate = 2 (UCX, MRR=128)

```
Traffic request rate:                    2.0
Max request concurrency:                 2
Successful requests:                     100
Benchmark duration (s):                  133.74
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              0.75
Input token throughput (tok/s):          1,153.81
Output token throughput (tok/s):         143.36
Peak output token throughput (tok/s):    180.00
Peak concurrent requests:                4
Total token throughput (tok/s):          1,297.16
Concurrency:                             1.99
Mean E2E Latency (ms):                   2,657.09
Median E2E Latency (ms):                 2,602.84
P90 E2E Latency (ms):                    3,182.47
P99 E2E Latency (ms):                    3,628.37
Mean TTFT (ms):                          571.13
Median TTFT (ms):                        535.98
P99 TTFT (ms):                           940.78
Mean TPOT (ms):                          10.93
Median TPOT (ms):                        10.90
P99 TPOT (ms):                           11.62
Mean ITL (ms):                           10.94
Median ITL (ms):                         11.09
P95 ITL (ms):                            11.27
P99 ITL (ms):                            11.41
Max ITL (ms):                            330.62
```

### Rate = 4 (UCX, MRR=128)

```
Traffic request rate:                    4.0
Max request concurrency:                 4
Successful requests:                     100
Benchmark duration (s):                  79.54
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              1.26
Input token throughput (tok/s):          1,940.00
Output token throughput (tok/s):         241.04
Peak output token throughput (tok/s):    312.00
Peak concurrent requests:                7
Total token throughput (tok/s):          2,181.04
Concurrency:                             3.90
Mean E2E Latency (ms):                   3,099.91
Median E2E Latency (ms):                 3,068.35
P90 E2E Latency (ms):                    3,715.18
P99 E2E Latency (ms):                    4,256.23
Mean TTFT (ms):                          715.75
Median TTFT (ms):                        634.38
P99 TTFT (ms):                           1,361.28
Mean TPOT (ms):                          12.50
Median TPOT (ms):                        12.62
P99 TPOT (ms):                           12.84
Mean ITL (ms):                           12.50
Median ITL (ms):                         12.75
P95 ITL (ms):                            13.10
P99 ITL (ms):                            14.07
Max ITL (ms):                            17.81
```

### Rate = 8 (UCX, MRR=128)

```
Traffic request rate:                    8.0
Max request concurrency:                 8
Successful requests:                     100
Benchmark duration (s):                  52.34
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              1.91
Input token throughput (tok/s):          2,948.31
Output token throughput (tok/s):         366.32
Peak output token throughput (tok/s):    458.00
Peak concurrent requests:                12
Total token throughput (tok/s):          3,314.63
Concurrency:                             7.71
Mean E2E Latency (ms):                   4,034.23
Median E2E Latency (ms):                 3,999.63
P90 E2E Latency (ms):                    4,976.08
P99 E2E Latency (ms):                    6,120.32
Mean TTFT (ms):                          1,070.68
Median TTFT (ms):                        973.51
P99 TTFT (ms):                           2,772.62
Mean TPOT (ms):                          15.54
Median TPOT (ms):                        15.84
P99 TPOT (ms):                           16.06
Mean ITL (ms):                           15.54
Median ITL (ms):                         15.80
P95 ITL (ms):                            16.27
P99 ITL (ms):                            17.82
Max ITL (ms):                            26.21
```

### Rate = 16 (UCX, MRR=128)

```
Traffic request rate:                    16.0
Max request concurrency:                 16
Successful requests:                     100
Benchmark duration (s):                  42.31
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              2.36
Input token throughput (tok/s):          3,647.27
Output token throughput (tok/s):         453.16
Peak output token throughput (tok/s):    618.00
Peak concurrent requests:                21
Total token throughput (tok/s):          4,100.44
Concurrency:                             14.96
Mean E2E Latency (ms):                   6,329.67
Median E2E Latency (ms):                 6,280.62
P90 E2E Latency (ms):                    7,599.40
P99 E2E Latency (ms):                    10,009.73
Mean TTFT (ms):                          3,105.40
Median TTFT (ms):                        3,035.21
P99 TTFT (ms):                           6,152.50
Mean TPOT (ms):                          16.92
Median TPOT (ms):                        17.08
P99 TPOT (ms):                           18.11
Mean ITL (ms):                           16.91
Median ITL (ms):                         17.32
P95 ITL (ms):                            18.37
P99 ITL (ms):                            20.26
Max ITL (ms):                            25.49
```

### Rate = 32 (UCX, MRR=128)

```
Traffic request rate:                    32.0
Max request concurrency:                 32
Successful requests:                     100
Benchmark duration (s):                  38.44
Total input tokens:                      154,306
Total generated tokens:                  19,172
Request throughput (req/s):              2.60
Input token throughput (tok/s):          4,014.56
Output token throughput (tok/s):         498.80
Peak output token throughput (tok/s):    901.00
Peak concurrent requests:                45
Total token throughput (tok/s):          4,513.36
Concurrency:                             28.70
Mean E2E Latency (ms):                   11,030.05
Median E2E Latency (ms):                 10,797.45
P90 E2E Latency (ms):                    14,757.07
P99 E2E Latency (ms):                    16,308.99
Mean TTFT (ms):                          7,216.91
Median TTFT (ms):                        6,898.87
P99 TTFT (ms):                           10,958.35
Mean TPOT (ms):                          20.08
Median TPOT (ms):                        20.50
P99 TPOT (ms):                           22.97
Mean ITL (ms):                           19.99
Median ITL (ms):                         20.40
P95 ITL (ms):                            23.78
P99 ITL (ms):                            24.11
Max ITL (ms):                            29.47
```

## Summary Table (UCX, MRR=128)

| Rate | Req/s | Output tok/s | Total tok/s | Mean E2E (ms) | Mean TTFT (ms) | Mean TPOT (ms) | P99 TPOT (ms) | Mean ITL (ms) | P99 ITL (ms) |
|------|------:|-------------:|------------:|--------------:|---------------:|---------------:|--------------:|--------------:|-------------:|
| 1    | 0.41  | 79           | 715         | 2,426         | 493            | 10.13          | 10.18         | 10.13         | 10.33        |
| 2    | 0.75  | 143          | 1,297       | 2,657         | 571            | 10.93          | 11.62         | 10.94         | 11.41        |
| 4    | 1.26  | 241          | 2,181       | 3,100         | 716            | 12.50          | 12.84         | 12.50         | 14.07        |
| 8    | 1.91  | 366          | 3,315       | 4,034         | 1,071          | 15.54          | 16.06         | 15.54         | 17.82        |
| 16   | 2.36  | 453          | 4,100       | 6,330         | 3,105          | 16.92          | 18.11         | 16.91         | 20.26        |
| 32   | 2.60  | 499          | 4,513       | 11,030        | 7,217          | 20.08          | 22.97         | 19.99         | 24.11        |

## Effect of `--max-running-requests 128` (UCX Backend)

### Comparison Table (UCX)

| Rate | Output tok/s |  | Total tok/s |  | Mean TTFT (ms) |  | Mean TPOT (ms) |  |
|------|:-----------:|:-:|:----------:|:-:|:-------------:|:-:|:-------------:|:-:|
|      | **Default** | **MRR=128** | **Default** | **MRR=128** | **Default** | **MRR=128** | **Default** | **MRR=128** |
| 1    | 73  | **79** (+8%)   | 660   | **715** (+8%)   | 693   | **493** (-29%)   | 10.15 | **10.13** |
| 2    | 142 | **143** (+1%)  | 1,289 | **1,297** (+1%) | 587   | **571** (-3%)    | 10.94 | **10.93** |
| 4    | 242 | 241 (~)        | 2,186 | 2,181 (~)       | 716   | 716 (~)          | 12.51 | 12.50     |
| 8    | 345 | **366** (+6%)  | 3,124 | **3,315** (+6%) | 1,410 | **1,071** (-24%) | 15.16 | 15.54     |
| 16   | 430 | **453** (+5%)  | 3,895 | **4,100** (+5%) | 3,554 | **3,105** (-13%) | 16.61 | 16.92     |
| 32   | 454 | **499** (+10%) | 4,105 | **4,513** (+10%)| 8,141 | **7,217** (-11%) | 19.77 | 20.08     |

### Analysis

- **Throughput improvement**: +6~10% at rate >= 8, driven by larger decode batch sizes
- **TTFT improvement**: -11~29%, most significant at low concurrency (rate=1: 693→493ms)
- **TPOT unchanged**: <2% difference, confirming that per-token decode latency is not affected
- **Mechanism**: higher `--max-running-requests` allows the decode server to accumulate more
  concurrent requests into a single batch, improving GPU utilization for the memory-bound
  decode phase. The TTFT improvement comes from faster KV cache consumption on the decode side,
  which frees prefill server resources sooner
- **Recommendation**: use `--max-running-requests 128` for production deployments

## Performance Analysis (UCX Backend)

Analysis based on UCX backend with `--max-running-requests 128`.
For LIBFABRIC results (significantly better), see the LIBFABRIC section at the top.

### Throughput Scaling

- **Linear range (rate 1-8)**: throughput scales nearly linearly
  - rate 1→8: 715 → 3,315 total tok/s (4.6x for 8x rate increase)
- **Diminishing returns (rate 8-16)**: 3,315 → 4,100 tok/s (1.24x for 2x rate)
- **Saturation (rate 16-32)**: 4,100 → 4,513 tok/s (1.10x for 2x rate)
- **Bottleneck**: prefill server (8 GPU) becomes saturated at rate ~16

### TPOT Stability

TPOT stays remarkably stable across all rates:
- Rate 1: 10.13ms
- Rate 32: 20.08ms (only 1.98x increase for 32x rate increase)
- The dedicated decode server maintains low per-token latency even under load

### TTFT Degradation

TTFT grows rapidly with rate, indicating prefill queueing:
- Rate 1: 493ms
- Rate 8: 1,071ms (2.2x)
- Rate 32: 7,217ms (14.6x)
- This is the primary scaling bottleneck of 1P1D architecture

### Scaling Beyond 1P1D

To improve throughput beyond the rate=32 plateau:
- **More prefill instances**: 2P1D or NP1D to reduce prefill queueing
- **More decode instances**: 1PND for higher aggregate decode throughput
- **Larger TP per prefill**: if more GPUs available per node

## How to Run Benchmarks

### Standard Benchmark

```bash
bash scripts/pd_bench_serving.sh \
  --model /fsx/models/DeepSeek-V3 \
  --port 8000 \
  --rates "1 2 4 8 16 32"
```

### Custom Scenarios

High concurrency, short dialogue:
```bash
bash scripts/pd_bench_serving.sh \
  --model /fsx/models/DeepSeek-V3 \
  --num-prompts 500 \
  --input-len 512 \
  --output-len 128 \
  --rates "4 8 16 32 64"
```

Long context:
```bash
bash scripts/pd_bench_serving.sh \
  --model /fsx/models/DeepSeek-V3 \
  --num-prompts 50 \
  --input-len 8192 \
  --output-len 1024 \
  --rates "1 2 4 8"
```

### Direct Server Benchmark (Skip Router)

Benchmark prefill server directly:
```bash
bash scripts/pd_bench_serving.sh \
  --model /fsx/models/DeepSeek-V3 \
  --port 30000 \
  --rates "1 2 4 8"
```
