# Deployment Guide: DeepSeek-V3 PD Disaggregation on HyperPod EKS

Step-by-step guide to deploy DeepSeek-V3 671B FP8 using 1P1D Prefill-Decode
disaggregation with nixl LIBFABRIC backend on SageMaker HyperPod EKS.

## Prerequisites

- 2x p5en.48xlarge (or p5.48xlarge) nodes with EFA
- FSx for Lustre mounted at `/fsx`
- DeepSeek-V3 model weights at `/fsx/models/DeepSeek-V3`
- Kubernetes pods with: hostNetwork, privileged, IPC_LOCK, 8 GPU, 16+ EFA per pod

## Pod Specification

Key pod resource requirements:

```yaml
resources:
  limits:
    nvidia.com/gpu: "8"
    vpc.amazonaws.com/efa: "16"
    memory: 256Gi
  requests:
    nvidia.com/gpu: "8"
    vpc.amazonaws.com/efa: "16"
    memory: 256Gi
```

Required security context:
```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["IPC_LOCK"]
```

Required volumes:
```yaml
volumes:
  - name: fsx
    hostPath:
      path: /fsx
  - name: dshm
    emptyDir:
      medium: Memory
      sizeLimit: 64Gi
```

## Step 1: Initialize Worker Pods

Run on **both** node0 and node1:

```bash
# Copy init script
kubectl cp scripts/pd_init_worker.sh uccl-ep-node0:/tmp/pd_init_worker.sh
kubectl cp scripts/pd_init_worker.sh uccl-ep-node1:/tmp/pd_init_worker.sh

# Run init (without GDRCopy)
kubectl exec uccl-ep-node0 -- bash /tmp/pd_init_worker.sh
kubectl exec uccl-ep-node1 -- bash /tmp/pd_init_worker.sh

# Or with optional GDRCopy
kubectl exec uccl-ep-node0 -- bash /tmp/pd_init_worker.sh --with-gdrcopy
kubectl exec uccl-ep-node1 -- bash /tmp/pd_init_worker.sh --with-gdrcopy
```

The DLC image (`sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci`)
already includes sglang, nixl, sglang_router, and EFA libraries. The init script:
- Adds system dependencies, verifies EFA
- **Patches sglang's nixl conn.py** so that `SGLANG_DISAGGREGATION_NIXL_BACKEND=LIBFABRIC`
  is actually read and passed to nixl (SGLang 0.5.8 ignores this env var without the patch)
- **Symlinks DeepGEMM cache** to shared FSx (`~/.cache/deep_gemm` → `/fsx/deep_gemm_cache`)
  so compiled kernels persist across restarts

Verification output should show:
```
  Python:       Python 3.12.x
  PyTorch:      2.9.1+cu129
  SGLang:       0.5.8
  nixl:         OK
  sglang-router:OK
  EFA:          provider: efa
  GPUs:         8
  Patched conn.py for LIBFABRIC backend support
  Symlinked /root/.cache/deep_gemm -> /fsx/deep_gemm_cache
```

**Important**: After launching servers, verify LIBFABRIC is active in the logs:
```bash
kubectl exec uccl-ep-node0 -- grep "Selected backend" /tmp/pd_prefill.log
# Should show: Selected backend: LIBFABRIC
# If it shows UCX, the conn.py patch was not applied — re-run init
```

## Step 2: Get Node IPs

```bash
NODE0_IP=$(kubectl exec uccl-ep-node0 -- bash -c \
  "ip addr show | grep 'inet 10\.' | head -1 | awk '{print \$2}' | cut -d/ -f1")
NODE1_IP=$(kubectl exec uccl-ep-node1 -- bash -c \
  "ip addr show | grep 'inet 10\.' | head -1 | awk '{print \$2}' | cut -d/ -f1")
echo "Node0 (Prefill): $NODE0_IP"
echo "Node1 (Decode):  $NODE1_IP"
```

Important: Use `10.x.x.x` IPs (EFA data-plane), not `172.18.x.x` (HyperPod internal).

## Step 3: Copy Launch Script

```bash
kubectl cp scripts/pd_launch_libfabric.sh uccl-ep-node0:/tmp/pd_launch_libfabric.sh
kubectl cp scripts/pd_launch_libfabric.sh uccl-ep-node1:/tmp/pd_launch_libfabric.sh
```

## Step 4: Launch Prefill Server (Node0)

```bash
kubectl exec uccl-ep-node0 -- bash -c \
  "nohup bash /tmp/pd_launch_libfabric.sh prefill $NODE0_IP $NODE1_IP /fsx/models/DeepSeek-V3 8 \
   > /tmp/pd_prefill.log 2>&1 &"
```

Monitor:
```bash
kubectl exec uccl-ep-node0 -- tail -f /tmp/pd_prefill.log
```

## Step 5: Launch Decode Server (Node1)

```bash
kubectl exec uccl-ep-node1 -- bash -c \
  "nohup bash /tmp/pd_launch_libfabric.sh decode $NODE0_IP $NODE1_IP /fsx/models/DeepSeek-V3 8 \
   > /tmp/pd_decode.log 2>&1 &"
```

**Recommended**: For higher throughput, add `--max-running-requests 128` to the decode
server launch command in `pd_launch_libfabric.sh`. This allows larger decode batches and
improves throughput by ~10% at high concurrency with no TPOT degradation.
See `references/benchmarking.md` for detailed comparison.

Monitor:
```bash
kubectl exec uccl-ep-node1 -- tail -f /tmp/pd_decode.log
```

## Step 6: Wait for Servers to be Ready

Both servers go through these phases:
1. Weight loading (~3 min): 163 safetensors shards
2. NCCL init (~30s)
3. DeepGEMM JIT warmup (2-15 min depending on cache state)
   - Cold cache (first ever run): compiles ~278 kernels, ~15 min
   - Warm cache (FSx symlink populated): loads pre-compiled, ~2 min
4. Server warmup (~30s)

Check readiness:
```bash
# Poll until both return 1
kubectl exec uccl-ep-node0 -- grep -c "fired up" /tmp/pd_prefill.log
kubectl exec uccl-ep-node1 -- grep -c "fired up" /tmp/pd_decode.log
```

Or use a monitoring loop:
```bash
while true; do
  P=$(kubectl exec uccl-ep-node0 -- grep -c "fired up" /tmp/pd_prefill.log 2>/dev/null || echo 0)
  D=$(kubectl exec uccl-ep-node1 -- grep -c "fired up" /tmp/pd_decode.log 2>/dev/null || echo 0)
  echo "Prefill ready: $P, Decode ready: $D"
  [ "$P" -ge 1 ] && [ "$D" -ge 1 ] && echo "BOTH READY" && break
  sleep 30
done
```

## Step 7: Launch Router (Node0)

Only start the router after both servers are ready:

```bash
kubectl exec uccl-ep-node0 -- bash -c \
  "nohup bash /tmp/pd_launch_libfabric.sh router $NODE0_IP $NODE1_IP \
   > /tmp/pd_router.log 2>&1 &"
```

Verify router registered both workers:
```bash
kubectl exec uccl-ep-node0 -- grep "Activated" /tmp/pd_router.log
# Should show: Activated 1 worker(s) (marked as healthy)  (twice)
```

## Step 8: Verify End-to-End

```bash
kubectl exec uccl-ep-node0 -- curl -s http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "/fsx/models/DeepSeek-V3",
    "messages": [{"role": "user", "content": "Say hello in one sentence."}],
    "max_tokens": 50
  }'
```

Expected: JSON response with `choices[0].message.content` containing a greeting.

Health checks:
```bash
kubectl exec uccl-ep-node0 -- curl -s http://127.0.0.1:8000/health   # Router
kubectl exec uccl-ep-node0 -- curl -s http://127.0.0.1:30000/health  # Prefill
kubectl exec uccl-ep-node1 -- curl -s http://127.0.0.1:30001/health  # Decode
```

## Step 9: Run Benchmark

```bash
kubectl cp scripts/pd_bench_serving.sh uccl-ep-node0:/tmp/pd_bench_serving.sh

kubectl exec uccl-ep-node0 -- bash /tmp/pd_bench_serving.sh \
  --model /fsx/models/DeepSeek-V3 \
  --port 8000 \
  --rates "1 2 4 8 16 32"
```

This runs `sglang.bench_serving` at each rate with 100 random prompts
(input ~2048, output ~256 tokens).

## Stopping Services

```bash
# Find and kill processes
kubectl exec uccl-ep-node0 -- bash -c "pkill -f 'sglang.launch_server|sglang_router'"
kubectl exec uccl-ep-node1 -- bash -c "pkill -f 'sglang.launch_server'"

# Verify GPU memory is released
kubectl exec uccl-ep-node0 -- nvidia-smi --query-gpu=index,memory.used --format=csv,noheader
kubectl exec uccl-ep-node1 -- nvidia-smi --query-gpu=index,memory.used --format=csv,noheader
```

## Deploying Other Models

The scripts support any model and TP degree:

```bash
# Qwen3-8B, TP=1 (lightweight validation)
pd_launch_libfabric.sh prefill $NODE0_IP $NODE1_IP /fsx/models/Qwen3-8B 1
pd_launch_libfabric.sh decode  $NODE0_IP $NODE1_IP /fsx/models/Qwen3-8B 1
pd_launch_libfabric.sh router  $NODE0_IP $NODE1_IP

# DeepSeek-V2, TP=8
pd_launch_libfabric.sh prefill $NODE0_IP $NODE1_IP /fsx/models/DeepSeek-V2 8
pd_launch_libfabric.sh decode  $NODE0_IP $NODE1_IP /fsx/models/DeepSeek-V2 8
pd_launch_libfabric.sh router  $NODE0_IP $NODE1_IP
```

## Environment Variables Reference

### EFA + NCCL
| Variable | Value | Purpose |
|----------|-------|---------|
| `NCCL_SOCKET_IFNAME` | `enp` | NCCL socket interface prefix |
| `NCCL_NET_PLUGIN` | `libnccl-net-ofi.so` | OFI network plugin |
| `FI_PROVIDER` | `efa` | Libfabric EFA provider |
| `FI_EFA_USE_DEVICE_RDMA` | `1` | Enable device RDMA |
| `NCCL_PROTO` | `Simple` | NCCL protocol |

### nixl LIBFABRIC
| Variable | Value | Purpose |
|----------|-------|---------|
| `SGLANG_DISAGGREGATION_NIXL_BACKEND` | `LIBFABRIC` | nixl backend selection |
| `FI_EFA_FORK_SAFE` | `1` | Fork safety for EFA |
| `FI_EFA_USE_HUGE_PAGE` | `0` | Disable huge pages |
| `FI_MR_CACHE_MONITOR` | `disabled` | Disable MR cache monitor |
| `UCX_NET_DEVICES` | `<auto>` | UCX interface (required even for LIBFABRIC) |

### JIT Caches
| Variable | Value | Purpose |
|----------|-------|---------|
| `DG_JIT_CACHE_DIR` | `/fsx/deep_gemm_cache` | DeepGEMM kernel cache (env var ignored in this DLC; symlink used instead) |
| `TRITON_CACHE_DIR` | `/fsx/triton-cache` | Triton kernel cache |
| `FLASHINFER_CACHE_DIR` | `/fsx/flashinfer-cache` | FlashInfer cache |
| `TORCHINDUCTOR_CACHE_DIR` | `/fsx/torchinductor-cache` | TorchInductor cache |

**Note on DeepGEMM cache**: The `DG_JIT_CACHE_DIR` env var is ignored by the DeepGEMM
version in this DLC image. DeepGEMM always writes to `~/.cache/deep_gemm/cache/`.
The init script creates a symlink `~/.cache/deep_gemm` → `/fsx/deep_gemm_cache` to
persist kernels on shared FSx. Prefill (278 kernels) and decode (251 kernels, strict
subset) safely share the same cache directory.
