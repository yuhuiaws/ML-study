#!/bin/bash
# Launch sglang with NCCL backend for DeepSeek-V3 on a single P5en.48xlarge node.
# Configuration: TP=8, EP=8 (single node, 8 GPUs, all-to-all via NVLink/NCCL)
#
# Usage: launch_sglang_nccl_ep8_tp8.sh [model_path]
#   model_path: path to model weights (default: /fsx/models/DeepSeek-V3)
set -e
export PYTHONUNBUFFERED=1

MODEL_PATH=${1:-/fsx/models/DeepSeek-V3}

# --- EFA + NCCL environment ---
export CUDA_HOME=/usr/local/cuda
export EFA_HOME=/opt/amazon/efa
export LD_LIBRARY_PATH=/opt/amazon/ofi-nccl/lib/x86_64-linux-gnu:$EFA_HOME/lib64:$CUDA_HOME/lib64:$LD_LIBRARY_PATH
export PATH=$EFA_HOME/bin:$CUDA_HOME/bin:$PATH

export NCCL_SOCKET_IFNAME=enp
export NCCL_NET_PLUGIN=libnccl-net-ofi.so
export FI_PROVIDER=efa
export FI_EFA_USE_DEVICE_RDMA=1
export NCCL_PROTO=Simple

# --- Fix missing cuobjdump in DLC (DeepGEMM JIT needs it) ---
if ! command -v cuobjdump &>/dev/null; then
  TRITON_CUOBJDUMP=$(python3 -c "import triton; import os; print(os.path.join(os.path.dirname(triton.__file__), 'backends/nvidia/bin/cuobjdump'))" 2>/dev/null)
  if [ -f "$TRITON_CUOBJDUMP" ]; then
    ln -sf "$TRITON_CUOBJDUMP" /usr/local/cuda/bin/cuobjdump
    echo ">>> Fixed: symlinked cuobjdump from Triton to CUDA bin"
  fi
fi

# --- DeepGEMM JIT cache (shared FSx for persistence across restarts) ---
export DG_JIT_CACHE_DIR=/fsx/deepseek_v3/tp8ep8/deep_gemm_cache
export SGLANG_DG_CACHE_DIR=/fsx/deepseek_v3/tp8ep8/deep_gemm_cache
mkdir -p /fsx/deepseek_v3/tp8ep8/deep_gemm_cache

# --- Cache directories ---
export TRITON_CACHE_DIR=/fsx/triton-cache
export TORCHINDUCTOR_CACHE_DIR=/fsx/torchinductor-cache
export FLASHINFER_CACHE_DIR=/fsx/flashinfer-cache

# --- Fix hostname resolution (HyperPod 172.x -> 10.x) ---
MYIP=$(hostname -I | awk '{print $1}')
MYHOST=$(hostname)
cp /etc/hosts /tmp/hosts.bak
grep -v "$MYHOST" /tmp/hosts.bak > /tmp/hosts.new || true
echo "$MYIP $MYHOST" >> /tmp/hosts.new
cp /tmp/hosts.new /etc/hosts
echo ">>> Single-node: $MYHOST @ $MYIP, backend=NCCL, TP=8, EP=8"

# DeepGEMM cold-cache JIT compilation takes 10-20 min on first run.
export SGLANG_WARMUP_TIMEOUT=1800

# --- Launch sglang ---
# Single node: 1 node x 8 GPUs = 8 GPUs total
# TP=8: tensor parallelism across 8 GPUs (NVLink)
# EP=8: expert parallelism across 8 GPUs (NVLink)
# --moe-a2a-backend none: use NCCL for MoE all-to-all
# --moe-runner-backend deep_gemm: DeepGEMM for expert computation
# --mem-fraction-static 0.78: weights ~84GB/GPU, leaves room for KV cache + CUDA graphs
echo ">>> Launching sglang: model=$MODEL_PATH, tp=8, ep=8, nnodes=1, backend=NCCL"
python3 -m sglang.launch_server \
  --model-path "$MODEL_PATH" \
  --tp 8 \
  --ep 8 \
  --nnodes 1 \
  --node-rank 0 \
  --moe-a2a-backend none \
  --moe-runner-backend deep_gemm \
  --trust-remote-code \
  --port 30000 \
  --mem-fraction-static 0.78 \
  --host 0.0.0.0 \
  --watchdog-timeout 1200
