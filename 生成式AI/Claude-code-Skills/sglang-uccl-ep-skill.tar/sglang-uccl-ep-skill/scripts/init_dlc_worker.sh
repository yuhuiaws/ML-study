#!/bin/bash
# Initialize a DLC (Deep Learning Container) worker for DeepSeek-V3 serving with UCCL-EP.
#
# Container image: public.ecr.aws/deep-learning-containers/sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci
# This image already has: SGLang 0.5.8, Python 3.12, PyTorch 2.9.1, CUDA 12.9, EFA.
# This script adds: UCCL-EP (EFA-compatible expert-parallel comm) + deep_ep wrapper.
#
# Usage: Run inside each worker pod before launching sglang.
#   bash init_dlc_worker.sh
#
# Prerequisites:
#   - FSx mounted at /fsx
#   - Pod has GPU + EFA resources allocated
set -e
export DEBIAN_FRONTEND=noninteractive

echo ">>> [$(hostname)] DLC Worker Init - Start"
echo ">>> Python: $(python3 --version 2>&1)"
echo ">>> PyTorch: $(python3 -c 'import torch; print(torch.__version__)' 2>&1)"
echo ">>> CUDA: $(nvcc --version 2>&1 | grep release || echo 'nvcc not found')"

# ---- Step 1: System dependencies for UCCL-EP build ----
echo ">>> [$(hostname)] Step 1: System dependencies"
apt-get update -qq
apt-get install -y -qq \
  build-essential git curl wget \
  rdma-core libibverbs-dev libnuma-dev librdmacm-dev \
  libgoogle-glog-dev libnl-3-dev libnl-route-3-dev \
  python3-dev \
  libevent-dev libhwloc-dev \
  pciutils iproute2 2>&1 | tail -2
echo ">>> [$(hostname)] System deps done"

# ---- Step 2: EFA installer (inside container) ----
echo ">>> [$(hostname)] Step 2: EFA"
export EFA_HOME=/opt/amazon/efa
export CUDA_HOME=/usr/local/cuda

# Check if EFA is already installed in the DLC
if [ -f "$EFA_HOME/bin/fi_info" ]; then
  echo ">>> [$(hostname)] EFA already installed: $(fi_info --version 2>&1 || $EFA_HOME/bin/fi_info --version 2>&1)"
else
  echo ">>> [$(hostname)] Installing EFA..."
  cd /tmp
  curl -sO https://efa-installer.amazonaws.com/aws-efa-installer-1.42.0.tar.gz
  tar -xf aws-efa-installer-1.42.0.tar.gz
  cd aws-efa-installer
  ./efa_installer.sh -y --skip-kmod -g --no-verify 2>&1 | tail -3
  echo ">>> [$(hostname)] EFA installed: $($EFA_HOME/bin/fi_info --version 2>&1)"
fi

export LD_LIBRARY_PATH=/opt/amazon/ofi-nccl/lib/x86_64-linux-gnu:$EFA_HOME/lib64:$CUDA_HOME/lib64:$LD_LIBRARY_PATH
export PATH=$EFA_HOME/bin:$CUDA_HOME/bin:$PATH

# ---- Step 3: Build UCCL-EP ----
echo ">>> [$(hostname)] Step 3: Build UCCL-EP"
UCCL_DIR=${UCCL_DIR:-/fsx/uccl}
INSTALL_DIR=${INSTALL_DIR:-/fsx/uccl-ep-install/uccl-pkg}

# Ensure pybind11 and numpy are available for UCCL-EP build
pip3 install pybind11 nanobind numpy 2>&1 | tail -1

if [ ! -d "$UCCL_DIR" ]; then
  echo ">>> [$(hostname)] Cloning UCCL..."
  git clone https://github.com/uccl-project/uccl.git "$UCCL_DIR"
fi

# Build to match DLC's PyTorch version
SITE_PKG=$(python3 -c "import site; print(site.getsitepackages()[0])")
TORCH_VERSION=$(python3 -c "import torch; print(torch.__version__)")

echo ">>> [$(hostname)] Building UCCL-EP for PyTorch $TORCH_VERSION..."
cd "$UCCL_DIR/ep"
make clean 2>/dev/null || true
make -j$(nproc)

# Install to site-packages
make install
mkdir -p "$INSTALL_DIR"
cp ep.abi3.so "$INSTALL_DIR/"

# Also ensure it's in the Python path
mkdir -p "$SITE_PKG/uccl"
cp ep.abi3.so "$SITE_PKG/uccl/"
touch "$SITE_PKG/uccl/__init__.py"

echo ">>> [$(hostname)] UCCL-EP built: $(du -h $INSTALL_DIR/ep.abi3.so | cut -f1)"
python3 -c "import uccl.ep; print('>>> UCCL-EP import OK')"

# ---- Step 4: Install deep_ep wrapper ----
# The DLC has a residual deep_ep directory that must be cleaned before install.
echo ">>> [$(hostname)] Step 4: Install deep_ep wrapper"
pip3 uninstall -y deep_ep 2>/dev/null || true
rm -rf "$SITE_PKG/deep_ep" "$SITE_PKG/deep_ep.stock_bak"
cd "$UCCL_DIR/ep/deep_ep_wrapper"
pip install . 2>&1 | tail -2
python3 -c "from deep_ep import Buffer, Config; print('>>> deep_ep import OK')"

# ---- Step 5: Fix hostname resolution ----
echo ">>> [$(hostname)] Step 5: Fix hostname resolution"
MYIP=$(hostname -I | awk '{print $1}')
MYHOST=$(hostname)
# Remove any existing entry for this hostname, then add correct one
cp /etc/hosts /tmp/hosts.bak
grep -v "$MYHOST" /tmp/hosts.bak > /tmp/hosts.new || true
echo "$MYIP $MYHOST" >> /tmp/hosts.new
cp /tmp/hosts.new /etc/hosts
echo ">>> [$(hostname)] Hostname: $MYHOST -> $MYIP"

# ---- Step 6: Create cache directories ----
echo ">>> [$(hostname)] Step 6: Cache directories"
mkdir -p /tmp/deep_gemm_cache
mkdir -p /fsx/triton-cache
mkdir -p /fsx/torchinductor-cache
mkdir -p /fsx/flashinfer-cache

# ---- Verify ----
echo ">>> [$(hostname)] Verification:"
echo "  Python:    $(python3 --version 2>&1)"
echo "  PyTorch:   $TORCH_VERSION"
echo "  SGLang:    $(python3 -c 'import sglang; print(sglang.__version__)' 2>&1)"
echo "  UCCL-EP:   $(python3 -c 'import uccl.ep; print("OK")' 2>&1)"
echo "  deep_ep:   $(python3 -c 'from deep_ep import Buffer; print("OK")' 2>&1)"
echo "  EFA:       $(fi_info --version 2>&1 || echo 'N/A')"
echo "  GPUs:      $(python3 -c 'import torch; print(torch.cuda.device_count())' 2>&1)"
echo ">>> [$(hostname)] DLC WORKER INIT COMPLETE"
