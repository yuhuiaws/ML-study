#!/bin/bash
# Launch sglang with NCCL backend for DeepSeek-V3 on 2-node P5en.48xlarge.
# Configuration: TP=16 (across 2 nodes), EP=8 (intra-node MoE via NCCL/NVLink)
#
# Usage: launch_sglang_nccl_ep8_tp16.sh <node_rank> <master_addr> [model_path]
#   node_rank:   0 or 1
#   master_addr: IP of node0 (10.x.x.x)
#   model_path:  path to model (default: /fsx/models/DeepSeek-V3)
set -e
export PYTHONUNBUFFERED=1

NODE_RANK=${1:?Usage: $0 <node_rank> <master_addr> [model_path]}
MASTER_ADDR=${2:?Usage: $0 <node_rank> <master_addr> [model_path]}
MODEL_PATH=${3:-/fsx/models/DeepSeek-V3}

# --- EFA + NCCL environment ---
export CUDA_HOME=/usr/local/cuda
export EFA_HOME=/opt/amazon/efa
# DLC has NCCL OFI plugin at /opt/amazon/ofi-nccl/lib/ (not x86_64-linux-gnu)
export LD_LIBRARY_PATH=/opt/amazon/ofi-nccl/lib:$EFA_HOME/lib:$CUDA_HOME/lib64:$LD_LIBRARY_PATH
export PATH=$EFA_HOME/bin:$CUDA_HOME/bin:$PATH

export NCCL_SOCKET_IFNAME=enp
export NCCL_NET_PLUGIN=libnccl-net-ofi.so
export FI_PROVIDER=efa
export FI_EFA_USE_DEVICE_RDMA=1
export NCCL_PROTO=Simple

# --- Fix missing cuobjdump in DLC (DeepGEMM JIT needs it to extract kernel symbols) ---
if ! command -v cuobjdump &>/dev/null; then
  TRITON_CUOBJDUMP=$(python3 -c "import triton; import os; print(os.path.join(os.path.dirname(triton.__file__), 'backends/nvidia/bin/cuobjdump'))" 2>/dev/null)
  if [ -f "$TRITON_CUOBJDUMP" ]; then
    ln -sf "$TRITON_CUOBJDUMP" /usr/local/cuda/bin/cuobjdump
    echo ">>> Fixed: symlinked cuobjdump from Triton to CUDA bin"
  fi
fi

# --- DeepGEMM JIT cache (use FSx shared cache with 278 pre-compiled kernels) ---
export DG_JIT_CACHE_DIR=/fsx/deep_gemm_cache
mkdir -p /fsx/deep_gemm_cache

# --- Fix hostname resolution (HyperPod 172.x -> 10.x) ---
MYIP=$(hostname -I | awk '{print $1}')
MYHOST=$(hostname)
cp /etc/hosts /tmp/hosts.bak
grep -v "$MYHOST" /tmp/hosts.bak > /tmp/hosts.new || true
echo "$MYIP $MYHOST" >> /tmp/hosts.new
cp /tmp/hosts.new /etc/hosts
echo ">>> Node $NODE_RANK: $MYHOST @ $MYIP, master=$MASTER_ADDR"

# --- Cache directories ---
export TRITON_CACHE_DIR=/fsx/triton-cache
export TORCHINDUCTOR_CACHE_DIR=/fsx/torchinductor-cache
export FLASHINFER_CACHE_DIR=/fsx/flashinfer-cache

# DeepGEMM cold-cache JIT compilation takes 10-20 min on first run.
export SGLANG_WARMUP_TIMEOUT=1800

# --- Launch sglang ---
# DeepSeek-V3: 2 nodes x 8 GPUs = 16 GPUs total
# TP=16: tensor parallelism across all 16 GPUs
# EP=8: expert parallelism intra-node (MoE all-to-all over NVLink via NCCL)
# --moe-runner-backend deep_gemm: DeepGEMM for expert computation
# --mem-fraction-static 0.85: P5en H200 has 140 GB, ample headroom
echo ">>> Launching sglang: model=$MODEL_PATH, tp=16, ep=8, backend=NCCL"
python3 -m sglang.launch_server \
  --model-path "$MODEL_PATH" \
  --tp 16 \
  --ep 8 \
  --nnodes 2 \
  --node-rank "$NODE_RANK" \
  --dist-init-addr "${MASTER_ADDR}:25001" \
  --moe-runner-backend deep_gemm \
  --trust-remote-code \
  --port 30000 \
  --mem-fraction-static 0.80 \
  --host 0.0.0.0 \
  --watchdog-timeout 1200 \
  --cuda-graph-max-bs 32
