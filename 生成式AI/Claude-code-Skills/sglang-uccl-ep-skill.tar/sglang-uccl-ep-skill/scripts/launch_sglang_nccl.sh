#!/bin/bash
# Launch sglang with NCCL backend (--moe-a2a-backend none) for DeepSeek-V3 on 2-node cluster.
#
# This is the RECOMMENDED backend for AWS EFA — 2.3x faster than UCCL-EP at single-request
# latency, 1.6x faster at high concurrency (rate=32).
#
# Container image: public.ecr.aws/deep-learning-containers/sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci
# Architecture: 2 nodes x 8 GPUs = 16 GPUs, TP=16, EP=16
# Model: DeepSeek-V3 (671B MoE, 256 experts, top-8 routing, FP8)
#
# Usage:
#   bash launch_sglang_nccl.sh <node_rank> <master_addr> [model_path]
#
#   node_rank:   0 or 1
#   master_addr: IP of node0 (10.x.x.x, NOT 172.x.x.x)
#   model_path:  path to model weights (default: /fsx/models/DeepSeek-V3)
#
# Examples:
#   # Node 0 (master):
#   bash launch_sglang_nccl.sh 0 10.3.103.129
#   # Node 1 (worker):
#   bash launch_sglang_nccl.sh 1 10.3.103.129
set -e
export PYTHONUNBUFFERED=1

NODE_RANK=${1:?Usage: $0 <node_rank> <master_addr> [model_path]}
MASTER_ADDR=${2:?Usage: $0 <node_rank> <master_addr> [model_path]}
MODEL_PATH=${3:-/fsx/models/DeepSeek-V3}

# --- EFA + NCCL environment ---
export CUDA_HOME=/usr/local/cuda
export EFA_HOME=/opt/amazon/efa
export LD_LIBRARY_PATH=/opt/amazon/ofi-nccl/lib/x86_64-linux-gnu:$EFA_HOME/lib64:$CUDA_HOME/lib64:$LD_LIBRARY_PATH
export PATH=$EFA_HOME/bin:$CUDA_HOME/bin:$PATH

export NCCL_SOCKET_IFNAME=enp
export NCCL_NET_PLUGIN=libnccl-net-ofi.so
export FI_PROVIDER=efa
export FI_EFA_USE_DEVICE_RDMA=1
export NCCL_PROTO=Simple

# --- Fix missing cuobjdump in DLC (DeepGEMM JIT needs it to extract kernel symbols) ---
if ! command -v cuobjdump &>/dev/null; then
  TRITON_CUOBJDUMP=$(python3 -c "import triton; import os; print(os.path.join(os.path.dirname(triton.__file__), 'backends/nvidia/bin/cuobjdump'))" 2>/dev/null)
  if [ -f "$TRITON_CUOBJDUMP" ]; then
    ln -sf "$TRITON_CUOBJDUMP" /usr/local/cuda/bin/cuobjdump
    echo ">>> Fixed: symlinked cuobjdump from Triton to CUDA bin"
  fi
fi

# --- DeepGEMM JIT cache (must be /tmp, avoid FSx race conditions) ---
export DG_JIT_CACHE_DIR=/tmp/deep_gemm_cache
export SGLANG_DG_CACHE_DIR=/tmp/deep_gemm_cache
mkdir -p /tmp/deep_gemm_cache

# --- Cache directories ---
export TRITON_CACHE_DIR=/fsx/triton-cache
export TORCHINDUCTOR_CACHE_DIR=/fsx/torchinductor-cache
export FLASHINFER_CACHE_DIR=/fsx/flashinfer-cache

# --- Fix hostname resolution (HyperPod 172.x -> 10.x) ---
MYIP=$(hostname -I | awk '{print $1}')
MYHOST=$(hostname)
cp /etc/hosts /tmp/hosts.bak
grep -v "$MYHOST" /tmp/hosts.bak > /tmp/hosts.new || true
echo "$MYIP $MYHOST" >> /tmp/hosts.new
cp /tmp/hosts.new /etc/hosts
echo ">>> Node $NODE_RANK: $MYHOST @ $MYIP, master=$MASTER_ADDR, backend=NCCL"

# DeepGEMM cold-cache JIT compilation takes 10-20 min on first run.
export SGLANG_WARMUP_TIMEOUT=1800

# --- Detect mem-fraction-static based on GPU memory ---
# p5en H200: 141 GB -> 0.90, p5 H100: 80 GB -> 0.80
# NCCL can use more GPU memory than UCCL-EP (no RDMA buffer reservation needed)
GPU_MEM_MB=$(python3 -c "import torch; p=torch.cuda.get_device_properties(0); print(getattr(p,'total_memory',getattr(p,'total_mem',0))//(1024*1024))")
if [ "$GPU_MEM_MB" -gt 100000 ]; then
  MEM_FRACTION=0.85
  echo ">>> Detected H200 (${GPU_MEM_MB} MB), using mem-fraction-static=$MEM_FRACTION"
else
  MEM_FRACTION=0.75
  echo ">>> Detected H100 (${GPU_MEM_MB} MB), using mem-fraction-static=$MEM_FRACTION"
fi

# --- Launch sglang ---
# DeepSeek-V3: 2 nodes x 8 GPUs = 16 GPUs total
# --moe-a2a-backend none: use NCCL for MoE all-to-all (NOT "nccl", which is invalid)
# --moe-runner-backend deep_gemm: DeepGEMM for MoE expert computation
echo ">>> Launching sglang: model=$MODEL_PATH, tp=16, ep=16, backend=NCCL (moe-a2a-backend=none)"
python3 -m sglang.launch_server \
  --model-path "$MODEL_PATH" \
  --tp 16 \
  --ep 16 \
  --nnodes 2 \
  --node-rank "$NODE_RANK" \
  --dist-init-addr "${MASTER_ADDR}:25001" \
  --moe-a2a-backend none \
  --moe-runner-backend deep_gemm \
  --trust-remote-code \
  --port 30000 \
  --mem-fraction-static "$MEM_FRACTION" \
  --host 0.0.0.0 \
  --watchdog-timeout 1200
