#!/bin/bash
# Launch sglang with UCCL-EP (DeepEP) backend for DeepSeek-V3 on 2-node cluster.
#
# Container image: public.ecr.aws/deep-learning-containers/sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci
# Architecture: 2 nodes x 8 GPUs = 16 GPUs, TP=16, EP=16
# Model: DeepSeek-V3 (671B MoE, 256 experts, top-8 routing, FP8)
#
# Usage:
#   bash launch_sglang_dlc.sh <node_rank> <master_addr> [model_path] [deepep_mode]
#
#   node_rank:   0 or 1
#   master_addr: IP of node0 (10.x.x.x, NOT 172.x.x.x)
#   model_path:  path to model weights (default: /fsx/models/DeepSeek-V3)
#   deepep_mode: low_latency or normal (default: low_latency)
#
# Examples:
#   # Node 0 (master):
#   bash launch_sglang_dlc.sh 0 10.3.103.129
#   # Node 1 (worker):
#   bash launch_sglang_dlc.sh 1 10.3.103.129
set -e
export PYTHONUNBUFFERED=1

NODE_RANK=${1:?Usage: $0 <node_rank> <master_addr> [model_path] [deepep_mode]}
MASTER_ADDR=${2:?Usage: $0 <node_rank> <master_addr> [model_path] [deepep_mode]}
MODEL_PATH=${3:-/fsx/models/DeepSeek-V3}
DEEPEP_MODE=${4:-low_latency}

# --- EFA + NCCL environment ---
export CUDA_HOME=/usr/local/cuda
export EFA_HOME=/opt/amazon/efa
export LD_LIBRARY_PATH=/opt/amazon/ofi-nccl/lib/x86_64-linux-gnu:$EFA_HOME/lib64:$CUDA_HOME/lib64:$LD_LIBRARY_PATH
export PATH=$EFA_HOME/bin:$CUDA_HOME/bin:$PATH

export NCCL_SOCKET_IFNAME=enp
export NCCL_NET_PLUGIN=libnccl-net-ofi.so
export FI_PROVIDER=efa
export FI_EFA_USE_DEVICE_RDMA=1
export NCCL_PROTO=Simple
export UCCL_SOCKET_IFNAME=enp

# --- UCCL-EP tuning ---
# Increase low-latency inflight writes from default 32 to 64
# to better utilize p5en EFAv2 bandwidth (100 Gbps/lane, 131KB max_msg_sz)
export UCCL_IB_MAX_INFLIGHT_LOW_LATENCY=128

# --- Fix missing cuobjdump in DLC (DeepGEMM JIT needs it to extract kernel symbols) ---
if ! command -v cuobjdump &>/dev/null; then
  TRITON_CUOBJDUMP=$(python3 -c "import triton; import os; print(os.path.join(os.path.dirname(triton.__file__), 'backends/nvidia/bin/cuobjdump'))" 2>/dev/null)
  if [ -f "$TRITON_CUOBJDUMP" ]; then
    ln -sf "$TRITON_CUOBJDUMP" /usr/local/cuda/bin/cuobjdump
    echo ">>> Fixed: symlinked cuobjdump from Triton to CUDA bin"
  fi
fi

# --- DeepGEMM JIT cache (must be /tmp, avoid FSx race conditions) ---
export DG_JIT_CACHE_DIR=/tmp/deep_gemm_cache
export SGLANG_DG_CACHE_DIR=/tmp/deep_gemm_cache
mkdir -p /tmp/deep_gemm_cache

# --- Cache directories ---
export TRITON_CACHE_DIR=/fsx/triton-cache
export TORCHINDUCTOR_CACHE_DIR=/fsx/torchinductor-cache
export FLASHINFER_CACHE_DIR=/fsx/flashinfer-cache

# --- Fix hostname resolution (HyperPod 172.x -> 10.x) ---
MYIP=$(hostname -I | awk '{print $1}')
MYHOST=$(hostname)
cp /etc/hosts /tmp/hosts.bak
grep -v "$MYHOST" /tmp/hosts.bak > /tmp/hosts.new || true
echo "$MYIP $MYHOST" >> /tmp/hosts.new
cp /tmp/hosts.new /etc/hosts
echo ">>> Node $NODE_RANK: $MYHOST @ $MYIP, master=$MASTER_ADDR, mode=$DEEPEP_MODE"

# DeepGEMM cold-cache JIT compilation takes 10-20 min on first run.
export SGLANG_WARMUP_TIMEOUT=1800

# --- Detect mem-fraction-static based on GPU memory ---
# p5en H200: 141 GB -> 0.85, p5 H100: 80 GB -> 0.70
GPU_MEM_MB=$(python3 -c "import torch; p=torch.cuda.get_device_properties(0); print(getattr(p,'total_memory',getattr(p,'total_mem',0))//(1024*1024))")
if [ "$GPU_MEM_MB" -gt 100000 ]; then
  MEM_FRACTION=0.85
  echo ">>> Detected H200 (${GPU_MEM_MB} MB), using mem-fraction-static=$MEM_FRACTION"
else
  MEM_FRACTION=0.70
  echo ">>> Detected H100 (${GPU_MEM_MB} MB), using mem-fraction-static=$MEM_FRACTION"
fi

# --- Launch sglang ---
# DeepSeek-V3: 2 nodes x 8 GPUs = 16 GPUs total
# --deepep-mode: low_latency (GPU IBGDA on p5en) or normal (throughput mode)
# --moe-runner-backend deep_gemm: DeepGEMM for MoE expert computation
echo ">>> Launching sglang: model=$MODEL_PATH, tp=16, ep=16, deepep_mode=$DEEPEP_MODE"
python3 -m sglang.launch_server \
  --model-path "$MODEL_PATH" \
  --tp 16 \
  --ep 16 \
  --nnodes 2 \
  --node-rank "$NODE_RANK" \
  --dist-init-addr "${MASTER_ADDR}:25001" \
  --moe-a2a-backend deepep \
  --moe-runner-backend deep_gemm \
  --deepep-mode "$DEEPEP_MODE" \
  --trust-remote-code \
  --port 30000 \
  --mem-fraction-static "$MEM_FRACTION" \
  --host 0.0.0.0 \
  --watchdog-timeout 1200
