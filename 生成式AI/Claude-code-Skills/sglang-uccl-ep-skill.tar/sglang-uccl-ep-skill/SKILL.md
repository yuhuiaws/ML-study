---
name: sglang-uccl-ep
description: >
  Deploy DeepSeek-V3 (671B MoE) with SGLang on AWS EFA using the SageMaker
  Deep Learning Container. Supports single-node (1x p5en, TP=8 EP=8) and
  multi-node (2x p5/p5en, TP=16 EP=16) deployments. Covers two MoE communication
  backends: (1) NCCL (default, --moe-a2a-backend none) and (2) UCCL-EP (drop-in
  DeepEP replacement for EFA). Includes full workflow: pod creation, SGLang launch,
  and serving benchmark.
  **Key finding**: Single-node TP8 EP8 on H200 is the optimal config (TPOT 12ms),
  2.2x faster than 2-node TP16 EP16 (TPOT 27ms) due to NVLink vs EFA for all-to-all.
  NCCL outperforms UCCL-EP by 2.3x on EFA.
---

# SGLang + DeepSeek-V3 Deployment on AWS EFA

## Overview

Deploy DeepSeek-V3 (671B MoE, FP8, 256 experts, top-8 routing) using:
- **Container**: `public.ecr.aws/deep-learning-containers/sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci`
- **Serving framework**: SGLang 0.5.8
- **MoE communication**: NCCL (recommended) or UCCL-EP over EFA

### Deployment Configurations

| Config | Hardware | TP | EP | TPOT (rate=1) | Output tok/s (rate=1) | When to Use |
|--------|----------|----|----|---------------|----------------------|-------------|
| **Single-node NCCL (best)** | 1x p5en.48xlarge (8x H200) | 8 | 8 | **12.38 ms** | **76.18** | H200 with 141GB — model fits on 1 node |
| 2-node NCCL EP8 TP16 | 2x p5en.48xlarge (16x H200) | 16 | 8 | 27.10 ms | 35.80 | MoE on NVLink + TP across nodes |
| 2-node NCCL EP16 TP16 | 2x p5en.48xlarge (16x H200) | 16 | 16 | 26.92 ms | 36.04 | Need more KV cache or H100 (80GB) |
| 2-node UCCL-EP | 2x p5en.48xlarge (16x H200) | 16 | 16 | 62.59 ms | 15.70 | Only if GPU RDMA (InfiniBand) available |

**Recommendation**: On p5en (H200 141GB), use **single-node TP=8 EP=8 with NCCL**. The model
fits in memory at ~83 GB/GPU in FP8, and all MoE all-to-all communication stays on NVLink
(900 GB/s) instead of crossing EFA (~100 GB/s), yielding 2.2x lower decode latency than the
2-node setup. Use 2-node only when GPU memory is insufficient (H100 80GB) or larger KV cache
is needed for long-context workloads.

### MoE Backend Options

| Backend | SGLang Flag | Performance (rate=1, 2-node) | When to Use |
|---------|-------------|------------------------------|-------------|
| **NCCL (recommended)** | `--moe-a2a-backend none` | 36 tok/s, TPOT 27ms | Default for EFA clusters |
| UCCL-EP | `--moe-a2a-backend deepep` | 16 tok/s, TPOT 62ms | Only if GPU RDMA (InfiniBand) is available |

On AWS EFA, NCCL's all-to-all via aws-ofi-nccl is 2.3x faster than UCCL-EP's CPU-proxy
approach. UCCL-EP is designed for GPU-initiated RDMA (IBGDA) which EFA does not support.

### Integration Chains

**NCCL path** (recommended on EFA):
```
sglang (--moe-a2a-backend none)
  -> torch.distributed (NCCL all-to-all)
    -> NVLink (single-node) or aws-ofi-nccl (multi-node EFA)
```

**UCCL-EP path** (for comparison / InfiniBand environments):
```
sglang (--moe-a2a-backend deepep)
  -> deep_ep.Buffer   (wrapper, same API as original DeepEP)
    -> uccl.ep         (CPU proxy + libibverbs/libfabric)
      -> AWS EFA RDMA
```

## Prerequisites

- SageMaker HyperPod EKS cluster with:
  - **Single-node**: 1x p5en.48xlarge (H200 141GB) — recommended for best latency
  - **Multi-node**: 2x p5.48xlarge (H100) or p5en.48xlarge (H200) — for larger KV cache
- FSx for Lustre shared storage mounted as PVC (`fsx-claim`)
- DeepSeek-V3 model weights on FSx (e.g., `/fsx/models/DeepSeek-V3`)
- `kubectl` access to the cluster

## Workflow

1. **Create Pods** — Deploy worker pod(s) with GPU + EFA resources
2. **Initialize Workers** — (UCCL-EP only) Build UCCL-EP, install deep_ep wrapper
3. **Launch SGLang** — Start serving with chosen backend and parallelism config
4. **Benchmark** — Run sglang.bench_serving at various concurrency levels

## Step 1: Create Pods

See [references/pod-templates.md](references/pod-templates.md) for complete YAML templates.

### Single-Node (TP=8, EP=8) — Recommended for H200

```bash
# Find a p5en.48xlarge node
kubectl get nodes -o wide

# Create single-node pod (edit nodeSelector to match your node)
kubectl apply -f references/sglang-ep8-tp8-node0.yaml

# Wait for pod to be ready (image pull may take several minutes on first run)
kubectl wait --for=condition=Ready pod/sglang-ep8-tp8-node0 --timeout=600s
```

### Multi-Node (TP=16, EP=16) — For H100 or larger KV cache

```bash
# Edit nodeSelector in each YAML to match your cluster nodes
kubectl get nodes -o wide

# Create pods
kubectl apply -f references/uccl-ep-node0.yaml
kubectl apply -f references/uccl-ep-node1.yaml

# Wait for pods to be ready
kubectl wait --for=condition=Ready pod/uccl-ep-node0 --timeout=300s
kubectl wait --for=condition=Ready pod/uccl-ep-node1 --timeout=300s
```

### Key Pod Spec Requirements

- Image: `public.ecr.aws/deep-learning-containers/sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci`
- `hostNetwork: true`, `hostIPC: true`, `privileged: true`
- 8 GPU + 16 EFA per node, 256 Gi memory, 48 CPUs
- FSx mounted at `/fsx`, `/dev/shm` as 64Gi emptyDir
- Do NOT mount host `/opt/amazon/efa` — the DLC container has EFA pre-installed

### Pre-installed in the DLC Container

The SageMaker DLC already includes:
- SGLang 0.5.8
- Python 3.12.3
- PyTorch 2.9.1+cu129
- CUDA 12.9
- EFA (libfabric 2.3.1)

## Step 2: Initialize Workers

### Option A: NCCL Backend (Recommended)

No additional initialization required. The DLC container has everything needed.
Just set up cache directories and fix hostname resolution:

```bash
kubectl exec uccl-ep-node0 -- bash -c '
  mkdir -p /tmp/deep_gemm_cache /fsx/triton-cache /fsx/torchinductor-cache /fsx/flashinfer-cache
  MYIP=$(hostname -I | awk "{print \$1}"); MYHOST=$(hostname)
  cp /etc/hosts /tmp/hosts.bak
  grep -v "$MYHOST" /tmp/hosts.bak > /tmp/hosts.new || true
  echo "$MYIP $MYHOST" >> /tmp/hosts.new
  cp /tmp/hosts.new /etc/hosts'
# Repeat for node1
```

### Option B: UCCL-EP Backend

Copy and run `scripts/init_dlc_worker.sh` on both nodes:

```bash
# Copy scripts to shared FSx
kubectl exec uccl-ep-node0 -- mkdir -p /fsx/scripts
kubectl cp scripts/init_dlc_worker.sh uccl-ep-node0:/fsx/scripts/init_dlc_worker.sh
kubectl cp scripts/launch_sglang_dlc.sh uccl-ep-node0:/fsx/scripts/launch_sglang_dlc.sh

# Initialize both nodes in parallel
kubectl exec uccl-ep-node0 -- bash /fsx/scripts/init_dlc_worker.sh &
kubectl exec uccl-ep-node1 -- bash /fsx/scripts/init_dlc_worker.sh &
wait
```

The init script:
1. Installs system dependencies (rdma-core, libibverbs-dev, etc.)
2. Verifies EFA is pre-installed in the DLC
3. Clones UCCL repo to `/fsx/uccl` (if not already present)
4. Builds `ep.abi3.so` with EFA flags against the DLC's PyTorch 2.9.1
5. Installs the `deep_ep` wrapper package (non-editable `pip install .`)
6. Fixes hostname resolution (HyperPod 172.x -> 10.x mapping)
7. Creates cache directories

Completion marker: `DLC WORKER INIT COMPLETE`

### DLC-Specific: deep_ep Installation

The DLC container ships with a pre-existing but incomplete `deep_ep` directory at
`/usr/local/lib/python3.12/dist-packages/deep_ep/` (missing `__init__.py` and `buffer.py`).
The init script cleans this up before installing the UCCL wrapper:

```bash
pip3 uninstall -y deep_ep
rm -rf /usr/local/lib/python3.12/dist-packages/deep_ep
rm -rf /usr/local/lib/python3.12/dist-packages/deep_ep.stock_bak
cd /fsx/uccl/ep/deep_ep_wrapper && pip3 install .
```

**Important**: Use `pip install .` (non-editable), NOT `pip install -e .`. The editable
install creates a namespace package that conflicts with the DLC's residual `deep_ep` directory.

## Step 3: Launch SGLang

### Option A: Single-Node NCCL EP8 TP8 (Recommended for H200)

```bash
# Copy launch script to pod
kubectl exec sglang-ep8-tp8-node0 -- mkdir -p /fsx/scripts
kubectl cp scripts/launch_sglang_nccl_ep8_tp8.sh sglang-ep8-tp8-node0:/fsx/scripts/launch_sglang_nccl_ep8_tp8.sh

# Launch SGLang
kubectl exec sglang-ep8-tp8-node0 -- bash -c \
  "nohup bash /fsx/scripts/launch_sglang_nccl_ep8_tp8.sh /fsx/models/DeepSeek-V3 \
   > /fsx/sglang_ep8_tp8.log 2>&1 &"

# Monitor startup
kubectl exec sglang-ep8-tp8-node0 -- tail -f /fsx/sglang_ep8_tp8.log
```

### Option B: 2-Node NCCL EP8 TP16 (Hybrid)

```bash
# Get Node0 IP (must be 10.x.x.x, NOT 172.x.x.x)
NODE0_IP=$(kubectl exec uccl-ep-node0 -- bash -c \
  "hostname -I | awk '{print \$1}'")
echo "Node0 IP: $NODE0_IP"

# Copy launch script
kubectl cp scripts/launch_sglang_nccl_ep8_tp16.sh uccl-ep-node0:/fsx/scripts/launch_sglang_nccl_ep8_tp16.sh

# Launch on both nodes
kubectl exec uccl-ep-node0 -- bash -c \
  "nohup bash /fsx/scripts/launch_sglang_nccl_ep8_tp16.sh 0 $NODE0_IP /fsx/models/DeepSeek-V3 \
   > /fsx/sglang_ep8_tp16_node0.log 2>&1 &"
kubectl exec uccl-ep-node1 -- bash -c \
  "nohup bash /fsx/scripts/launch_sglang_nccl_ep8_tp16.sh 1 $NODE0_IP /fsx/models/DeepSeek-V3 \
   > /fsx/sglang_ep8_tp16_node1.log 2>&1 &"
```

### Option C: 2-Node NCCL EP16 TP16

```bash
# Get Node0 IP (must be 10.x.x.x, NOT 172.x.x.x)
NODE0_IP=$(kubectl exec uccl-ep-node0 -- bash -c \
  "hostname -I | awk '{print \$1}'")
echo "Node0 IP: $NODE0_IP"

# Copy NCCL launch script
kubectl cp scripts/launch_sglang_nccl.sh uccl-ep-node0:/fsx/scripts/launch_sglang_nccl.sh

# Launch on both nodes
kubectl exec uccl-ep-node0 -- bash -c \
  "nohup bash /fsx/scripts/launch_sglang_nccl.sh 0 $NODE0_IP /fsx/models/DeepSeek-V3 \
   > /fsx/sglang_node0.log 2>&1 &"
kubectl exec uccl-ep-node1 -- bash -c \
  "nohup bash /fsx/scripts/launch_sglang_nccl.sh 1 $NODE0_IP /fsx/models/DeepSeek-V3 \
   > /fsx/sglang_node1.log 2>&1 &"
```

### Option D: 2-Node UCCL-EP Backend

```bash
NODE0_IP=$(kubectl exec uccl-ep-node0 -- bash -c \
  "ip addr show | grep 'inet 10\.' | head -1 | awk '{print \$2}' | cut -d/ -f1")
echo "Node0 IP: $NODE0_IP"

# Launch on both nodes
kubectl exec uccl-ep-node0 -- bash -c \
  "nohup bash /fsx/scripts/launch_sglang_dlc.sh 0 $NODE0_IP /fsx/models/DeepSeek-V3 \
   > /fsx/sglang_node0.log 2>&1 &"
kubectl exec uccl-ep-node1 -- bash -c \
  "nohup bash /fsx/scripts/launch_sglang_dlc.sh 1 $NODE0_IP /fsx/models/DeepSeek-V3 \
   > /fsx/sglang_node1.log 2>&1 &"
```

Server ready marker: `"The server is fired up and ready to roll!"`

### SGLang Launch Commands

**Single-node NCCL EP8 TP8** (`launch_sglang_nccl_ep8_tp8.sh`):
```bash
python3 -m sglang.launch_server \
  --model-path /fsx/models/DeepSeek-V3 \
  --tp 8 \
  --ep 8 \
  --nnodes 1 \
  --node-rank 0 \
  --moe-a2a-backend none \
  --moe-runner-backend deep_gemm \
  --trust-remote-code \
  --port 30000 \
  --mem-fraction-static 0.78 \
  --host 0.0.0.0 \
  --watchdog-timeout 1200
```

**2-node NCCL EP8 TP16** (`launch_sglang_nccl_ep8_tp16.sh`):
```bash
python3 -m sglang.launch_server \
  --model-path /fsx/models/DeepSeek-V3 \
  --tp 16 \
  --ep 8 \
  --nnodes 2 \
  --node-rank <0|1> \
  --dist-init-addr <NODE0_IP>:25001 \
  --moe-runner-backend deep_gemm \
  --trust-remote-code \
  --port 30000 \
  --mem-fraction-static 0.80 \
  --host 0.0.0.0 \
  --watchdog-timeout 1200 \
  --cuda-graph-max-bs 32
```

**2-node NCCL EP16 TP16** (`launch_sglang_nccl.sh`):
```bash
python3 -m sglang.launch_server \
  --model-path /fsx/models/DeepSeek-V3 \
  --tp 16 \
  --ep 16 \
  --nnodes 2 \
  --node-rank <0|1> \
  --dist-init-addr <NODE0_IP>:25001 \
  --moe-a2a-backend none \
  --moe-runner-backend deep_gemm \
  --trust-remote-code \
  --port 30000 \
  --mem-fraction-static 0.85 \
  --host 0.0.0.0 \
  --watchdog-timeout 1200
```

**2-node UCCL-EP EP16 TP16** (`launch_sglang_dlc.sh`):
```bash
python3 -m sglang.launch_server \
  --model-path /fsx/models/DeepSeek-V3 \
  --tp 16 \
  --ep 16 \
  --nnodes 2 \
  --node-rank <0|1> \
  --dist-init-addr <NODE0_IP>:25001 \
  --moe-a2a-backend deepep \
  --moe-runner-backend deep_gemm \
  --deepep-mode low_latency \
  --trust-remote-code \
  --port 30000 \
  --mem-fraction-static 0.85 \
  --host 0.0.0.0 \
  --watchdog-timeout 1200
```

**Note**: `--moe-a2a-backend nccl` is NOT a valid option in SGLang 0.5.8. Valid choices
are: `none`, `deepep`, `mooncake`, `ascend_fuseep`. Use `none` for the NCCL path.

### Key SGLang Flags

| Flag | 1-node EP8 TP8 | 2-node EP8 TP16 | 2-node EP16 TP16 | 2-node UCCL-EP | Description |
|------|---------------|----------------|-----------------|----------------|-------------|
| `--tp` / `--ep` | 8 / 8 | 16 / 8 | 16 / 16 | 16 / 16 | Tensor + expert parallelism |
| `--nnodes` | 1 | 2 | 2 | 2 | Number of nodes |
| `--moe-a2a-backend` | `none` | (default) | `none` | `deepep` | MoE all-to-all backend |
| `--moe-runner-backend` | `deep_gemm` | `deep_gemm` | `deep_gemm` | `deep_gemm` | MoE expert computation |
| `--deepep-mode` | N/A | N/A | N/A | `low_latency` | UCCL-EP mode |
| `--mem-fraction-static` | 0.78 | 0.80 | 0.85 | 0.85 | GPU memory for KV cache |
| `--cuda-graph-max-bs` | (default) | 32 | (default) | (default) | Max batch size for CUDA graphs |
| `--watchdog-timeout` | 1200s | 1200s | 1200s | 1200s | DeepGEMM compile time |

### Startup Timeline

| Phase | 1-node EP8 TP8 | 2-node EP16 TP16 | Notes |
|-------|---------------|------------------|-------|
| Distributed init | ~2s | ~10s | Single-node: local only; 2-node: Gloo + NCCL over EFA |
| Model weight loading (163 shards) | ~3 min | ~3 min | FP8 safetensors from FSx |
| UCCL-EP proxy init (UCCL-EP only) | N/A | ~5 min | RDMA buffer allocation, QP setup |
| DeepGEMM JIT compile (cold cache) | ~10-15 min | ~10-15 min | ~16384 kernels; <2s with warm cache |
| CUDA graph capture | ~12 min | ~12 min | All batch size variants |
| **Total (cold start)** | **~25-30 min** | **~25-35 min** | Subsequent starts: ~5 min with warm caches |

### Environment Variables

The launch scripts set these critical environment variables:

```bash
# EFA + NCCL (all configs)
export NCCL_SOCKET_IFNAME=enp
export NCCL_NET_PLUGIN=libnccl-net-ofi.so
export FI_PROVIDER=efa
export FI_EFA_USE_DEVICE_RDMA=1
export NCCL_PROTO=Simple

# UCCL-EP specific (2-node UCCL-EP only)
export UCCL_SOCKET_IFNAME=enp
export UCCL_IB_MAX_INFLIGHT_LOW_LATENCY=128

# DeepGEMM cache
# Single-node: use shared FSx for persistence across restarts
export DG_JIT_CACHE_DIR=/fsx/deepseek_v3/tp8ep8/deep_gemm_cache
export SGLANG_DG_CACHE_DIR=/fsx/deepseek_v3/tp8ep8/deep_gemm_cache
# Multi-node: use /tmp to avoid FSx race conditions between nodes
# export DG_JIT_CACHE_DIR=/tmp/deep_gemm_cache
# export SGLANG_DG_CACHE_DIR=/tmp/deep_gemm_cache

# Other caches (shared FSx for persistence)
export TRITON_CACHE_DIR=/fsx/triton-cache
export TORCHINDUCTOR_CACHE_DIR=/fsx/torchinductor-cache
export FLASHINFER_CACHE_DIR=/fsx/flashinfer-cache
```

### GPU Memory Layout (per GPU, p5en H200 141 GB)

| Component | 1-node EP8 TP8 | 2-node NCCL | 2-node UCCL-EP | Notes |
|-----------|---------------|-------------|----------------|-------|
| Model weights (FP8) | ~83.4 GB | ~42.8 GB | ~42.8 GB | 671B / 8 GPUs vs 671B / 16 GPUs |
| KV cache | ~27.0 GB | ~77.2 GB | ~77.2 GB | mem-fraction: 0.78 vs 0.85 |
| CUDA graphs | ~8.7 GB | ~8.7 GB | ~8.7 GB | All batch size variants |
| Available | ~22.6 GB | ~13.0 GB | ~13.0 GB | Headroom |
| **Total** | ~141.7 GB | ~141.7 GB | ~141.7 GB | H200 HBM |

## Step 4: Test the Server

```bash
# Simple chat completion
curl http://<NODE0_IP>:30000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"/fsx/models/DeepSeek-V3","messages":[{"role":"user","content":"Hello"}],"max_tokens":50}'
```

## Step 5: Benchmark

Use `sglang.bench_serving` to measure throughput and latency. Use `tee` to write
progress to a log file on FSx so you can monitor from another terminal:

```bash
# Single concurrency (latency-focused) — progress logged to /fsx/benchmark_rate1.log
kubectl exec uccl-ep-node0 -- bash -c 'python3 -m sglang.bench_serving \
    --backend sglang \
    --dataset-name random \
    --num-prompts 100 \
    --random-input-len 2048 \
    --random-output-len 256 \
    --random-range-ratio 0.5 \
    --request-rate 1 \
    --max-concurrency 1 \
    --port 30000 2>&1 | tee /fsx/benchmark_rate1.log'

# High concurrency (throughput-focused) — progress logged to /fsx/benchmark_rate32.log
kubectl exec uccl-ep-node0 -- bash -c 'python3 -m sglang.bench_serving \
    --backend sglang \
    --dataset-name random \
    --num-prompts 100 \
    --random-input-len 2048 \
    --random-output-len 256 \
    --random-range-ratio 0.5 \
    --request-rate 32 \
    --max-concurrency 32 \
    --port 30000 2>&1 | tee /fsx/benchmark_rate32.log'

# Monitor progress from another terminal:
# kubectl exec uccl-ep-node0 -- tail -f /fsx/benchmark_rate1.log
# kubectl exec uccl-ep-node0 -- tail -f /fsx/benchmark_rate32.log
```

### Benchmark Results

**Workload**: random dataset, 100 prompts, input ~1024-2048 tokens, output ~128-256 tokens.

See [references/benchmark-results.md](references/benchmark-results.md) for full raw output.

#### Single-Node EP8 TP8 Scaling (1x p5en.48xlarge, H200)

| Rate | Output tok/s | Peak tok/s | Total tok/s | Mean TPOT (ms) | Mean TTFT (ms) | Mean E2E (ms) |
|------|-------------|-----------|-------------|----------------|----------------|---------------|
| 1 | 76.18 | 82 | 689 | 12.38 | 154.94 | 2,516 |
| 2 | 132.31 | 148 | 1,197 | 14.30 | 147.98 | 2,876 |
| 4 | 211.38 | 252 | 1,913 | 17.80 | 146.75 | 3,541 |
| 8 | 329.31 | 424 | 2,980 | 22.70 | 164.03 | 4,496 |
| 16 | 486.75 | 688 | 4,404 | 30.26 | 188.94 | 5,952 |
| 32 | 687.49 | 1,056 | 6,221 | 41.49 | 272.96 | 8,157 |

#### 2-Node EP8 TP16 Scaling (2x p5en.48xlarge, H200, NCCL)

| Rate | Output tok/s | Peak tok/s | Total tok/s | Mean TPOT (ms) | Mean TTFT (ms) | Mean E2E (ms) |
|------|-------------|-----------|-------------|----------------|----------------|---------------|
| 1 | 35.80 | 38 | 324 | 27.10 | 186.71 | 5,354 |
| 2 | 49.45 | 68 | 447 | 39.33 | 215.83 | 7,718 |
| 4 | 106.25 | 120 | 961 | 35.85 | 212.17 | 7,050 |
| 8 | 197.93 | 248 | 1,791 | 37.93 | 224.22 | 7,462 |
| 16 | 331.75 | 448 | 3,002 | 44.29 | 239.29 | 8,678 |
| 32 | 510.01 | 800 | 4,615 | 55.52 | 325.03 | 10,885 |

#### Configuration Comparison (rate=1, Single Request Latency)

| Metric | 1-node EP8 TP8 | 2-node EP8 TP16 | 2-node EP16 TP16 | 2-node UCCL-EP | Best |
|--------|---------------|----------------|-----------------|----------------|------|
| **Output throughput (tok/s)** | **76.18** | 35.80 | 36.04 | 15.70 | **1-node: 2.1x** |
| **Mean TPOT (ms)** | **12.38** | 27.10 | 26.92 | 62.59 | **1-node: 2.2x** |
| Mean E2E latency (ms) | **2,516** | 5,354 | 5,319 | 12,211 | **1-node: 2.1x** |
| Mean TTFT (ms) | **155** | 187 | 236 | 234 | **1-node: 1.2x vs EP8 TP16** |
| P99 TPOT (ms) | **12.44** | 27.31 | 28.22 | 65.27 | **1-node: 2.2x** |

#### Configuration Comparison (rate=32, High Concurrency)

| Metric | 1-node EP8 TP8 | 2-node EP8 TP16 | 2-node EP16 TP16 | 2-node UCCL-EP | Best |
|--------|---------------|----------------|-----------------|----------------|------|
| **Output throughput (tok/s)** | **687.49** | 510.01 | 502.23 | 305.16 | **1-node: 1.3x vs EP8 TP16** |
| **Total throughput (tok/s)** | **6,221** | 4,615 | 4,523 | 2,758 | **1-node: 1.3x vs EP8 TP16** |
| **Mean TPOT (ms)** | **41.49** | 55.52 | 56.34 | 92.54 | **1-node: 1.3x vs EP8 TP16** |
| Peak output (tok/s) | **1,056** | 800 | 616 | 446 | **1-node: 1.3x vs EP8 TP16** |

#### Why Single-Node is Faster

Single-node TP8 EP8 keeps all MoE all-to-all communication on NVLink (900 GB/s bidirectional)
instead of crossing EFA (~100 GB/s). With 61 MoE decoder layers each requiring all-to-all
dispatch/combine, eliminating cross-node latency compounds to a 2.2x improvement in per-token
decode time.

#### EP8 TP16 vs EP16 TP16

EP8 TP16 keeps MoE all-to-all (EP=8) on intra-node NVLink while TP=16 spans both nodes for
attention. EP16 TP16 sends both MoE and attention traffic across EFA. At rate=1, TPOT is nearly
identical (27.10 vs 26.92 ms) — the TP cross-node communication dominates in both configs. At
rate=32, EP8 TP16 shows a slight edge in peak throughput (800 vs 616 tok/s) because NVLink MoE
all-to-all scales better under batching. TTFT is consistently better for EP8 TP16 (187 vs 236 ms
at rate=1) since the prefill phase benefits from faster intra-node MoE dispatch.

#### Why NCCL is Faster than UCCL-EP on EFA

NCCL uses aws-ofi-nccl to run all-to-all directly over EFA with optimized chunking and
pipelining. UCCL-EP was designed for GPU-initiated RDMA (IBGDA) on InfiniBand/MLX5 — on
EFA, it falls back to CPU proxy threads that copy data between GPU and host memory, adding
latency per MoE dispatch/combine cycle.

### UCCL-EP Tuning: INFLIGHT Parameter

Tested `UCCL_IB_MAX_INFLIGHT_LOW_LATENCY` values 64 vs 128. **No significant difference**:

| Metric | INFLIGHT=64 | INFLIGHT=128 | Delta |
|--------|-------------|--------------|-------|
| Output tok/s (rate=1) | 15.85 | 15.70 | -0.9% |
| TPOT ms (rate=1) | 62.17 | 62.59 | +0.7% |
| Output tok/s (rate=32) | 305.82 | 305.16 | -0.2% |
| Peak output (rate=32) | 416 | 446 | +7.2% |

The bottleneck is CPU proxy overhead per dispatch/combine, not inflight write capacity.

## Troubleshooting

### `ImportError: DeepEP is not installed`

The DLC container has a residual `deep_ep` directory without `__init__.py`. Fix:
```bash
pip3 uninstall -y deep_ep
rm -rf /usr/local/lib/python3.12/dist-packages/deep_ep
rm -rf /usr/local/lib/python3.12/dist-packages/deep_ep.stock_bak
cd /fsx/uccl/ep/deep_ep_wrapper && pip3 install .
```

### Hostname resolution (HyperPod 172.x vs 10.x)

HyperPod assigns 172.18.x.x hostnames but EFA uses 10.x.x.x IPs. Fix:
```bash
MYIP=$(hostname -I | awk '{print $1}')
MYHOST=$(hostname)
grep -v "$MYHOST" /etc/hosts > /tmp/hosts.new
echo "$MYIP $MYHOST" >> /tmp/hosts.new
cp /tmp/hosts.new /etc/hosts
```

### `--moe-a2a-backend nccl` is not a valid choice

SGLang 0.5.8 valid options are: `none`, `deepep`, `mooncake`, `ascend_fuseep`.
Use `--moe-a2a-backend none` to get the NCCL all-to-all path.

### `import uccl.ep` fails after installing sglang

sglang may install a different PyTorch version. Rebuild:
```bash
cd /fsx/uccl/ep && make clean && make -j$(nproc) && make install
```

### `Segfault in Proxy::send_barrier` during CUDA graph capture

UCCL-EP proxy crashes when sglang captures CUDA graphs with dispatch/combine in the graph
context. Fix: add `--disable-cuda-graph` to the launch command. This reduces decode throughput
but avoids the crash. (Not observed on p5en with low_latency mode + SGLang 0.5.8.)

### DeepGEMM cold-cache compilation slow (10-20 min)

First startup compiles ~16384 GEMM kernels. Cache is stored in `/tmp/deep_gemm_cache` (per-node).
To speed up subsequent starts, copy the compiled cache to shared FSx after first run:
```bash
kubectl exec uccl-ep-node0 -- cp -r /tmp/deep_gemm_cache /fsx/deep_gemm_cache_backup
```
Then on future starts, pre-populate: `cp -r /fsx/deep_gemm_cache_backup /tmp/deep_gemm_cache`

### `AttributeError: 'torch._C._CudaDeviceProperties' object has no attribute 'total_mem'`

PyTorch 2.9+ renamed `total_mem` to `total_memory`. The launch script handles this with:
```python
getattr(p, 'total_memory', getattr(p, 'total_mem', 0))
```

### `--enable-two-batch-overlap` causes dispatch timeout

Two-batch overlap doubles RDMA pressure, causing `DeepEP error: timeout (dispatch CPU)` on EFA.
Do not use with UCCL-EP.

### Pods expire after 24h

Pods use `command: ["sleep", "infinity"]` but installed packages are ephemeral. After pod
recreation, re-run `init_dlc_worker.sh`. Build artifacts on FSx (`/fsx/uccl`) persist.

## Resources

| File | Description |
|------|-------------|
| `scripts/launch_sglang_nccl_ep8_tp8.sh` | SGLang launch — single-node NCCL EP8 TP8 (best for H200) |
| `scripts/launch_sglang_nccl.sh` | SGLang launch — 2-node NCCL EP16 TP16 |
| `scripts/launch_sglang_nccl_ep8_tp16.sh` | SGLang launch — 2-node NCCL EP8 TP16 (alternative) |
| `scripts/launch_sglang_dlc.sh` | SGLang launch — 2-node UCCL-EP backend |
| `scripts/init_dlc_worker.sh` | DLC container initialization (UCCL-EP build + deep_ep install) |
| `references/pod-templates.md` | Kubernetes pod YAML templates and configuration notes |
| `references/sglang-ep8-tp8-node0.yaml` | Pod spec for single-node EP8 TP8 deployment |
| `references/uccl-ep-node0.yaml` | Pod spec for 2-node deployment — node 0 |
| `references/uccl-ep-node1.yaml` | Pod spec for 2-node deployment — node 1 |
| `references/benchmark-results.md` | Detailed benchmark output from sglang.bench_serving |

## UCCL-EP Kernel Benchmarks

These benchmarks test the UCCL-EP communication kernels directly (without SGLang), verifying
correctness and measuring raw dispatch/combine bandwidth. They require UCCL-EP to be built
(`init_dlc_worker.sh` completed) and **no other GPU processes running** — stop SGLang before
running these tests.

```bash
# Check GPU usage
kubectl exec uccl-ep-node0 -- nvidia-smi --query-compute-apps=pid,used_memory --format=csv
kubectl exec uccl-ep-node1 -- nvidia-smi --query-compute-apps=pid,used_memory --format=csv

# If GPUs are occupied, kill processes (e.g., SGLang schedulers)
kubectl exec uccl-ep-node0 -- bash -c "pkill -9 -f 'sglang|test_low_latency|test_internode'"
kubectl exec uccl-ep-node1 -- bash -c "pkill -9 -f 'sglang|test_low_latency|test_internode'"
```

Both nodes must execute their commands simultaneously (use separate terminals or background jobs).

### Internode Low Latency Test (Inference Config)

Tests low-latency dispatch/combine kernels with pure RDMA, simulating inference workloads.

**Configuration**: 128 tokens, 7168 hidden, top-8 experts, 288 experts, 16 EP (2 nodes x 8 GPUs)

```bash
NODE0_IP=$(kubectl get pod uccl-ep-node0 -o jsonpath='{.status.podIP}')

# Node0:
kubectl exec uccl-ep-node0 -- bash -c "cd /fsx/uccl/ep && torchrun \
  --nnodes=2 --nproc_per_node=8 --node_rank=0 \
  --master_addr=$NODE0_IP --master_port=12355 \
  bench/test_low_latency.py --num-tokens=128 \
  --hidden=7168 --num-topk=8 --num-experts=288"

# Node1 (in another terminal):
kubectl exec uccl-ep-node1 -- bash -c "cd /fsx/uccl/ep && torchrun \
  --nnodes=2 --nproc_per_node=8 --node_rank=1 \
  --master_addr=$NODE0_IP --master_port=12355 \
  bench/test_low_latency.py --num-tokens=128 \
  --hidden=7168 --num-topk=8 --num-experts=288"
```

**Expected output** (per rank): correctness check followed by bandwidth numbers:
```
✓ All correctness tests passed!
[rank 0] Dispatch + combine bandwidth: 32.83 GB/s, avg_t=671.63 us
[rank 0] Dispatch bandwidth: 51.34 GB/s, avg_t=146.31 us | Combine bandwidth: 34.35 GB/s, avg_t=423.14 us
[rank 0] Dispatch send/recv time: 40.15 + 24.53 us | Combine send/recv time: 36.80 + 48.07 us
```

**Reference results** (p5en, 2 nodes, 16 EP):

| Metric | UCCL Official | Our Result |
|--------|---------------|------------|
| Dispatch latency | 226 µs | ~140-330 µs (varies by rank) |
| Dispatch RDMA BW | 36 GB/s | ~22-53 GB/s (varies by rank) |
| Combine latency | 293 µs | ~230-429 µs (varies by rank) |
| Combine RDMA BW | 48 GB/s | ~34-63 GB/s (varies by rank) |
| Dispatch+Combine total | ~519 µs | ~672 µs |

Note: Per-rank numbers are asymmetric due to RDMA communication direction. The official
benchmark reports representative single values; actual per-rank results vary depending on
whether the rank is primarily sending or receiving in each phase.

### Internode Normal Mode Test (Pretraining/Throughput Config)

Tests internode dispatch/combine with NVLink + RDMA pipelining, simulating pretraining workloads.
Includes auto-tuning of NVL/RDMA chunk sizes and low-latency compatibility check.

**Configuration**: 4096 tokens, 7168 hidden, top-8 experts, 288 experts, 16 EP (2 nodes x 8 GPUs)

```bash
NODE0_IP=$(kubectl get pod uccl-ep-node0 -o jsonpath='{.status.podIP}')

# Node0:
kubectl exec uccl-ep-node0 -- bash -c "cd /fsx/uccl/ep && torchrun \
  --nnodes=2 --nproc_per_node=8 --node_rank=0 \
  --master_addr=$NODE0_IP --master_port=12355 \
  bench/test_internode.py --num-tokens=4096 \
  --hidden=7168 --num-topk=8 --num-experts=288 --test-ll-compatibility"

# Node1 (in another terminal):
kubectl exec uccl-ep-node1 -- bash -c "cd /fsx/uccl/ep && torchrun \
  --nnodes=2 --nproc_per_node=8 --node_rank=1 \
  --master_addr=$NODE0_IP --master_port=12355 \
  bench/test_internode.py --num-tokens=4096 \
  --hidden=7168 --num-topk=8 --num-experts=288 --test-ll-compatibility"
```

**Expected output**: correctness tests followed by tuning sweep and best configuration:
```
Testing with seed 0 ...
[testing] Running with BF16, without top-k (async=False, previous=False) ...
[testing] Running with FP8, with top-k (async=True, previous=True) ...
...
[tuning] Best dispatch (FP8): SMs 24, NVL chunk 28, RDMA chunk 16, transmit: 1210.00 us, BW: 49.84 GB/s (RDMA), 163.46 GB/s (NVL)
[tuning] Best dispatch (BF16): SMs 24, NVL chunk 20, RDMA chunk 12, transmit: 1988.00 us, BW: 58.84 GB/s (RDMA), 192.95 GB/s (NVL)
[tuning] Best combine: SMs 24, NVL chunk 7, RDMA chunk 32, transmit: 5994.00 us, BW: 19.51 GB/s (RDMA), 64.00 GB/s (NVL)
```

**Reference results** (p5en, 2 nodes, 16 EP):

| Metric | UCCL Official | Our Result (avg) |
|--------|---------------|------------------|
| Dispatch FP8 RDMA BW | 50 GB/s | ~51 GB/s |
| Dispatch FP8 latency | 1196 µs | ~1181 µs |
| Combine RDMA BW | 18 GB/s | ~19.5 GB/s |
| Combine latency | 6379 µs | ~5991 µs |

The internode normal mode test matches the official benchmark closely, with dispatch bandwidth
within 2% and combine performance slightly better (~8% higher BW, ~6% lower latency).
