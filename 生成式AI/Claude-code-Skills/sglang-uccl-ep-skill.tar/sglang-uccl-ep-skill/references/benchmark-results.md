# SGLang Benchmark Results

## Setup

- **Model**: DeepSeek-V3 (671B MoE, FP8, 256 experts, top-8 routing)
- **Container**: `sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci`
- **Benchmark tool**: `sglang.bench_serving`

### Configurations Tested

| Config | Hardware | TP | EP | Nodes | Communication |
|--------|----------|----|----|-------|---------------|
| 2-node NCCL EP16 TP16 | 2x p5en.48xlarge (16x H200) | 16 | 16 | 2 | EFA (aws-ofi-nccl) |
| 2-node NCCL EP8 TP16 | 2x p5en.48xlarge (16x H200) | 16 | 8 | 2 | MoE on NVLink, TP on EFA |
| 2-node UCCL-EP | 2x p5en.48xlarge (16x H200) | 16 | 16 | 2 | EFA (UCCL-EP CPU proxy) |
| **1-node NCCL** | **1x p5en.48xlarge (8x H200)** | **8** | **8** | **1** | **NVLink (intra-node)** |

## Workload

- **Dataset**: random
- **Prompts**: 100
- **Input length**: ~1024-2048 tokens (random-input-len=2048, random-range-ratio=0.5)
- **Output length**: ~128-256 tokens (random-output-len=256, random-range-ratio=0.5)
- **Total input tokens**: ~154,306
- **Total output tokens**: ~19,172

---

## NCCL EP16 TP16 Backend (`--moe-a2a-backend none`, `--mem-fraction-static 0.90`)

### NCCL EP16 TP16: rate=1 (max-concurrency=1)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    1.0
Max request concurrency:                 1
Successful requests:                     100
Benchmark duration (s):                  531.82
Total input tokens:                      154306
Total generated tokens:                  19172
Request throughput (req/s):              0.19
Input token throughput (tok/s):          290.16
Output token throughput (tok/s):         36.04
Peak output token throughput (tok/s):    39.00
Total token throughput (tok/s):          326.20
Concurrency:                             1.00
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   5319.02
Median E2E Latency (ms):                 5222.24
P90 E2E Latency (ms):                    6647.84
P99 E2E Latency (ms):                    7027.69
---------------Time to First Token----------------
Mean TTFT (ms):                          236.16
Median TTFT (ms):                        235.81
P99 TTFT (ms):                           263.59
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          26.92
Median TPOT (ms):                        26.86
P99 TPOT (ms):                           28.22
---------------Inter-Token Latency----------------
Mean ITL (ms):                           26.92
Median ITL (ms):                         26.29
P95 ITL (ms):                            27.79
P99 ITL (ms):                            30.04
Max ITL (ms):                            157.01
==================================================
```

### NCCL EP16 TP16: rate=32 (max-concurrency=32)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    32.0
Max request concurrency:                 32
Successful requests:                     100
Benchmark duration (s):                  38.38
Total input tokens:                      154306
Total generated tokens:                  19172
Request throughput (req/s):              2.61
Input token throughput (tok/s):          4020.62
Output token throughput (tok/s):         502.23
Peak output token throughput (tok/s):    616.00
Total token throughput (tok/s):          4522.85
Concurrency:                             28.91
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   11063.26
Median E2E Latency (ms):                 10711.01
P90 E2E Latency (ms):                    14283.07
P99 E2E Latency (ms):                    14918.08
---------------Time to First Token----------------
Mean TTFT (ms):                          352.28
Median TTFT (ms):                        316.70
P99 TTFT (ms):                           564.81
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          56.34
Median TPOT (ms):                        57.24
P99 TPOT (ms):                           66.04
---------------Inter-Token Latency----------------
Mean ITL (ms):                           56.24
Median ITL (ms):                         47.86
P95 ITL (ms):                            134.85
P99 ITL (ms):                            154.40
Max ITL (ms):                            572.27
==================================================
```

---

## NCCL EP8 TP16 Backend (`--tp 16 --ep 8 --nnodes 2`, `--mem-fraction-static 0.80`)

- **Hardware**: 2x p5en.48xlarge (16x H200 141GB, 16 GPUs total)
- **Configuration**: TP=16 (across 2 nodes), EP=8 (intra-node MoE via NVLink)
- **Flags**: `--moe-runner-backend deep_gemm`, `--cuda-graph-max-bs 32`
- **Communication**: MoE all-to-all on NVLink (intra-node EP=8), attention TP on EFA (cross-node)

### NCCL EP8 TP16: rate=1 (max-concurrency=1)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    1.0
Max request concurrency:                 1
Successful requests:                     100
Benchmark duration (s):                  535.50
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19077
Request throughput (req/s):              0.19
Input token throughput (tok/s):          288.16
Output token throughput (tok/s):         35.80
Peak output token throughput (tok/s):    38.00
Peak concurrent requests:                2
Total token throughput (tok/s):          323.96
Concurrency:                             1.00
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   5354.24
Median E2E Latency (ms):                 5273.39
P90 E2E Latency (ms):                    6703.48
P99 E2E Latency (ms):                    7015.92
---------------Time to First Token----------------
Mean TTFT (ms):                          186.71
Median TTFT (ms):                        184.39
P99 TTFT (ms):                           210.79
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          27.10
Median TPOT (ms):                        27.09
P99 TPOT (ms):                           27.31
---------------Inter-Token Latency----------------
Mean ITL (ms):                           27.09
Median ITL (ms):                         27.09
P95 ITL (ms):                            27.39
P99 ITL (ms):                            27.57
Max ITL (ms):                            43.00
==================================================
```

### NCCL EP8 TP16: rate=2 (max-concurrency=2)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    2.0
Max request concurrency:                 2
Successful requests:                     100
Benchmark duration (s):                  387.70
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19078
Request throughput (req/s):              0.26
Input token throughput (tok/s):          398.00
Output token throughput (tok/s):         49.45
Peak output token throughput (tok/s):    68.00
Peak concurrent requests:                4
Total token throughput (tok/s):          447.45
Concurrency:                             1.99
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   7717.49
Median E2E Latency (ms):                 7352.85
P90 E2E Latency (ms):                    10045.99
P99 E2E Latency (ms):                    13351.49
---------------Time to First Token----------------
Mean TTFT (ms):                          215.83
Median TTFT (ms):                        210.95
P99 TTFT (ms):                           356.61
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          39.33
Median TPOT (ms):                        36.54
P99 TPOT (ms):                           64.24
---------------Inter-Token Latency----------------
Mean ITL (ms):                           39.33
Median ITL (ms):                         33.68
P95 ITL (ms):                            42.49
P99 ITL (ms):                            176.06
Max ITL (ms):                            335.48
==================================================
```

### NCCL EP8 TP16: rate=4 (max-concurrency=4)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    4.0
Max request concurrency:                 4
Successful requests:                     100
Benchmark duration (s):                  180.45
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19081
Request throughput (req/s):              0.55
Input token throughput (tok/s):          855.14
Output token throughput (tok/s):         106.25
Peak output token throughput (tok/s):    120.00
Peak concurrent requests:                6
Total token throughput (tok/s):          961.39
Concurrency:                             3.91
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   7050.32
Median E2E Latency (ms):                 6775.63
P90 E2E Latency (ms):                    8869.38
P99 E2E Latency (ms):                    9291.95
---------------Time to First Token----------------
Mean TTFT (ms):                          212.17
Median TTFT (ms):                        211.49
P99 TTFT (ms):                           240.06
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          35.85
Median TPOT (ms):                        35.99
P99 TPOT (ms):                           36.92
---------------Inter-Token Latency----------------
Mean ITL (ms):                           35.85
Median ITL (ms):                         33.75
P95 ITL (ms):                            34.11
P99 ITL (ms):                            168.17
Max ITL (ms):                            179.72
==================================================
```

### NCCL EP8 TP16: rate=8 (max-concurrency=8)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    8.0
Max request concurrency:                 8
Successful requests:                     100
Benchmark duration (s):                  96.86
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19078
Request throughput (req/s):              1.03
Input token throughput (tok/s):          1593.06
Output token throughput (tok/s):         197.93
Peak output token throughput (tok/s):    248.00
Peak concurrent requests:                12
Total token throughput (tok/s):          1790.99
Concurrency:                             7.70
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   7462.35
Median E2E Latency (ms):                 7225.01
P90 E2E Latency (ms):                    9450.70
P99 E2E Latency (ms):                    9917.14
---------------Time to First Token----------------
Mean TTFT (ms):                          224.22
Median TTFT (ms):                        209.52
P99 TTFT (ms):                           351.03
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          37.93
Median TPOT (ms):                        38.15
P99 TPOT (ms):                           40.43
---------------Inter-Token Latency----------------
Mean ITL (ms):                           37.95
Median ITL (ms):                         33.30
P95 ITL (ms):                            34.66
P99 ITL (ms):                            175.14
Max ITL (ms):                            320.41
==================================================
```

### NCCL EP8 TP16: rate=16 (max-concurrency=16)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    16.0
Max request concurrency:                 16
Successful requests:                     100
Benchmark duration (s):                  57.79
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19080
Request throughput (req/s):              1.73
Input token throughput (tok/s):          2670.08
Output token throughput (tok/s):         331.75
Peak output token throughput (tok/s):    448.00
Peak concurrent requests:                20
Total token throughput (tok/s):          3001.83
Concurrency:                             15.02
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   8678.43
Median E2E Latency (ms):                 8460.16
P90 E2E Latency (ms):                    10976.71
P99 E2E Latency (ms):                    11722.98
---------------Time to First Token----------------
Mean TTFT (ms):                          239.29
Median TTFT (ms):                        210.27
P99 TTFT (ms):                           445.67
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          44.29
Median TPOT (ms):                        45.05
P99 TPOT (ms):                           48.57
---------------Inter-Token Latency----------------
Mean ITL (ms):                           44.25
Median ITL (ms):                         35.83
P95 ITL (ms):                            171.14
P99 ITL (ms):                            175.23
Max ITL (ms):                            597.39
==================================================
```

### NCCL EP8 TP16: rate=32 (max-concurrency=32)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    32.0
Max request concurrency:                 32
Successful requests:                     100
Benchmark duration (s):                  37.59
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19077
Request throughput (req/s):              2.66
Input token throughput (tok/s):          4104.85
Output token throughput (tok/s):         510.01
Peak output token throughput (tok/s):    800.00
Peak concurrent requests:                38
Total token throughput (tok/s):          4614.86
Concurrency:                             28.96
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   10884.84
Median E2E Latency (ms):                 10500.60
P90 E2E Latency (ms):                    14238.25
P99 E2E Latency (ms):                    15402.61
---------------Time to First Token----------------
Mean TTFT (ms):                          325.03
Median TTFT (ms):                        321.88
P99 TTFT (ms):                           603.60
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          55.52
Median TPOT (ms):                        57.23
P99 TPOT (ms):                           69.66
---------------Inter-Token Latency----------------
Mean ITL (ms):                           55.37
Median ITL (ms):                         40.59
P95 ITL (ms):                            180.68
P99 ITL (ms):                            186.10
Max ITL (ms):                            994.77
==================================================
```

### NCCL EP8 TP16: Scaling Summary

| Rate | Output tok/s | Peak tok/s | Total tok/s | Mean TPOT (ms) | Mean TTFT (ms) | Mean E2E (ms) |
|------|-------------|-----------|-------------|----------------|----------------|---------------|
| 1 | 35.80 | 38 | 324 | 27.10 | 186.71 | 5,354 |
| 2 | 49.45 | 68 | 447 | 39.33 | 215.83 | 7,718 |
| 4 | 106.25 | 120 | 961 | 35.85 | 212.17 | 7,050 |
| 8 | 197.93 | 248 | 1,791 | 37.93 | 224.22 | 7,462 |
| 16 | 331.75 | 448 | 3,002 | 44.29 | 239.29 | 8,678 |
| 32 | 510.01 | 800 | 4,615 | 55.52 | 325.03 | 10,885 |

---

## UCCL-EP Backend (`--moe-a2a-backend deepep`, `--deepep-mode low_latency`)

### UCCL-EP (INFLIGHT=64): rate=1

`UCCL_IB_MAX_INFLIGHT_LOW_LATENCY=64`, `--mem-fraction-static 0.85`

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    1.0
Max request concurrency:                 1
Successful requests:                     100
Benchmark duration (s):                  1209.29
Total input tokens:                      154306
Total generated tokens:                  19172
Request throughput (req/s):              0.08
Input token throughput (tok/s):          127.60
Output token throughput (tok/s):         15.85
Peak output token throughput (tok/s):    17.00
Total token throughput (tok/s):          143.45
Concurrency:                             1.00
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   12091.69
Median E2E Latency (ms):                 11859.80
P90 E2E Latency (ms):                    15099.31
P99 E2E Latency (ms):                    15975.77
---------------Time to First Token----------------
Mean TTFT (ms):                          234.08
Median TTFT (ms):                        233.84
P99 TTFT (ms):                           257.37
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          62.17
Median TPOT (ms):                        62.08
P99 TPOT (ms):                           64.98
---------------Inter-Token Latency----------------
Mean ITL (ms):                           62.17
Median ITL (ms):                         69.34
P95 ITL (ms):                            70.32
P99 ITL (ms):                            71.77
Max ITL (ms):                            159.94
==================================================
```

### UCCL-EP (INFLIGHT=64): rate=32

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    32.0
Max request concurrency:                 32
Successful requests:                     100
Benchmark duration (s):                  62.69
Total input tokens:                      154306
Total generated tokens:                  19172
Request throughput (req/s):              1.60
Input token throughput (tok/s):          2461.41
Output token throughput (tok/s):         305.82
Peak output token throughput (tok/s):    416.00
Total token throughput (tok/s):          2767.24
Concurrency:                             28.66
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   17963.90
Median E2E Latency (ms):                 17384.52
P90 E2E Latency (ms):                    22924.70
P99 E2E Latency (ms):                    24567.39
---------------Time to First Token----------------
Mean TTFT (ms):                          382.26
Median TTFT (ms):                        340.30
P99 TTFT (ms):                           603.24
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          92.35
Median TPOT (ms):                        94.01
P99 TPOT (ms):                           106.71
---------------Inter-Token Latency----------------
Mean ITL (ms):                           92.19
Median ITL (ms):                         80.83
P95 ITL (ms):                            224.24
P99 ITL (ms):                            239.16
Max ITL (ms):                            952.26
==================================================
```

### UCCL-EP (INFLIGHT=128): rate=1

`UCCL_IB_MAX_INFLIGHT_LOW_LATENCY=128`, `--mem-fraction-static 0.85`

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    1.0
Max request concurrency:                 1
Successful requests:                     100
Benchmark duration (s):                  1221.40
Total input tokens:                      154306
Total generated tokens:                  19172
Request throughput (req/s):              0.08
Input token throughput (tok/s):          126.34
Output token throughput (tok/s):         15.70
Peak output token throughput (tok/s):    17.00
Total token throughput (tok/s):          142.04
Concurrency:                             1.00
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   12211.36
Median E2E Latency (ms):                 11969.36
P90 E2E Latency (ms):                    15251.75
P99 E2E Latency (ms):                    16076.88
---------------Time to First Token----------------
Mean TTFT (ms):                          234.33
Median TTFT (ms):                        233.88
P99 TTFT (ms):                           258.33
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          62.59
Median TPOT (ms):                        62.56
P99 TPOT (ms):                           65.27
---------------Inter-Token Latency----------------
Mean ITL (ms):                           62.59
Median ITL (ms):                         69.61
P95 ITL (ms):                            70.47
P99 ITL (ms):                            72.09
Max ITL (ms):                            161.24
==================================================
```

### UCCL-EP (INFLIGHT=128): rate=32

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    32.0
Max request concurrency:                 32
Successful requests:                     100
Benchmark duration (s):                  62.90
Total input tokens:                      154306
Total generated tokens:                  19172
Request throughput (req/s):              1.59
Input token throughput (tok/s):          2453.28
Output token throughput (tok/s):         305.16
Peak output token throughput (tok/s):    446.00
Total token throughput (tok/s):          2758.44
Concurrency:                             28.73
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   17998.48
Median E2E Latency (ms):                 17458.26
P90 E2E Latency (ms):                    22877.58
P99 E2E Latency (ms):                    24458.18
---------------Time to First Token----------------
Mean TTFT (ms):                          381.62
Median TTFT (ms):                        339.36
P99 TTFT (ms):                           598.41
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          92.54
Median TPOT (ms):                        94.11
P99 TPOT (ms):                           106.53
---------------Inter-Token Latency----------------
Mean ITL (ms):                           92.41
Median ITL (ms):                         80.82
P95 ITL (ms):                            224.41
P99 ITL (ms):                            240.55
Max ITL (ms):                            944.42
==================================================
```

---

## Summary: NCCL vs UCCL-EP

### rate=1 (Single Request Latency)

| Metric | NCCL | UCCL-EP (INFLIGHT=128) | Ratio |
|--------|------|------------------------|-------|
| Output throughput (tok/s) | **36.04** | 15.70 | **2.3x** |
| Mean E2E Latency (ms) | **5,319** | 12,211 | **2.3x faster** |
| Mean TTFT (ms) | 236 | 234 | ~same |
| Mean TPOT (ms) | **26.92** | 62.59 | **2.3x faster** |
| Mean ITL (ms) | **26.92** | 62.59 | **2.3x faster** |
| P99 ITL (ms) | 30.04 | 72.09 | 2.4x faster |
| Max ITL (ms) | 157 | 161 | ~same |
| Benchmark duration (s) | 532 | 1,221 | 2.3x faster |

### rate=32 (High Concurrency Throughput)

| Metric | NCCL | UCCL-EP (INFLIGHT=128) | Ratio |
|--------|------|------------------------|-------|
| Output throughput (tok/s) | **502.23** | 305.16 | **1.6x** |
| Total throughput (tok/s) | **4,523** | 2,758 | **1.6x** |
| Peak output (tok/s) | **616** | 446 | **1.4x** |
| Mean E2E Latency (ms) | **11,063** | 17,998 | **1.6x faster** |
| Mean TTFT (ms) | 352 | 382 | ~same |
| Mean TPOT (ms) | **56.34** | 92.54 | **1.6x faster** |
| Mean ITL (ms) | **56.24** | 92.41 | **1.6x faster** |
| P99 ITL (ms) | 154 | 241 | 1.6x faster |
| Max ITL (ms) | 572 | 944 | 1.7x faster |
| Benchmark duration (s) | 38 | 63 | 1.7x faster |

### UCCL-EP INFLIGHT Tuning (64 vs 128)

| Metric | INFLIGHT=64 | INFLIGHT=128 | Delta |
|--------|-------------|--------------|-------|
| Output tok/s (rate=1) | 15.85 | 15.70 | -0.9% |
| TPOT ms (rate=1) | 62.17 | 62.59 | +0.7% |
| Output tok/s (rate=32) | 305.82 | 305.16 | -0.2% |
| TPOT ms (rate=32) | 92.35 | 92.54 | +0.2% |
| Peak output (rate=32) | 416 | 446 | +7.2% |

**Conclusion**: INFLIGHT parameter has negligible impact. The bottleneck is CPU proxy
overhead per MoE dispatch/combine, not inflight RDMA write capacity.

## NCCL Single-Node EP8 TP8 (`--tp 8 --ep 8 --nnodes 1`)

- **Hardware**: 1x p5en.48xlarge (8x H200 141GB each, 8 GPUs total)
- **Configuration**: TP=8, EP=8, single node (all-to-all via NVLink/NCCL)
- **Flags**: `--moe-a2a-backend none`, `--mem-fraction-static 0.78`
- **Communication**: Intra-node NVLink (no cross-node EFA traffic)

### NCCL EP8 TP8: rate=1 (max-concurrency=1)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    1.0
Max request concurrency:                 1
Successful requests:                     100
Benchmark duration (s):                  251.66
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19073
Request throughput (req/s):              0.40
Input token throughput (tok/s):          613.16
Output token throughput (tok/s):         76.18
Peak output token throughput (tok/s):    82.00
Peak concurrent requests:                2
Total token throughput (tok/s):          689.34
Concurrency:                             1.00
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   2516.10
Median E2E Latency (ms):                 2480.53
P90 E2E Latency (ms):                    3120.92
P99 E2E Latency (ms):                    3265.48
---------------Time to First Token----------------
Mean TTFT (ms):                          154.94
Median TTFT (ms):                        149.28
P99 TTFT (ms):                           218.08
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          12.38
Median TPOT (ms):                        12.38
P99 TPOT (ms):                           12.44
---------------Inter-Token Latency----------------
Mean ITL (ms):                           12.38
Median ITL (ms):                         12.38
P95 ITL (ms):                            12.50
P99 ITL (ms):                            12.61
Max ITL (ms):                            15.33
==================================================
```

### NCCL EP8 TP8: rate=2 (max-concurrency=2)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    2.0
Max request concurrency:                 2
Successful requests:                     100
Benchmark duration (s):                  144.90
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19079
Request throughput (req/s):              0.69
Input token throughput (tok/s):          1064.89
Output token throughput (tok/s):         132.31
Peak output token throughput (tok/s):    148.00
Peak concurrent requests:                4
Total token throughput (tok/s):          1197.20
Concurrency:                             1.98
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   2875.83
Median E2E Latency (ms):                 2768.77
P90 E2E Latency (ms):                    3558.32
P99 E2E Latency (ms):                    3768.69
---------------Time to First Token----------------
Mean TTFT (ms):                          147.98
Median TTFT (ms):                        145.77
P99 TTFT (ms):                           261.83
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          14.30
Median TPOT (ms):                        14.35
P99 TPOT (ms):                           14.86
---------------Inter-Token Latency----------------
Mean ITL (ms):                           14.30
Median ITL (ms):                         13.71
P95 ITL (ms):                            13.96
P99 ITL (ms):                            18.80
Max ITL (ms):                            127.37
==================================================
```

### NCCL EP8 TP8: rate=4 (max-concurrency=4)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    4.0
Max request concurrency:                 4
Successful requests:                     100
Benchmark duration (s):                  90.70
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19079
Request throughput (req/s):              1.10
Input token throughput (tok/s):          1701.25
Output token throughput (tok/s):         211.38
Peak output token throughput (tok/s):    252.00
Peak concurrent requests:                7
Total token throughput (tok/s):          1912.63
Concurrency:                             3.90
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   3541.41
Median E2E Latency (ms):                 3412.40
P90 E2E Latency (ms):                    4487.80
P99 E2E Latency (ms):                    4661.37
---------------Time to First Token----------------
Mean TTFT (ms):                          146.75
Median TTFT (ms):                        145.22
P99 TTFT (ms):                           184.30
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          17.80
Median TPOT (ms):                        17.86
P99 TPOT (ms):                           18.65
---------------Inter-Token Latency----------------
Mean ITL (ms):                           17.80
Median ITL (ms):                         16.11
P95 ITL (ms):                            16.47
P99 ITL (ms):                            127.14
Max ITL (ms):                            147.90
==================================================
```

### NCCL EP8 TP8: rate=8 (max-concurrency=8)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    8.0
Max request concurrency:                 8
Successful requests:                     100
Benchmark duration (s):                  58.22
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19063
Request throughput (req/s):              1.72
Input token throughput (tok/s):          2650.42
Output token throughput (tok/s):         329.31
Peak output token throughput (tok/s):    424.00
Peak concurrent requests:                11
Total token throughput (tok/s):          2979.72
Concurrency:                             7.72
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   4495.75
Median E2E Latency (ms):                 4354.50
P90 E2E Latency (ms):                    5679.33
P99 E2E Latency (ms):                    5988.37
---------------Time to First Token----------------
Mean TTFT (ms):                          164.03
Median TTFT (ms):                        149.88
P99 TTFT (ms):                           274.74
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          22.70
Median TPOT (ms):                        22.83
P99 TPOT (ms):                           24.67
---------------Inter-Token Latency----------------
Mean ITL (ms):                           22.71
Median ITL (ms):                         19.01
P95 ITL (ms):                            25.47
P99 ITL (ms):                            125.13
Max ITL (ms):                            283.32
==================================================
```

### NCCL EP8 TP8: rate=16 (max-concurrency=16)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    16.0
Max request concurrency:                 16
Successful requests:                     100
Benchmark duration (s):                  39.39
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19080
Request throughput (req/s):              2.54
Input token throughput (tok/s):          3917.63
Output token throughput (tok/s):         486.75
Peak output token throughput (tok/s):    688.00
Peak concurrent requests:                22
Total token throughput (tok/s):          4404.38
Concurrency:                             15.11
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   5951.85
Median E2E Latency (ms):                 5758.29
P90 E2E Latency (ms):                    7592.39
P99 E2E Latency (ms):                    8083.83
---------------Time to First Token----------------
Mean TTFT (ms):                          188.94
Median TTFT (ms):                        152.08
P99 TTFT (ms):                           364.85
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          30.26
Median TPOT (ms):                        30.86
P99 TPOT (ms):                           33.26
---------------Inter-Token Latency----------------
Mean ITL (ms):                           30.22
Median ITL (ms):                         23.32
P95 ITL (ms):                            126.46
P99 ITL (ms):                            128.17
Max ITL (ms):                            285.75
==================================================
```

### NCCL EP8 TP8: rate=32 (max-concurrency=32)

```
============ Serving Benchmark Result ============
Backend:                                 sglang
Traffic request rate:                    32.0
Max request concurrency:                 32
Successful requests:                     100
Benchmark duration (s):                  27.89
Total input tokens:                      154306
Total input text tokens:                 154306
Total generated tokens:                  19172
Total generated tokens (retokenized):    19057
Request throughput (req/s):              3.59
Input token throughput (tok/s):          5533.29
Output token throughput (tok/s):         687.49
Peak output token throughput (tok/s):    1056.00
Peak concurrent requests:                39
Total token throughput (tok/s):          6220.78
Concurrency:                             29.25
----------------End-to-End Latency----------------
Mean E2E Latency (ms):                   8157.33
Median E2E Latency (ms):                 7838.79
P90 E2E Latency (ms):                    10678.52
P99 E2E Latency (ms):                    11702.06
---------------Time to First Token----------------
Mean TTFT (ms):                          272.96
Median TTFT (ms):                        256.88
P99 TTFT (ms):                           556.95
-----Time per Output Token (excl. 1st token)------
Mean TPOT (ms):                          41.49
Median TPOT (ms):                        42.83
P99 TPOT (ms):                           52.22
---------------Inter-Token Latency----------------
Mean ITL (ms):                           41.34
Median ITL (ms):                         30.50
P95 ITL (ms):                            127.48
P99 ITL (ms):                            162.02
Max ITL (ms):                            962.54
==================================================
```

### NCCL EP8 TP8: Scaling Summary

| Rate | Output tok/s | Peak tok/s | Total tok/s | Mean TPOT (ms) | Mean TTFT (ms) | Mean E2E (ms) |
|------|-------------|-----------|-------------|----------------|----------------|---------------|
| 1 | 76.18 | 82 | 689 | 12.38 | 154.94 | 2,516 |
| 2 | 132.31 | 148 | 1,197 | 14.30 | 147.98 | 2,876 |
| 4 | 211.38 | 252 | 1,913 | 17.80 | 146.75 | 3,541 |
| 8 | 329.31 | 424 | 2,980 | 22.70 | 164.03 | 4,496 |
| 16 | 486.75 | 688 | 4,404 | 30.26 | 188.94 | 5,952 |
| 32 | 687.49 | 1,056 | 6,221 | 41.49 | 272.96 | 8,157 |

---

## Analysis

### Single-Node EP8 TP8 vs 2-Node Configs (NCCL)

Single-node TP8 EP8 significantly outperforms all 2-node configurations because all MoE all-to-all
communication stays on NVLink (900 GB/s) instead of crossing EFA (~100 GB/s).

| Metric | 1-node EP8 TP8 | 2-node EP8 TP16 | 2-node EP16 TP16 | Best Ratio |
|--------|---------------|----------------|-----------------|------------|
| Output tok/s (rate=1) | **76.18** | 35.80 | 36.04 | **2.1x** |
| TPOT (rate=1) | **12.38 ms** | 27.10 ms | 26.92 ms | **2.2x** |
| TTFT (rate=1) | **154.94 ms** | 186.71 ms | 236 ms | **1.2x vs EP8 TP16** |
| Output tok/s (rate=32) | **687.49** | 510.01 | 502.23 | **1.3x** |
| Total tok/s (rate=32) | **6,221** | 4,615 | 4,523 | **1.3x** |
| Peak output (rate=32) | **1,056** | 800 | 616 | **1.3x vs EP8 TP16** |
| TPOT (rate=32) | **41.49 ms** | 55.52 ms | 56.34 ms | **1.3x** |

**Key insight**: For DeepSeek-V3 on H200 (141GB), single-node TP8 EP8 is the optimal
configuration when the model fits in memory (~83 GB/GPU in FP8). The 2-node setup is only
needed when GPU memory is insufficient (e.g., H100 80GB) or when larger KV cache is required.

### EP8 TP16 vs EP16 TP16 (2-Node NCCL)

EP8 TP16 keeps MoE all-to-all (EP=8) on intra-node NVLink while TP=16 spans both nodes.
EP16 TP16 sends both MoE and attention traffic across EFA.

| Metric | EP8 TP16 | EP16 TP16 | Delta |
|--------|----------|-----------|-------|
| Output tok/s (rate=1) | 35.80 | 36.04 | -0.7% |
| TPOT (rate=1) | 27.10 ms | 26.92 ms | +0.7% |
| TTFT (rate=1) | **186.71 ms** | 236 ms | **21% faster** |
| Output tok/s (rate=32) | **510.01** | 502.23 | **+1.5%** |
| Peak output (rate=32) | **800** | 616 | **+30%** |
| TPOT (rate=32) | **55.52 ms** | 56.34 ms | **1.5% faster** |

**Analysis**: At rate=1, decode TPOT is nearly identical (~27 ms) — the cross-node TP
communication dominates in both configs. EP8 TP16 has a clear TTFT advantage (187 vs 236 ms)
because prefill benefits from faster intra-node MoE dispatch. At high concurrency (rate=32),
EP8 TP16 shows better peak throughput (800 vs 616 tok/s) as NVLink MoE all-to-all scales
better under batching than EFA-based EP16.

### NCCL vs UCCL-EP on EFA

- **NCCL is 2.3x faster at rate=1**: Per-token decode time (TPOT) is 27ms vs 63ms. Each
  decode step requires all-to-all communication across 61 MoE layers. NCCL's aws-ofi-nccl
  plugin uses optimized EFA data paths, while UCCL-EP's CPU proxy adds GPU↔host copy overhead.

- **Gap narrows at high concurrency (1.6x at rate=32)**: Batching amortizes per-token
  communication cost. UCCL-EP reaches 305 tok/s vs NCCL's 502 tok/s.

- **TTFT is identical**: Prefill computation is GPU-bound and doesn't depend on the MoE
  communication backend. Both backends achieve ~235ms TTFT at rate=1.

- **NCCL uses more GPU memory**: With no RDMA buffer reservation needed, NCCL can use
  `--mem-fraction-static 0.90` (vs 0.85 for UCCL-EP), providing ~5GB more KV cache per GPU.

### Recommendation

**Use NCCL (`--moe-a2a-backend none`) on AWS EFA**. UCCL-EP is designed for environments
with GPU-initiated RDMA (InfiniBand + NVSHMEM IBGDA). On EFA, which does not support
GPU-initiated RDMA, the CPU proxy fallback eliminates UCCL-EP's primary advantage. NCCL's
aws-ofi-nccl is the optimized path for EFA all-to-all communication.

UCCL-EP may be preferable on InfiniBand clusters where GPU-initiated RDMA (IBGDA) is
available, as it can bypass the CPU entirely for expert dispatch/combine.
