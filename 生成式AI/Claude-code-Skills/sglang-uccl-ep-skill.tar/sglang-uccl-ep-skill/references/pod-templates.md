# Pod Templates for SGLang + UCCL-EP on EKS

## Worker Pod

Full-resource pod for DeepSeek-V3 serving. Needs all 8 GPUs + 16 EFA + FSx.
Create one per node, adjusting `nodeSelector` and pod `name`.

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: uccl-ep-node0          # uccl-ep-node1 for second node
  namespace: default
  labels:
    kueue.x-k8s.io/queue-name: default-queue
spec:
  nodeSelector:
    kubernetes.io/hostname: <NODE_HOSTNAME>   # kubectl get nodes -o wide
  hostNetwork: true
  hostIPC: true
  restartPolicy: Never
  containers:
  - name: worker
    image: public.ecr.aws/deep-learning-containers/sglang:0.5.8-gpu-py312-cu129-ubuntu24.04-sagemaker-v1.11-soci
    command: ["sleep", "infinity"]
    securityContext:
      privileged: true
      capabilities:
        add: ["IPC_LOCK"]
    resources:
      requests:
        nvidia.com/gpu: 8
        vpc.amazonaws.com/efa: 16
        memory: "256Gi"
        cpu: "48"
      limits:
        nvidia.com/gpu: 8
        vpc.amazonaws.com/efa: 16
        memory: "256Gi"
        cpu: "48"
    env:
    - name: DEBIAN_FRONTEND
      value: noninteractive
    - name: CUDA_HOME
      value: /usr/local/cuda
    - name: EFA_HOME
      value: /opt/amazon/efa
    volumeMounts:
    - name: fsx
      mountPath: /fsx
    - name: shm
      mountPath: /dev/shm
  volumes:
  - name: fsx
    persistentVolumeClaim:
      claimName: fsx-claim
  - name: shm
    emptyDir:
      medium: Memory
      sizeLimit: "64Gi"
```

## Key Configuration Notes

- **`hostNetwork: true`**: Required for EFA device access and proper IP resolution.
- **`hostIPC: true`**: Required for shared memory (NVLink/NVSwitch IPC).
- **`privileged: true` + `IPC_LOCK`**: Required for RDMA pinned memory and GPU peer access.
- **`vpc.amazonaws.com/efa: 16`**: Request EFA adapters per node. Adjust for your instance type.
- **`/dev/shm` as emptyDir Memory**: Required for PyTorch distributed shared memory. 64Gi for workers.
- **FSx PVC**: Shared storage for build artifacts and model weights. Requires `fsx-claim` PVC pre-configured.
- **Do NOT mount host `/opt/amazon/efa`**: The DLC container has EFA pre-installed. Host mount causes read-only conflicts.
- **Base image**: SageMaker DLC with SGLang 0.5.8, PyTorch 2.9.1, CUDA 12.9 pre-installed.
